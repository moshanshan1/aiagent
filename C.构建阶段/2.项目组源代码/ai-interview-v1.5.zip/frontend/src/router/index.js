import { createRouter, createWebHashHistory } from 'vue-router'
import { useAppStore } from '../store/appStore.js?v=20260717a'
import { CandidatePage, InterviewerPage, LandingPage } from '../pages/browserPages.js?v=20260717a'

const routes = [
  {
    path: '/',
    name: 'landing',
    component: LandingPage
  },
  {
    path: '/interviewer',
    name: 'interviewer',
    component: InterviewerPage,
    meta: { role: 'interviewer' }
  },
  {
    path: '/candidate',
    name: 'candidate',
    component: CandidatePage,
    meta: { role: 'candidate' }
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/'
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

router.beforeEach((to) => {
  const store = useAppStore()
  const user = store.currentUser.value

  if (!to.meta.role) {
    return true
  }

  if (!user) {
    return '/'
  }

  if (user.role !== to.meta.role) {
    return user.role === 'interviewer' ? '/interviewer' : '/candidate'
  }

  return true
})

export default router








