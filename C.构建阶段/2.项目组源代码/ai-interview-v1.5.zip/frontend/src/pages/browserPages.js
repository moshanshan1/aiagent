import { computed, reactive, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { onBeforeUnmount } from 'vue'
import { useAppStore } from '../store/appStore.js?v=20260717a'
import { getTabSessionValue, setTabSessionValue } from '../utils/tabSession.js?v=20260716g'
import {
  AppHeader,
  InterviewSimulator,
  MessageCenter,
  MetricCard,
  ModuleNav,
  NotificationStack,
  SectionPanel
} from '../components/browserComponents.js?v=20260716g'

const LAST_REGISTERED_ACCOUNT_KEY = 'ai-interview-last-registered-account-v1'
const PENDING_REGISTER_NOTICE_KEY = 'ai-interview-pending-register-notice-v1'

function loadLastRegisteredAccount() {
  if (typeof localStorage === 'undefined') {
    return ''
  }

  try {
    return localStorage.getItem(LAST_REGISTERED_ACCOUNT_KEY) ?? ''
  } catch {
    return ''
  }
}

function saveLastRegisteredAccount(account) {
  if (typeof localStorage === 'undefined' || !account) {
    return
  }

  try {
    localStorage.setItem(LAST_REGISTERED_ACCOUNT_KEY, String(account))
  } catch {
    // Ignore storage failures.
  }
}

function savePendingRegisterNotice(payload) {
  if (!payload?.account) {
    return
  }

  setTabSessionValue(PENDING_REGISTER_NOTICE_KEY, JSON.stringify(payload))
}

function loadPendingRegisterNotice() {
  try {
    const raw = getTabSessionValue(PENDING_REGISTER_NOTICE_KEY)
    if (typeof raw !== 'string' || !raw) {
      return null
    }

    return JSON.parse(raw)
  } catch {
    return null
  }
}

function clearPendingRegisterNotice() {
  setTabSessionValue(PENDING_REGISTER_NOTICE_KEY, '')
}

function preview(text, length = 72) {
  if (!text) {
    return ''
  }

  return text.length > length ? `${text.slice(0, length)}...` : text
}

function matchesJobFilters(job, filters) {
  const keyword = filters.keyword?.trim().toLowerCase() ?? ''
  const salary = filters.salary?.trim().toLowerCase() ?? ''

  if (keyword) {
    const pool = `${job.title} ${job.tags.join(' ')} ${job.requirements} ${job.responsibilities}`.toLowerCase()
    if (!pool.includes(keyword)) {
      return false
    }
  }

  if (salary && !job.salaryRange.toLowerCase().includes(salary)) {
    return false
  }

  if (filters.education !== 'all' && job.education !== filters.education) {
    return false
  }

  if (filters.graduateType !== 'all' && job.graduateType !== filters.graduateType) {
    return false
  }

  if (filters.maxExperience !== 'all' && job.experienceYears > Number(filters.maxExperience)) {
    return false
  }

  return true
}

function toLocalInput(value) {
  if (!value) {
    return ''
  }

  const text = String(value)
  return text.includes('T') ? text.slice(0, 16) : text.replace(' ', 'T').slice(0, 16)
}

function extractDatePart(value) {
  return value ? String(value).slice(0, 10) : ''
}

function extractHourPart(value) {
  return value ? String(value).slice(11, 13) : '09'
}

function extractMinutePart(value) {
  return value ? String(value).slice(14, 16) : '00'
}

function composeLocalDateTime(date, hour, minute) {
  if (!date) {
    return ''
  }

  return `${date}T${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`
}

function padDateTimePart(value) {
  return String(value).padStart(2, '0')
}

function formatLocalDateTimeValue(date) {
  return [
    date.getFullYear(),
    padDateTimePart(date.getMonth() + 1),
    padDateTimePart(date.getDate())
  ].join('-') + `T${padDateTimePart(date.getHours())}:${padDateTimePart(date.getMinutes())}`
}

function buildDefaultScheduleDraft() {
  const start = new Date()
  start.setSeconds(0, 0)

  const roundedMinutes = Math.ceil(start.getMinutes() / 5) * 5
  if (roundedMinutes >= 60) {
    start.setHours(start.getHours() + 1, 0, 0, 0)
  } else {
    start.setMinutes(roundedMinutes, 0, 0)
  }

  const end = new Date(start.getTime() + 30 * 60 * 1000)

  return {
    start: formatLocalDateTimeValue(start),
    end: formatLocalDateTimeValue(end)
  }
}

function interviewerStatusText(interview) {
  const map = {
    draft_schedule: '待设置时间',
    scheduled: '等待开始',
    in_progress: interview.activeQuestion ? `第 ${interview.round} 题进行中` : '面试进行中',
    completed: '已结束'
  }

  return map[interview.status] ?? '状态更新中'
}

function candidateStatusText(interview) {
  const map = {
    draft_schedule: '等待面试安排',
    scheduled: '已安排时间',
    in_progress: interview.activeQuestion ? `第 ${interview.round} 题待作答` : '面试进行中',
    completed: '已结束'
  }

  return map[interview.status] ?? '状态更新中'
}

function reportAverage(scores) {
  const values = Object.values(scores ?? {}).filter((value) => Number.isFinite(Number(value)))
  if (!values.length) {
    return 0
  }

  return Math.round(values.reduce((sum, value) => sum + Number(value), 0) / values.length)
}

function formatReportDateTime(value) {
  if (!value) {
    return '待生成'
  }

  return String(value).replace('T', ' ').slice(0, 16)
}

function scoreBand(score) {
  const numeric = Number(score ?? 0)
  if (numeric >= 85) {
    return '表现突出'
  }
  if (numeric >= 75) {
    return '整体稳定'
  }
  if (numeric >= 60) {
    return '需要追问'
  }
  return '风险较高'
}

function buildDimensionInsights(report) {
  if (!report) {
    return []
  }

  return [
    {
      key: 'professional',
      label: '专业技能',
      score: report.scores.professional,
      summary: '结合题目作答内容、知识点覆盖度与岗位要求匹配度形成判断。'
    },
    {
      key: 'communication',
      label: '沟通能力',
      score: report.scores.communication,
      summary: '综合表述清晰度、表达完整性与回应效率进行评估。'
    },
    {
      key: 'logic',
      label: '逻辑思维',
      score: report.scores.logic,
      summary: '重点观察答题结构、问题拆解能力与论证连贯程度。'
    },
    {
      key: 'culture',
      label: '文化匹配',
      score: report.scores.culture,
      summary: '结合岗位角色预期、协作风格与稳定性倾向综合判断。'
    },
    {
      key: 'bodyLanguage',
      label: '表情与肢体',
      score: report.scores.bodyLanguage,
      summary: '如有视频作答，则参考语音、表情和肢体反馈形成补充评价。'
    }
  ]
}

function buildAnalysisOverview(interview) {
  const records = interview?.qaRecords ?? []
  if (!records.length) {
    return []
  }

  const completed = records.filter((item) => item.analysisStatus === 'completed').length
  const withTone = records.filter((item) => item.toneAnalysis?.summary).length
  const withBody = records.filter((item) => item.bodyLanguageAnalysis?.summary).length
  const videoCount = records.filter((item) => item.mediaType === 'video').length
  const audioCount = records.filter((item) => item.mediaType === 'audio').length

  return [
    { label: '已完成轮次', value: `${records.length} / ${interview.maxRounds || records.length}`, hint: '纳入本次评估的有效问答' },
    { label: '分析完成', value: `${completed} 轮`, hint: '已完成内容与语音分析的作答' },
    { label: '语音分析覆盖', value: `${withTone} 轮`, hint: '提取到语调、节奏或流畅度信号' },
    { label: '肢体分析覆盖', value: `${withBody} 轮`, hint: '视频模式下提取到表情或肢体信号' },
    { label: '视频作答', value: `${videoCount} 轮`, hint: '包含视频记录的回答轮次' },
    { label: '音频作答', value: `${audioCount} 轮`, hint: '仅使用语音完成的回答轮次' }
  ]
}

function buildMultimodalInsights(interview) {
  const records = interview?.qaRecords ?? []
  const items = []

  for (const record of records) {
    if (record.toneAnalysis?.summary) {
      items.push({
        key: `tone-${record.round}`,
        title: `第 ${record.round} 题语音信号`,
        text: record.toneAnalysis.summary
      })
    }

    if (record.bodyLanguageAnalysis?.summary) {
      items.push({
        key: `body-${record.round}`,
        title: `第 ${record.round} 题表情与肢体`,
        text: record.bodyLanguageAnalysis.summary
      })
    }
  }

  return items.slice(0, 8)
}

function buildEvidenceRecords(interview) {
  const records = interview?.qaRecords ?? []
  return records.map((record) => ({
    key: `record-${record.round}`,
    round: record.round,
    question: preview(record.question, 110),
    answer: preview(record.answerTranscript, 150),
    analysis: preview(record.analysis || '', 160),
    modeLabel: record.mediaType === 'video' ? '视频作答' : '语音作答'
  }))
}

const REPORT_OUTCOME_OPTIONS = [
  { value: 'hired', label: '录用' },
  { value: 'pending', label: '待定' },
  { value: 'rejected', label: '未录用' }
]

function buildInterviewScheduleNotice(jobTitle, start, end) {
  const title = jobTitle || '相关'
  const startText = start || '待定'
  const endText = end || '待定'
  return `你对于“${title}”岗位的面试时间已确定为 ${startText} 至 ${endText}，请准时参加并提前做好准备。如时间存在特殊情况，请及时在信息邮箱中沟通。`
}

function buildOutcomeMessage(jobTitle, outcome) {
  const title = jobTitle || '相关'
  const templates = {
    hired: `对于你应聘“${title}”岗位的面试，经过慎重考虑，结果为录用。我们认可你在本次面试中的综合表现，期待与你推进后续流程，并欢迎你的加入。`,
    pending: `对于你应聘“${title}”岗位的面试，经过慎重考虑，当前结果为待定。我们仍在结合岗位安排与整体评估进行进一步讨论，如有后续进展将第一时间与你联系，感谢你的耐心等待。`,
    rejected: `很遗憾地通知你，对于你应聘“${title}”岗位的面试，经过慎重考虑，本次结果为未录用。感谢你对本岗位的关注与认真参与，祝你后续求职顺利。`
  }

  return templates[outcome] ?? ''
}

export const LandingPage = {
  setup() {
    const router = useRouter()
    const store = useAppStore()
    const authMode = ref('login')
    const errorMessage = ref('')
    const successMessage = ref('')
    const lastRegisteredAccount = ref(loadLastRegisteredAccount())

    const loginForm = reactive({
      account: lastRegisteredAccount.value,
      password: ''
    })

    const registerForm = reactive({
      name: '',
      password: '',
      education: '本科',
      experienceYears: 0,
      graduateType: '应届',
      salaryExpectation: '12K-18K',
      skills: 'Vue 3, TypeScript, 沟通协作',
      experienceSummary: ''
    })

    function routeByRole(role) {
      router.push(role === 'interviewer' ? '/interviewer' : '/candidate').catch(() => {})
    }

    async function handleLogin() {
      errorMessage.value = ''
      successMessage.value = ''

      const result = await store.login(loginForm)
      if (!result.ok) {
        errorMessage.value = result.message
        return
      }

      routeByRole(result.user.role)
    }

    async function handleRegister() {
      errorMessage.value = ''
      successMessage.value = ''

      if (!registerForm.name.trim() || !registerForm.password.trim()) {
        errorMessage.value = '请先填写姓名和密码。'
        return
      }

      try {
        const user = await store.registerCandidate(registerForm)
        saveLastRegisteredAccount(user.account)
        lastRegisteredAccount.value = user.account
        loginForm.account = user.account
        savePendingRegisterNotice({
          userId: String(store.currentUser.value?.id ?? ''),
          account: user.account
        })
        successMessage.value = `注册成功，系统已分配账号 ${user.account}。`
        router.push('/candidate')
      } catch (error) {
        errorMessage.value = error instanceof Error ? error.message : '注册失败'
      }
    }

    return {
      authMode,
      errorMessage,
      successMessage,
      lastRegisteredAccount,
      loginForm,
      registerForm,
      handleLogin,
      handleRegister
    }
  },
  template: `
    <div class="landing-shell">
      <section class="landing-top">
        <div class="landing-copy">
          <span class="landing-tag">AI Interview Console</span>
          <h1>AI面试官与人才评估系统</h1>
          <p>统一处理岗位管理、面试安排、报告沉淀与站内沟通。</p>
          <div class="landing-actions">
            <button class="primary-button simple" type="button" @click="authMode = 'login'">登录</button>
            <button class="secondary-button simple" type="button" @click="authMode = 'register'">注册</button>
          </div>
          <div class="landing-graphic" aria-hidden="true">
            <span class="graphic-node node-a"></span>
            <span class="graphic-node node-b"></span>
            <span class="graphic-node node-c"></span>
            <span class="graphic-node node-d"></span>
            <span class="graphic-line line-a"></span>
            <span class="graphic-line line-b"></span>
            <span class="graphic-line line-c"></span>
          </div>
        </div>

        <div class="landing-auth">
          <div class="auth-switch-lite">
            <button :class="{ active: authMode === 'login' }" type="button" @click="authMode = 'login'">登录</button>
            <button :class="{ active: authMode === 'register' }" type="button" @click="authMode = 'register'">注册</button>
          </div>

          <div v-if="authMode === 'login'" class="auth-form-lite">
            <label>
              账号
              <input v-model="loginForm.account" placeholder="请输入六位账号" />
            </label>
            <label>
              密码
              <input v-model="loginForm.password" type="password" placeholder="请输入密码" />
            </label>
            <button class="primary-button simple full" type="button" @click="handleLogin">进入系统</button>
            <div class="demo-box">
              <strong>演示账号</strong>
              <span>面试官：000001 / admin123</span>
              <span>面试者：请先注册后登录</span>
              <span v-if="lastRegisteredAccount">最近注册账号：{{ lastRegisteredAccount }}</span>
            </div>
          </div>

          <div v-else class="auth-form-lite">
            <label>
              姓名
              <input v-model="registerForm.name" placeholder="请输入姓名" />
            </label>
            <div class="form-row-lite">
              <label>
                学历
                <select v-model="registerForm.education">
                  <option>大专</option>
                  <option>本科</option>
                  <option>硕士</option>
                  <option>博士</option>
                </select>
              </label>
              <label>
                经验年限
                <input v-model="registerForm.experienceYears" type="number" min="0" max="20" />
              </label>
            </div>
            <div class="form-row-lite">
              <label>
                应届 / 往届
                <select v-model="registerForm.graduateType">
                  <option>应届</option>
                  <option>往届</option>
                </select>
              </label>
              <label>
                薪资期望
                <input v-model="registerForm.salaryExpectation" />
              </label>
            </div>
            <label>
              技能关键词
              <input v-model="registerForm.skills" placeholder="例如 Vue 3, TypeScript, 沟通协作" />
            </label>
            <label>
              个人经历
              <textarea v-model="registerForm.experienceSummary" placeholder="输入个人经历或项目亮点"></textarea>
            </label>
            <label>
              登录密码
              <input v-model="registerForm.password" type="password" placeholder="设置密码" />
            </label>
            <button class="primary-button simple full" type="button" @click="handleRegister">注册并进入系统</button>
          </div>

          <p v-if="errorMessage" class="feedback error">{{ errorMessage }}</p>
          <p v-if="successMessage" class="feedback success">{{ successMessage }}</p>
        </div>
      </section>
    </div>
  `
}

export const InterviewerPage = {
  components: {
    AppHeader,
    MessageCenter,
    MetricCard,
    ModuleNav,
    NotificationStack,
    SectionPanel
  },
  setup() {
    const store = useAppStore()
    const currentUser = store.currentUser
    const activeModule = ref('overview')
    const selectedJobId = ref('')
    const selectedInterviewId = ref('')
    const selectedInterviewDetail = ref(null)
    const selectedReportId = ref('')
    const showJobForm = ref(false)
    const jdUploadInputRef = ref(null)
    const jdUploading = ref(false)
    const creatingInterviewKeys = reactive({})
    const scheduleDraft = reactive({
      start: '',
      end: ''
    })
    const scheduleDirty = ref(false)
    const scheduleHydrating = ref(false)
    const scheduleRefreshLockReason = 'interviewer-schedule-editing'
    const questionDrafts = reactive({})
    const questionSavingKeys = reactive({})
    const reportOutcomeChoice = ref('hired')
    const scheduleSaving = ref(false)
    const reportGenerating = ref(false)
    const reportDownloading = ref(false)
    const feedbackMessage = ref('')
    let liveSyncTimer = null

    const showInterviewModeDialog = ref(false)
    const dialogJobId = ref('')
    const dialogCandidateId = ref('')
    const dialogInterviewMode = ref('preset')
    const dialogMaxRounds = ref(5)

    const jobForm = reactive({
      title: '',
      salaryRange: '',
      education: '本科',
      experienceYears: 0,
      graduateType: '不限',
      responsibilities: '',
      requirements: '',
      tags: ''
    })

    const modules = [
      { key: 'overview', label: '总览', hint: '查看当前工作入口' },
      { key: 'jobs', label: '岗位管理', hint: '岗位与候选人' },
      { key: 'interviews', label: '面试管理', hint: '安排时间与查看记录' },
      { key: 'reports', label: '报告中心', hint: '生成报告与评级' },
      { key: 'messages', label: '信息邮箱', hint: '查看沟通记录' }
    ]

    const jobs = store.interviewerJobs
    const interviews = store.interviewerInterviews
    const reports = store.enrichedReports
    const threads = store.messageThreads
    const notifications = store.notificationsForCurrentUser

    const selectedJob = computed(() => jobs.value.find((item) => item.id === selectedJobId.value) ?? null)
    const selectedJobDocuments = computed(
      () => store.jobDocumentsByJob.value[String(selectedJobId.value)] ?? []
    )
    const selectedInterview = computed(() => {
      if (selectedInterviewDetail.value && selectedInterviewDetail.value.id === selectedInterviewId.value) {
        return selectedInterviewDetail.value
      }

      return interviews.value.find((item) => item.id === selectedInterviewId.value) ?? null
    })
    const selectedReport = computed(
      () => reports.value.find((item) => item.id === selectedReportId.value) ?? null
    )
    const selectedReportInterview = computed(() => {
      if (!selectedReport.value) {
        return null
      }

      if (
        selectedInterviewDetail.value &&
        selectedInterviewDetail.value.id === selectedReport.value.interviewId
      ) {
        return selectedInterviewDetail.value
      }

      return interviews.value.find((item) => item.id === selectedReport.value.interviewId) ?? null
    })
    const selectedReportOutcomePreview = computed(() =>
      buildOutcomeMessage(selectedReport.value?.job?.title || selectedReport.value?.jobTitle, reportOutcomeChoice.value)
    )
    const selectedReportOutcomeSent = computed(() => Boolean(selectedReport.value?.outcomeSent))
    const selectedReportDimensions = computed(() => buildDimensionInsights(selectedReport.value))
    const selectedReportAnalysisOverview = computed(() => buildAnalysisOverview(selectedReportInterview.value))
    const selectedReportMultimodalInsights = computed(() => buildMultimodalInsights(selectedReportInterview.value))
    const selectedReportEvidenceRecords = computed(() => buildEvidenceRecords(selectedReportInterview.value))

    const scheduleHourOptions = Array.from({ length: 24 }, (_, index) => String(index).padStart(2, '0'))
    const scheduleMinuteOptions = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55']

    const scheduleStartDate = computed({
      get: () => extractDatePart(scheduleDraft.start),
      set: (value) => {
        scheduleDraft.start = composeLocalDateTime(
          value,
          extractHourPart(scheduleDraft.start),
          extractMinutePart(scheduleDraft.start)
        )
        if (!scheduleHydrating.value) {
          scheduleDirty.value = true
          store.pauseAutoRefresh(scheduleRefreshLockReason)
        }
      }
    })
    const scheduleStartHour = computed({
      get: () => extractHourPart(scheduleDraft.start),
      set: (value) => {
        scheduleDraft.start = composeLocalDateTime(
          extractDatePart(scheduleDraft.start),
          value,
          extractMinutePart(scheduleDraft.start)
        )
        if (!scheduleHydrating.value) {
          scheduleDirty.value = true
          store.pauseAutoRefresh(scheduleRefreshLockReason)
        }
      }
    })
    const scheduleStartMinute = computed({
      get: () => extractMinutePart(scheduleDraft.start),
      set: (value) => {
        scheduleDraft.start = composeLocalDateTime(
          extractDatePart(scheduleDraft.start),
          extractHourPart(scheduleDraft.start),
          value
        )
        if (!scheduleHydrating.value) {
          scheduleDirty.value = true
          store.pauseAutoRefresh(scheduleRefreshLockReason)
        }
      }
    })
    const scheduleEndDate = computed({
      get: () => extractDatePart(scheduleDraft.end),
      set: (value) => {
        scheduleDraft.end = composeLocalDateTime(
          value,
          extractHourPart(scheduleDraft.end),
          extractMinutePart(scheduleDraft.end)
        )
        if (!scheduleHydrating.value) {
          scheduleDirty.value = true
          store.pauseAutoRefresh(scheduleRefreshLockReason)
        }
      }
    })
    const scheduleEndHour = computed({
      get: () => extractHourPart(scheduleDraft.end),
      set: (value) => {
        scheduleDraft.end = composeLocalDateTime(
          extractDatePart(scheduleDraft.end),
          value,
          extractMinutePart(scheduleDraft.end)
        )
        if (!scheduleHydrating.value) {
          scheduleDirty.value = true
          store.pauseAutoRefresh(scheduleRefreshLockReason)
        }
      }
    })
    const scheduleEndMinute = computed({
      get: () => extractMinutePart(scheduleDraft.end),
      set: (value) => {
        scheduleDraft.end = composeLocalDateTime(
          extractDatePart(scheduleDraft.end),
          extractHourPart(scheduleDraft.end),
          value
        )
        if (!scheduleHydrating.value) {
          scheduleDirty.value = true
          store.pauseAutoRefresh(scheduleRefreshLockReason)
        }
      }
    })

    function syncScheduleDraftFromInterview(interview, force = false) {
      if (scheduleDirty.value && !force) {
        return
      }

      scheduleHydrating.value = true
      try {
        if (interview?.openTimeStart || interview?.openTimeEnd) {
          scheduleDraft.start = toLocalInput(interview?.openTimeStart)
          scheduleDraft.end = toLocalInput(interview?.openTimeEnd)
        } else {
          const fallback = buildDefaultScheduleDraft()
          scheduleDraft.start = fallback.start
          scheduleDraft.end = fallback.end
        }
        scheduleDirty.value = false
        store.resumeAutoRefresh(scheduleRefreshLockReason)
      } finally {
        scheduleHydrating.value = false
      }
    }

    watch(
      interviews,
      (list) => {
        if (!list.find((item) => item.id === selectedInterviewId.value)) {
          selectedInterviewId.value = ''
          selectedInterviewDetail.value = null
        }
      },
      { immediate: true, deep: true }
    )

    watch(
      () => [
        selectedInterviewId.value,
        selectedInterview.value?.openTimeStart ?? '',
        selectedInterview.value?.openTimeEnd ?? ''
      ],
      ([interviewId, openTimeStart, openTimeEnd], previous = []) => {
        const [previousInterviewId] = previous
        syncScheduleDraftFromInterview(
          interviewId
            ? {
                openTimeStart,
                openTimeEnd
              }
            : null,
          interviewId !== previousInterviewId
        )
      },
      { immediate: true }
    )

    watch(
      selectedReportId,
      () => {
        reportOutcomeChoice.value = 'hired'
      }
    )

    watch(
      () => [selectedInterviewId.value, JSON.stringify(selectedInterview.value?.questions ?? [])],
      () => {
        Object.keys(questionDrafts).forEach((key) => {
          delete questionDrafts[key]
        })

        ;(selectedInterview.value?.questions ?? []).forEach((question) => {
          questionDrafts[question.id] = question.text
        })
      },
      { immediate: true }
    )

    async function openJob(jobId) {
      selectedJobId.value = selectedJobId.value === jobId ? '' : jobId
      activeModule.value = 'jobs'
      if (selectedJobId.value) {
        await store.loadJobDocuments(selectedJobId.value)
      }
    }

    function triggerJobDocumentPicker() {
      jdUploadInputRef.value?.click?.()
    }

    async function handleJobDocumentSelected(event) {
      const file = event?.target?.files?.[0]
      if (!file || !selectedJobId.value) {
        return
      }

      jdUploading.value = true
      feedbackMessage.value = ''
      try {
        const result = await store.uploadJobDocument(selectedJobId.value, file, file.name.replace(/\.[^.]+$/, ''))
        feedbackMessage.value = result.ok
          ? 'JD 文档已上传，系统正在后台解析。'
          : result.message
      } finally {
        jdUploading.value = false
        if (event?.target) {
          event.target.value = ''
        }
      }
    }

    async function openInterview(interviewId) {
      if (selectedInterviewId.value === interviewId) {
        selectedInterviewId.value = ''
        selectedInterviewDetail.value = null
        store.resumeAutoRefresh(scheduleRefreshLockReason)
        return
      }

      selectedInterviewId.value = interviewId
      activeModule.value = 'interviews'
      selectedInterviewDetail.value = await store.loadInterviewDetails(interviewId)
    }

    async function openReport(reportId) {
      const nextReportId = selectedReportId.value === reportId ? '' : reportId
      selectedReportId.value = nextReportId
      activeModule.value = 'reports'

      if (!nextReportId) {
        return
      }

      const targetReport = reports.value.find((item) => item.id === nextReportId)
      if (targetReport?.interviewId) {
        try {
          await store.loadInterviewDetails(targetReport.interviewId)
        } catch {
          // Ignore detail hydration failures and keep the report visible.
        }
      }
    }

    async function submitAddJob() {
      feedbackMessage.value = ''
      const result = await store.addJob(jobForm)
      if (!result.ok) {
        feedbackMessage.value = result.message
        return
      }

      Object.assign(jobForm, {
        title: '',
        salaryRange: '',
        education: '本科',
        experienceYears: 0,
        graduateType: '不限',
        responsibilities: '',
        requirements: '',
        tags: ''
      })

      showJobForm.value = false
      selectedJobId.value = result.job.id
      feedbackMessage.value = '岗位已创建。'
    }

    function interviewModeLabel(mode) {
      return mode === 'agent' ? 'Agent 面试' : '预制面试'
    }

    function interviewModeBadgeClass(mode) {
      return mode === 'agent' ? 'mode-badge agent' : 'mode-badge preset'
    }

    function openInterviewModeDialog(jobId, candidateId) {
      dialogJobId.value = jobId
      dialogCandidateId.value = candidateId
      dialogInterviewMode.value = 'preset'
      dialogMaxRounds.value = 5
      showInterviewModeDialog.value = true
    }

    function closeInterviewModeDialog() {
      showInterviewModeDialog.value = false
    }

    async function confirmCreateInterview() {
      const jobId = dialogJobId.value
      const candidateId = dialogCandidateId.value
      const requestKey = `${jobId}-${candidateId}`

      if (creatingInterviewKeys[requestKey]) {
        return
      }

      showInterviewModeDialog.value = false
      feedbackMessage.value = ''
      creatingInterviewKeys[requestKey] = true

      try {
        const interview = await store.createInterviewPlan(
          jobId,
          candidateId,
          dialogInterviewMode.value,
          Number(dialogMaxRounds.value)
        )
        feedbackMessage.value = '面试已创建。'
        await openInterview(interview.id)
      } catch (error) {
        feedbackMessage.value = error instanceof Error ? error.message : '创建面试失败'
      } finally {
        delete creatingInterviewKeys[requestKey]
      }
    }

    async function createInterview(jobId, candidateId) {
      openInterviewModeDialog(jobId, candidateId)
    }

    function isCreatingInterview(jobId, candidateId) {
      return Boolean(creatingInterviewKeys[`${jobId}-${candidateId}`])
    }

    async function saveSchedule() {
      if (!selectedInterview.value || !scheduleDraft.start || !scheduleDraft.end) {
        feedbackMessage.value = '请先选择开始和结束时间。'
        return
      }

      scheduleSaving.value = true
      feedbackMessage.value = ''
      try {
        await store.updateInterviewSchedule(selectedInterview.value.id, {
          openTimeStart: `${scheduleDraft.start}:00`,
          openTimeEnd: `${scheduleDraft.end}:00`
        })
        selectedInterviewDetail.value = await store.loadInterviewDetails(selectedInterview.value.id)
        scheduleDirty.value = false
        store.resumeAutoRefresh(scheduleRefreshLockReason)
        try {
          await store.sendInterviewScheduleNotice(
            selectedInterview.value.id,
            buildInterviewScheduleNotice(
              selectedInterview.value.job?.title,
              store.formatScheduleDisplay(`${scheduleDraft.start}:00`),
              store.formatScheduleDisplay(`${scheduleDraft.end}:00`)
            )
          )
          feedbackMessage.value = '开放时间已保存，并已通知面试者。'
        } catch (noticeError) {
          feedbackMessage.value = noticeError instanceof Error
            ? `开放时间已保存，但通知发送失败：${noticeError.message}`
            : '开放时间已保存，但通知发送失败。'
        }
      } catch (error) {
        feedbackMessage.value = error instanceof Error ? error.message : '保存开放时间失败'
      } finally {
        scheduleSaving.value = false
      }
    }

    async function saveQuestion(question) {
      if (!selectedInterview.value || !question?.id) {
        return
      }

      const draftText = String(questionDrafts[question.id] ?? '').trim()
      if (!draftText) {
        feedbackMessage.value = '题目内容不能为空。'
        return
      }

      const savingKey = `${selectedInterview.value.id}-${question.id}`
      if (questionSavingKeys[savingKey]) {
        return
      }

      questionSavingKeys[savingKey] = true
      feedbackMessage.value = ''
      try {
        selectedInterviewDetail.value = await store.updateInterviewQuestion(
          selectedInterview.value.id,
          question.id,
          draftText
        )
        feedbackMessage.value = `第 ${question.sortOrder} 题已更新。`
      } catch (error) {
        feedbackMessage.value = error instanceof Error ? error.message : '更新题目失败'
      } finally {
        delete questionSavingKeys[savingKey]
      }
    }

    function isSavingQuestion(questionId) {
      return Boolean(questionSavingKeys[`${selectedInterview.value?.id}-${questionId}`])
    }

    async function generateReport() {
      if (!selectedInterview.value) {
        return
      }

      reportGenerating.value = true
      feedbackMessage.value = ''
      try {
        const report = await store.generateReport(selectedInterview.value.id)
        feedbackMessage.value = '报告已生成。'
        if (report?.id) {
          openReport(report.id)
        }
      } catch (error) {
        feedbackMessage.value = error instanceof Error ? error.message : '生成报告失败'
      } finally {
        reportGenerating.value = false
      }
    }

    function collapseJobDetail() {
      selectedJobId.value = ''
    }

    function collapseInterviewDetail() {
      selectedInterviewId.value = ''
      selectedInterviewDetail.value = null
      store.resumeAutoRefresh(scheduleRefreshLockReason)
    }

    function collapseReportDetail() {
      selectedReportId.value = ''
    }

    function clearFeedbackMessage() {
      feedbackMessage.value = ''
    }

    async function rateReport(grade) {
      if (!selectedReport.value) {
        return
      }

      await store.rateReport(selectedReport.value.id, grade)
      feedbackMessage.value = `报告已评级为 ${grade}。`
    }

    async function sendOutcome() {
      if (!selectedReport.value || selectedReportOutcomeSent.value) {
        return
      }

      await store.sendOutcome(
        selectedReport.value.id,
        buildOutcomeMessage(selectedReport.value.job?.title || selectedReport.value.jobTitle, reportOutcomeChoice.value)
      )
      await store.refreshAll()
      feedbackMessage.value = '反馈结果已发送。'
      activeModule.value = 'messages'
    }

    async function downloadReport() {
      if (!selectedReport.value) {
        return
      }

      reportDownloading.value = true
      feedbackMessage.value = ''
      try {
        const result = await store.downloadReportPdf(selectedReport.value.id)
        if (typeof window !== 'undefined') {
          const downloadUrl = window.URL.createObjectURL(result.blob)
          const anchor = document.createElement('a')
          anchor.href = downloadUrl
          anchor.download = `report_${selectedReport.value.id}.pdf`
          document.body.appendChild(anchor)
          anchor.click()
          anchor.remove()
          window.URL.revokeObjectURL(downloadUrl)
        }
        feedbackMessage.value = '报告已上传。'
      } catch (error) {
        feedbackMessage.value = error instanceof Error ? error.message : '下载报告失败'
      } finally {
        reportDownloading.value = false
      }
    }

    function deleteCompletedInterview() {
      if (!selectedInterview.value) {
        return
      }

      const result = store.hideCompletedInterview(selectedInterview.value.id)
      if (!result.ok) {
        feedbackMessage.value = result.message
        return
      }

      collapseInterviewDetail()
      feedbackMessage.value = '已删除这条已完成面试记录。'
    }

    async function sendMessage(payload) {
      await store.sendMessage(payload)
    }

    if (typeof window !== 'undefined') {
      liveSyncTimer = window.setInterval(async () => {
        try {
          await store.refreshAll()
          if (
            selectedInterviewId.value &&
            !scheduleDirty.value &&
            !scheduleSaving.value &&
            !store.isAutoRefreshPaused()
          ) {
            selectedInterviewDetail.value = await store.loadInterviewDetails(selectedInterviewId.value)
          }
        } catch {
          // Ignore transient polling failures.
        }
      }, 15000)
    }

    onBeforeUnmount(() => {
      if (liveSyncTimer) {
        window.clearInterval(liveSyncTimer)
      }
    })

    return {
      store,
      currentUser,
      activeModule,
      modules,
      jobs,
      interviews,
      reports,
      threads,
      notifications,
      selectedJobId,
      selectedInterviewId,
      selectedReportId,
      selectedJob,
      selectedJobDocuments,
      selectedInterview,
      selectedReport,
      selectedReportInterview,
      showJobForm,
      jdUploadInputRef,
      jdUploading,
      scheduleDraft,
      scheduleHourOptions,
      scheduleMinuteOptions,
      scheduleStartDate,
      scheduleStartHour,
      scheduleStartMinute,
      scheduleEndDate,
      scheduleEndHour,
      scheduleEndMinute,
      scheduleSaving,
      reportGenerating,
      reportDownloading,
      feedbackMessage,
      showInterviewModeDialog,
      dialogInterviewMode,
      dialogMaxRounds,
      reportOutcomeOptions: REPORT_OUTCOME_OPTIONS,
      jobForm,
      reportOutcomeChoice,
      selectedReportOutcomePreview,
      selectedReportOutcomeSent,
      selectedReportDimensions,
      selectedReportAnalysisOverview,
      selectedReportMultimodalInsights,
      selectedReportEvidenceRecords,
      preview,
      interviewerStatusText,
      reportAverage,
      formatReportDateTime,
      scoreBand,
      interviewModeLabel,
      interviewModeBadgeClass,
      collapseJobDetail,
      collapseInterviewDetail,
      collapseReportDetail,
      clearFeedbackMessage,
      openJob,
      triggerJobDocumentPicker,
      handleJobDocumentSelected,
      openInterview,
      openReport,
      submitAddJob,
      createInterview,
      confirmCreateInterview,
      closeInterviewModeDialog,
      isCreatingInterview,
      saveSchedule,
      saveQuestion,
      isSavingQuestion,
      questionDrafts,
      generateReport,
      rateReport,
      sendOutcome,
      downloadReport,
      deleteCompletedInterview,
      sendMessage,
      dismissNotification: store.dismissNotification
    }
  },
  template: `
    <div class="workspace-page">
      <AppHeader />

      <div class="workspace-layout">
        <ModuleNav
          :items="modules"
          :active-key="activeModule"
          title="面试官工作区"
          :subtitle="currentUser?.name || ''"
          @select="activeModule = $event"
        />

        <main class="workspace-main">
          <NotificationStack :items="notifications" @dismiss="dismissNotification" />
          <div v-if="feedbackMessage" class="notice-bar prominent success-banner">
            <div class="success-banner-copy">
              <strong>操作成功</strong>
              <span>{{ feedbackMessage }}</span>
            </div>
            <button class="success-banner-close" type="button" aria-label="关闭提示" title="关闭提示" @click="clearFeedbackMessage">×</button>
          </div>

          <template v-if="activeModule === 'overview'">
            <div class="split-panels">
              <SectionPanel title="快捷入口" subtitle="按模块快速进入当前工作">
                <div class="quick-grid">
                  <button class="quick-entry" type="button" @click="activeModule = 'jobs'">岗位管理</button>
                  <button class="quick-entry" type="button" @click="activeModule = 'interviews'">面试管理</button>
                  <button class="quick-entry" type="button" @click="activeModule = 'reports'">报告中心</button>
                  <button class="quick-entry" type="button" @click="activeModule = 'messages'">信息邮箱</button>
                </div>
              </SectionPanel>

              <SectionPanel title="最近面试" subtitle="可直接打开当前面试">
                <div class="simple-list">
                  <button
                    v-for="item in interviews.slice(0, 5)"
                    :key="item.id"
                    class="list-row-button"
                    type="button"
                    @click="openInterview(item.id)"
                  >
                    <strong>{{ item.job?.title }}</strong>
                    <span>{{ item.candidate?.name }} / {{ interviewerStatusText(item) }}</span>
                  </button>
                  <div v-if="!interviews.length" class="empty-card">当前还没有面试。</div>
                </div>
              </SectionPanel>
            </div>
          </template>

          <template v-else-if="activeModule === 'jobs'">
            <SectionPanel title="岗位管理" subtitle="查看岗位、申请人并创建面试">
              <template #actions>
                <button class="secondary-button simple" type="button" @click="showJobForm = !showJobForm">
                  {{ showJobForm ? '收起新增岗位' : '新增岗位' }}
                </button>
              </template>

              <div v-if="showJobForm" class="inline-form-card">
                <div class="form-grid-2">
                  <label>
                    岗位名称
                    <input v-model="jobForm.title" />
                  </label>
                  <label>
                    薪资范围
                    <input v-model="jobForm.salaryRange" placeholder="例如 18K-24K" />
                  </label>
                  <label>
                    学历要求
                    <select v-model="jobForm.education">
                      <option>大专</option>
                      <option>本科</option>
                      <option>硕士</option>
                      <option>博士</option>
                    </select>
                  </label>
                  <label>
                    经验要求
                    <input v-model="jobForm.experienceYears" type="number" min="0" max="20" />
                  </label>
                  <label>
                    应届 / 往届
                    <select v-model="jobForm.graduateType">
                      <option>不限</option>
                      <option>应届</option>
                      <option>往届</option>
                    </select>
                  </label>
                  <label>
                    标签
                    <input v-model="jobForm.tags" placeholder="可留空" />
                  </label>
                  <label class="full">
                    工作内容
                    <textarea v-model="jobForm.responsibilities"></textarea>
                  </label>
                  <label class="full">
                    职位要求
                    <textarea v-model="jobForm.requirements"></textarea>
                  </label>
                </div>
                <button class="primary-button simple" type="button" @click="submitAddJob">保存岗位</button>
              </div>

              <div class="two-column">
                <div class="list-column">
                  <button
                    v-for="job in jobs"
                    :key="job.id"
                    class="list-row-button"
                    :class="{ active: selectedJobId === job.id }"
                    type="button"
                    @click="openJob(job.id)"
                  >
                    <strong>{{ job.title }}</strong>
                    <span>{{ job.salaryRange }} / {{ job.applicantsDetailed.length }} 人申请</span>
                  </button>
                  <div v-if="!jobs.length" class="empty-card">当前还没有岗位。</div>
                </div>

                <div class="detail-column">
                  <template v-if="selectedJob">
                    <div class="detail-summary">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseJobDetail">▴</button>
                      <h4>{{ selectedJob.title }}</h4>
                      <p>{{ selectedJob.salaryRange }} / {{ selectedJob.education }} / {{ selectedJob.experienceYears }} 年及以上</p>
                      <div class="tag-row">
                        <span v-for="tag in selectedJob.tags" :key="tag">{{ tag }}</span>
                      </div>
                    </div>

                    <div class="detail-block">
                      <strong>岗位职责</strong>
                      <p>{{ selectedJob.responsibilities }}</p>
                    </div>

                    <div class="detail-block">
                      <strong>职位要求</strong>
                      <p>{{ selectedJob.requirements }}</p>
                    </div>

                    <div class="detail-block">
                      <div class="detail-block-head">
                        <strong>JD 文档</strong>
                        <div class="detail-block-actions">
                          <button class="secondary-button simple" type="button" :disabled="jdUploading" @click="triggerJobDocumentPicker">
                            {{ jdUploading ? '上传中...' : '上传 JD 文档' }}
                          </button>
                          <input ref="jdUploadInputRef" class="visually-hidden-input" type="file" accept=".txt,.doc,.docx,.pdf" @change="handleJobDocumentSelected" />
                        </div>
                      </div>
                      <div class="history-list">
                        <article v-for="doc in selectedJobDocuments" :key="doc.id" class="history-item">
                          <strong>{{ doc.title || '未命名文档' }}</strong>
                          <p>状态：{{ doc.status === 'completed' ? '已解析' : (doc.status === 'failed' ? '解析失败' : '解析中') }}</p>
                          <small v-if="doc.parsedChunks != null">切片数：{{ doc.parsedChunks }}</small>
                          <small v-else-if="doc.errorMessage">{{ doc.errorMessage }}</small>
                        </article>
                        <div v-if="!selectedJobDocuments.length" class="empty-card">当前还没有上传 JD 文档。</div>
                      </div>
                    </div>

                    <div class="detail-block">
                      <strong>申请人列表</strong>
                      <div class="candidate-stack">
                        <article
                          v-for="person in selectedJob.applicantsDetailed"
                          :key="person.id"
                          class="candidate-card-lite"
                        >
                          <div class="candidate-card-head">
                            <div>
                              <strong>{{ person.name }}</strong>
                              <span>{{ person.application?.submittedAt || '已申请' }}</span>
                              <span
                                v-if="person.currentInterview"
                                :class="interviewModeBadgeClass(person.currentInterview.interviewMode)"
                              >{{ interviewModeLabel(person.currentInterview.interviewMode) }}</span>
                            </div>
                            <button
                              v-if="person.currentInterview"
                              class="secondary-button simple"
                              type="button"
                              @click="openInterview(person.currentInterview.id)"
                            >
                              查看面试
                            </button>
                            <button
                              v-else
                              class="primary-button simple"
                              type="button"
                              :disabled="isCreatingInterview(selectedJob.id, person.id)"
                              @click="createInterview(selectedJob.id, person.id)"
                            >
                              {{ isCreatingInterview(selectedJob.id, person.id) ? '创建中...' : '创建面试' }}
                            </button>
                          </div>

                          <div class="candidate-meta-grid">
                            <span>学历：{{ person.profile?.education || '未填写' }}</span>
                            <span>经验：{{ person.profile?.experienceYears ?? 0 }} 年</span>
                            <span>身份：{{ person.profile?.graduateType || '未填写' }}</span>
                          </div>

                          <ul class="note-list">
                            <li v-for="note in person.aiNotes" :key="note">初步建议：{{ note }}</li>
                          </ul>
                          <p v-if="person.resumeExcerpt" class="status-text">简历摘要：{{ preview(person.resumeExcerpt, 120) }}</p>
                        </article>

                        <div v-if="!selectedJob.applicantsDetailed.length" class="empty-card">该岗位暂时还没有申请人。</div>
                      </div>
                    </div>
                  </template>

                  <div v-else class="empty-card">请先从左侧岗位列表中选择一个岗位。</div>
                </div>
              </div>
            </SectionPanel>
          </template>

          <template v-else-if="activeModule === 'interviews'">
            <SectionPanel title="面试管理" subtitle="设置开放时间并查看问答记录">
              <div class="two-column">
                <div class="list-column">
                  <button
                    v-for="item in interviews"
                    :key="item.id"
                    class="list-row-button"
                    :class="{ active: selectedInterviewId === item.id }"
                    type="button"
                    @click="openInterview(item.id)"
                  >
                    <strong>{{ item.job?.title }}</strong>
                    <span>
                      <span :class="interviewModeBadgeClass(item.interviewMode)">{{ interviewModeLabel(item.interviewMode) }}</span>
                      {{ item.candidate?.name }} / {{ interviewerStatusText(item) }}
                    </span>
                  </button>
                  <div v-if="!interviews.length" class="empty-card">当前还没有可管理的面试。</div>
                </div>

                <div class="detail-column">
                  <template v-if="selectedInterview">
                    <div class="detail-summary">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseInterviewDetail">▴</button>
                      <h4>{{ selectedInterview.job?.title }}</h4>
                      <p>
                        <span :class="interviewModeBadgeClass(selectedInterview.interviewMode)">{{ interviewModeLabel(selectedInterview.interviewMode) }}</span>
                        {{ selectedInterview.candidate?.name }} / {{ interviewerStatusText(selectedInterview) }}
                      </p>
                    </div>

                    <div class="detail-block">
                      <div class="detail-block-head">
                        <strong>开放时间</strong>
                        <div v-if="scheduleDirty || !selectedInterview.openTimeStart || !selectedInterview.openTimeEnd" class="detail-block-actions">
                          <button class="primary-button simple" type="button" :disabled="scheduleSaving" @click="saveSchedule">
                            {{ scheduleSaving ? '保存中...' : '保存开放时间' }}
                          </button>
                        </div>
                      </div>
                      <div class="form-grid-2">
                        <label>
                          开始日期
                          <input v-model="scheduleStartDate" type="date" />
                        </label>
                        <label>
                          开始时间
                          <div class="inline-actions">
                            <select v-model="scheduleStartHour">
                              <option v-for="hour in scheduleHourOptions" :key="'start-hour-' + hour" :value="hour">{{ hour }}</option>
                            </select>
                            <select v-model="scheduleStartMinute">
                              <option v-for="minute in scheduleMinuteOptions" :key="'start-minute-' + minute" :value="minute">{{ minute }}</option>
                            </select>
                          </div>
                        </label>
                        <label>
                          结束日期
                          <input v-model="scheduleEndDate" type="date" />
                        </label>
                        <label>
                          结束时间
                          <div class="inline-actions">
                            <select v-model="scheduleEndHour">
                              <option v-for="hour in scheduleHourOptions" :key="'end-hour-' + hour" :value="hour">{{ hour }}</option>
                            </select>
                            <select v-model="scheduleEndMinute">
                              <option v-for="minute in scheduleMinuteOptions" :key="'end-minute-' + minute" :value="minute">{{ minute }}</option>
                            </select>
                          </div>
                        </label>
                      </div>
                    </div>

                    <div class="detail-block">
                      <div class="detail-block-head">
                        <strong>面试题目</strong>
                        <span v-if="selectedInterview.interviewMode === 'preset'" class="status-text">预制面试支持在开始前调整题目内容。</span>
                      </div>
                      <div class="history-list">
                        <article v-for="question in selectedInterview.questions ?? []" :key="question.id" class="history-item">
                          <strong>Q{{ question.sortOrder }}</strong>
                          <template v-if="selectedInterview.interviewMode === 'preset'">
                            <textarea v-model="questionDrafts[question.id]" class="question-edit-input"></textarea>
                            <div class="inline-actions">
                              <small>{{ question.type || '默认题型' }}</small>
                              <button class="secondary-button simple" type="button" :disabled="isSavingQuestion(question.id)" @click="saveQuestion(question)">
                                {{ isSavingQuestion(question.id) ? '保存中...' : '保存题目' }}
                              </button>
                            </div>
                          </template>
                          <template v-else>
                            <p>{{ question.text }}</p>
                            <small>{{ question.type || '默认题型' }}</small>
                          </template>
                        </article>
                        <div v-if="!(selectedInterview.questions ?? []).length" class="empty-card">当前暂无题目。</div>
                      </div>
                    </div>

                    <div class="detail-block">
                      <strong>问答记录</strong>
                      <div class="history-list">
                        <article v-for="record in selectedInterview.qaRecords" :key="record.round" class="history-item">
                          <strong>Q{{ record.round }} / {{ record.question }}</strong>
                          <p>A{{ record.round }} / {{ record.answerTranscript }}</p>
                          <div v-if="record.mediaUrl" class="media-preview-block">
                            <video v-if="record.mediaType === 'video'" :src="record.mediaUrl" controls preload="metadata"></video>
                            <audio v-else :src="record.mediaUrl" controls preload="metadata"></audio>
                          </div>
                          <p v-if="record.analysisStatus" class="status-text">分析状态：{{ record.analysisStatus === 'completed' ? '分析完成' : (record.analysisStatus === 'processing' ? 'AI 分析中' : (record.analysisStatus === 'failed' ? '分析失败' : '等待分析')) }}</p>
                          <p v-if="record.toneAnalysis?.summary" class="status-text">语音分析：{{ record.toneAnalysis.summary }}</p>
                          <p v-if="record.bodyLanguageAnalysis?.summary" class="status-text">表情与肢体：{{ record.bodyLanguageAnalysis.summary }}</p>
                          <small>{{ record.durationSec }}</small>
                        </article>
                        <div v-if="!selectedInterview.qaRecords.length" class="empty-card">当前还没有答题记录。</div>
                      </div>
                    </div>

                    <div class="detail-block" v-if="selectedInterview.status === 'completed'">
                      <strong>报告处理</strong>
                      <div class="inline-actions">
                        <button
                          v-if="!selectedInterview.reportId"
                          class="secondary-button simple report-action-button"
                          type="button"
                          :disabled="reportGenerating"
                          @click="generateReport"
                        >
                          {{ reportGenerating ? '生成中...' : '生成报告' }}
                        </button>
                        <button
                          v-else
                          class="secondary-button simple report-action-button"
                          type="button"
                          @click="openReport(selectedInterview.reportId)"
                        >
                          打开对应报告
                        </button>
                        <span v-if="reportGenerating" class="status-text">报告生成可能需要几秒钟，请稍候。</span>
                        <button class="secondary-button simple report-action-button danger-action-button" type="button" @click="deleteCompletedInterview">删除面试</button>
                      </div>
                    </div>
                  </template>

                  <div v-else class="empty-card">请先从左侧面试列表中选择一场面试。</div>
                </div>
              </div>
            </SectionPanel>
          </template>

          <template v-else-if="activeModule === 'reports'">
            <SectionPanel title="报告中心" subtitle="查看结构化报告、进行评级并发送结果">
              <div class="two-column">
                <div class="list-column">
                  <button
                    v-for="report in reports"
                    :key="report.id"
                    class="list-row-button"
                    :class="{ active: selectedReportId === report.id }"
                    type="button"
                    @click="openReport(report.id)"
                  >
                    <strong>{{ report.job?.title }}</strong>
                    <span>{{ report.candidate?.name }} / {{ report.grade || '未评级' }}</span>
                  </button>
                  <div v-if="!reports.length" class="empty-card">当前还没有报告。</div>
                </div>

                <div class="detail-column">
                  <template v-if="selectedReport">
                    <div class="detail-summary">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseReportDetail">▴</button>
                      <h4>{{ selectedReport.job?.title }}</h4>
                      <p>{{ selectedReport.candidate?.name }} / 平均分 {{ selectedReport.average || reportAverage(selectedReport.scores) }}</p>
                      <div class="report-chip-row">
                        <span class="report-chip">报告时间：{{ formatReportDateTime(selectedReport.generatedAt) }}</span>
                        <span class="report-chip">面试轮次：{{ selectedReportInterview?.qaRecords?.length || 0 }} 轮</span>
                        <span class="report-chip">面试模式：{{ interviewModeLabel(selectedReportInterview?.interviewMode || 'preset') }}</span>
                        <span class="report-chip">当前评级：{{ selectedReport.grade || '未评级' }}</span>
                      </div>
                    </div>

                    <div class="score-grid">
                      <MetricCard label="专业技能" :value="selectedReport.scores.professional" hint="100 分制" />
                      <MetricCard label="沟通能力" :value="selectedReport.scores.communication" hint="100 分制" />
                      <MetricCard label="逻辑思维" :value="selectedReport.scores.logic" hint="100 分制" />
                      <MetricCard label="文化匹配" :value="selectedReport.scores.culture" hint="100 分制" />
                      <MetricCard label="表情与肢体" :value="selectedReport.scores.bodyLanguage" hint="100 分制" />
                    </div>

                    <div class="report-insight-grid">
                      <article v-for="item in selectedReportDimensions" :key="item.key" class="report-insight-card">
                        <span>{{ item.label }}</span>
                        <strong>{{ item.score ?? '--' }}</strong>
                        <em>{{ scoreBand(item.score) }}</em>
                        <p>{{ item.summary }}</p>
                      </article>
                    </div>

                    <div class="detail-block">
                      <strong>分析概览</strong>
                      <div class="analysis-overview-grid">
                        <article v-for="item in selectedReportAnalysisOverview" :key="item.label" class="analysis-overview-card">
                          <span>{{ item.label }}</span>
                          <strong>{{ item.value }}</strong>
                          <p>{{ item.hint }}</p>
                        </article>
                        <div v-if="!selectedReportAnalysisOverview.length" class="empty-card">当前还没有可引用的面试过程数据。</div>
                      </div>
                    </div>

                    <div class="detail-block">
                      <strong>回答摘要</strong>
                      <p>{{ selectedReport.summary }}</p>
                    </div>

                    <div class="detail-block">
                      <strong>亮点</strong>
                      <ul class="note-list">
                        <li v-for="item in selectedReport.highlights" :key="item">{{ item }}</li>
                      </ul>
                    </div>

                    <div class="detail-block">
                      <strong>风险点</strong>
                      <ul class="note-list">
                        <li v-for="item in selectedReport.risks" :key="item">{{ item }}</li>
                      </ul>
                    </div>

                    <div class="detail-block">
                      <strong>录用建议</strong>
                      <p>{{ selectedReport.recommendation }}</p>
                    </div>

                    <div class="detail-block">
                      <strong>多模态回答分析</strong>
                      <div class="note-list-block">
                        <article v-for="item in selectedReportMultimodalInsights" :key="item.key" class="report-evidence-card">
                          <strong>{{ item.title }}</strong>
                          <p>{{ item.text }}</p>
                        </article>
                        <div v-if="!selectedReportMultimodalInsights.length" class="empty-card">当前暂无可提取的语音、表情或肢体分析结果。</div>
                      </div>
                    </div>

                    <div class="detail-block">
                      <strong>逐轮作答证据</strong>
                      <div class="note-list-block">
                        <article v-for="item in selectedReportEvidenceRecords" :key="item.key" class="report-evidence-card">
                          <div class="report-evidence-head">
                            <strong>第 {{ item.round }} 题</strong>
                            <span>{{ item.modeLabel }}</span>
                          </div>
                          <p><b>问题：</b>{{ item.question }}</p>
                          <p><b>回答：</b>{{ item.answer }}</p>
                          <p v-if="item.analysis"><b>AI 分析：</b>{{ item.analysis }}</p>
                        </article>
                        <div v-if="!selectedReportEvidenceRecords.length" class="empty-card">当前暂无问答证据摘要。</div>
                      </div>
                    </div>

                    <div class="detail-block">
                      <strong>评级</strong>
                      <div class="inline-actions">
                        <button class="secondary-button simple" :class="{ active: selectedReport?.grade === 'S' }" type="button" @click="rateReport('S')">S</button>
                        <button class="secondary-button simple" :class="{ active: selectedReport?.grade === 'A' }" type="button" @click="rateReport('A')">A</button>
                        <button class="secondary-button simple" :class="{ active: selectedReport?.grade === 'B' }" type="button" @click="rateReport('B')">B</button>
                        <button class="secondary-button simple" :class="{ active: selectedReport?.grade === 'C' }" type="button" @click="rateReport('C')">C</button>
                        <span class="status-text">当前：{{ selectedReport.grade || '未评级' }}</span>
                      </div>
                    </div>

                    <div class="detail-block">
                      <div class="detail-block-head">
                        <strong>报告文件</strong>
                        <div class="detail-block-actions">
                          <button class="secondary-button simple" type="button" :disabled="reportDownloading" @click="downloadReport">
                            {{ reportDownloading ? '下载中...' : '下载 PDF 报告' }}
                          </button>
                        </div>
                      </div>
                      <p>导出当前面试报告，便于留档、发送与打印查看。</p>
                    </div>

                    <div class="detail-block">
                      <strong>发送结果反馈</strong>
                      <div class="outcome-choice-row">
                        <button
                          v-for="option in reportOutcomeOptions"
                          :key="option.value"
                          class="secondary-button simple"
                          :class="{ active: reportOutcomeChoice === option.value }"
                          type="button"
                          :disabled="selectedReportOutcomeSent"
                          @click="reportOutcomeChoice = option.value"
                        >
                          {{ option.label }}
                        </button>
                      </div>
                      <div class="detail-block outcome-preview-block">
                        <strong>发送预览</strong>
                        <p>{{ selectedReportOutcomePreview }}</p>
                      </div>
                      <div class="inline-actions">
                        <span class="status-text" v-if="selectedReportOutcomeSent">该报告的反馈结果已发送，不能再次发送。</span>
                        <button class="primary-button simple" type="button" :disabled="selectedReportOutcomeSent" @click="sendOutcome">发送反馈</button>
                      </div>
                    </div>
                  </template>

                  <div v-else class="empty-card">请先从左侧报告列表中选择一份报告。</div>
                </div>
              </div>
            </SectionPanel>
          </template>

          <template v-else-if="activeModule === 'messages'">
            <SectionPanel title="信息邮箱" subtitle="查看已有沟通渠道并发送补充消息">
              <MessageCenter
                :threads="threads"
                :users="store.state.users"
                :current-user-id="currentUser?.id"
                @send="sendMessage"
              />
            </SectionPanel>
          </template>
        </main>
      </div>

      <!-- 面试模式选择弹窗 -->
      <div v-if="showInterviewModeDialog" class="modal-overlay" @click.self="closeInterviewModeDialog">
        <div class="modal-card">
          <div class="modal-head">
            <h4>选择面试模式</h4>
            <button class="modal-close" type="button" aria-label="关闭" title="关闭" @click="closeInterviewModeDialog">×</button>
          </div>
          <div class="modal-body">
            <label class="radio-row">
              <input v-model="dialogInterviewMode" type="radio" value="preset" />
              <span>
                <strong>预制面试</strong>
                <small>创建时生成 5 道固定题目，按顺序作答</small>
              </span>
            </label>
            <label class="radio-row">
              <input v-model="dialogInterviewMode" type="radio" value="agent" />
              <span>
                <strong>Agent 面试</strong>
                <small>AI 根据历史回答动态生成下一题</small>
              </span>
            </label>
            <label v-if="dialogInterviewMode === 'agent'" class="form-row-lite">
              <span>最大轮数（3-10）</span>
              <input v-model.number="dialogMaxRounds" type="number" min="3" max="10" />
            </label>
          </div>
          <div class="modal-foot">
            <button class="secondary-button simple" type="button" @click="closeInterviewModeDialog">取消</button>
            <button
              class="primary-button simple"
              type="button"
              :disabled="isCreatingInterview(dialogJobId, dialogCandidateId)"
              @click="confirmCreateInterview"
            >
              {{ isCreatingInterview(dialogJobId, dialogCandidateId) ? '创建中...' : '确认创建' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  `
}

export const CandidatePage = {
  components: {
    AppHeader,
    InterviewSimulator,
    MessageCenter,
    ModuleNav,
    NotificationStack,
    SectionPanel
  },
  setup() {
    const store = useAppStore()
    const currentUser = store.currentUser
    const activeModule = ref('jobs')
    const selectedJobId = ref('')
    const selectedInterviewId = ref('')
    const applyMessage = ref('')
    const profileMessage = ref('')
    const applyingJobId = ref('')
    const avatarUploading = ref(false)
    const avatarInputRef = ref(null)
    const avatarFile = ref(null)
    const avatarFileName = ref('')
    const resumeInputRef = ref(null)
    const resumeFile = ref(null)
    const resumeFileName = ref('')
    const resumeUploadInputKey = ref(0)
    const avatarPreviewUrl = ref('')
    const avatarUploadInputKey = ref(0)
    const hasSeededIncomingMessages = ref(false)
    const seenIncomingMessageIds = new Set()
    let liveSyncTimer = null

    const jobFilters = reactive({
      keyword: '',
      salary: '',
      education: 'all',
      graduateType: 'all',
      maxExperience: 'all'
    })

    const profileForm = reactive({
      education: '本科',
      experienceYears: 0,
      graduateType: '应届',
      salaryExpectation: '12K-18K',
      skills: '',
      experienceSummary: ''
    })

    const modules = [
      { key: 'jobs', label: '岗位查看', hint: '筛选岗位并完成申请' },
      { key: 'profile', label: '个人信息', hint: '维护基础资料' },
      { key: 'interviews', label: '面试管理', hint: '查看安排并进入面试' },
      { key: 'messages', label: '信息邮箱', hint: '查看反馈消息' }
    ]

    const allJobs = computed(() => store.state.jobs.filter((job) => matchesJobFilters(job, jobFilters)))
    const appliedJobIds = computed(() => store.candidateApplications.value.map((item) => item.id))
    const myInterviews = store.currentCandidateInterviews
    const myThreads = store.messageThreads
    const notifications = store.notificationsForCurrentUser
    const selectedJob = computed(() => allJobs.value.find((item) => item.id === selectedJobId.value) ?? null)
    const selectedInterview = computed(
      () => myInterviews.value.find((item) => item.id === selectedInterviewId.value) ?? null
    )
    const avatarDisplayUrl = computed(() => avatarPreviewUrl.value || currentUser.value?.avatarUrl || '')
    const avatarFallbackText = computed(() => (currentUser.value?.name || '候').slice(0, 1))

    watch(
      currentUser,
      (user) => {
        const pendingNotice = loadPendingRegisterNotice()
        if (user && pendingNotice && pendingNotice.account === user.account) {
          store.pushNotification({
            userId: pendingNotice.userId || user.id,
            title: '注册成功',
            body: `系统已分配登录账号 ${pendingNotice.account}，请妥善保存。`
          })
          clearPendingRegisterNotice()
        }

        if (!user?.profile) {
          return
        }

        profileForm.education = user.profile.education || '本科'
        profileForm.experienceYears = user.profile.experienceYears ?? 0
        profileForm.graduateType = user.profile.graduateType || '应届'
        profileForm.salaryExpectation = user.profile.salaryExpectation || ''
        profileForm.skills = Array.isArray(user.profile.skills) ? user.profile.skills.join(', ') : ''
        profileForm.experienceSummary = user.profile.experienceSummary || ''
      },
      { immediate: true }
    )

    function hasApplied(jobId) {
      return appliedJobIds.value.includes(jobId)
    }

    function triggerResumePicker() {
      resumeInputRef.value?.click?.()
    }

    function handleResumeSelected(event) {
      const file = event?.target?.files?.[0]
      if (!file) {
        return
      }

      resumeFile.value = file
      resumeFileName.value = file.name
      applyMessage.value = ''
    }

    function clearResumeSelection() {
      resumeFile.value = null
      resumeFileName.value = ''
      resumeUploadInputKey.value += 1
    }

    async function applyToJob(jobId) {
      if (applyingJobId.value === jobId || hasApplied(jobId)) {
        return
      }

      applyingJobId.value = jobId
      applyMessage.value = ''
      try {
        const result = await store.applyToJob(jobId, resumeFile.value || null)
        applyMessage.value = result.message
        if (result.ok) {
          clearResumeSelection()
        }
      } finally {
        applyingJobId.value = ''
      }
    }

    async function saveProfile() {
      await store.updateCandidateProfile(profileForm)
      profileMessage.value = '个人信息已更新。'
    }

    function handleAvatarSelected(event) {
      const file = event?.target?.files?.[0]
      if (!file) {
        return
      }

      profileMessage.value = ''
      if (avatarPreviewUrl.value && typeof window !== 'undefined') {
        window.URL.revokeObjectURL(avatarPreviewUrl.value)
      }

      avatarFileName.value = file.name
      avatarFile.value = file
      avatarPreviewUrl.value = typeof window !== 'undefined' ? window.URL.createObjectURL(file) : ''
      uploadAvatar()
    }

    function triggerAvatarPicker() {
      avatarInputRef.value?.click?.()
    }

    async function uploadAvatar() {
      const file = avatarFile.value
      if (!file) {
        return
      }

      avatarUploading.value = true
      try {
        await store.uploadCandidateAvatar(file)
        store.pushNotification({
          userId: currentUser.value?.id,
          title: '头像已更新',
          body: '新的头像照片已保存。'
        })
        avatarFile.value = null
        avatarFileName.value = ''
        if (avatarPreviewUrl.value && typeof window !== 'undefined') {
          window.URL.revokeObjectURL(avatarPreviewUrl.value)
        }
        avatarPreviewUrl.value = ''
        avatarUploadInputKey.value += 1
      } catch (error) {
        avatarFile.value = null
        avatarFileName.value = ''
        if (avatarPreviewUrl.value && typeof window !== 'undefined') {
          window.URL.revokeObjectURL(avatarPreviewUrl.value)
        }
        avatarPreviewUrl.value = ''
        avatarUploadInputKey.value += 1
        store.pushNotification({
          userId: currentUser.value?.id,
          title: '头像上传失败',
          body: error instanceof Error ? error.message : '头像上传失败'
        })
      } finally {
        avatarUploading.value = false
      }
    }

    async function submitInterview(payload) {
      await store.submitVoiceAnswer(payload.interviewId, payload)
      await store.loadInterviewDetails(payload.interviewId)
    }

    async function openInterview(interviewId) {
      if (selectedInterviewId.value === interviewId) {
        selectedInterviewId.value = ''
        return
      }

      selectedInterviewId.value = interviewId
      activeModule.value = 'interviews'
      await store.loadInterviewDetails(interviewId)
    }

    function collapseJobDetail() {
      selectedJobId.value = ''
    }

    function collapseInterviewDetail() {
      selectedInterviewId.value = ''
    }

    function interviewModeLabel(mode) {
      return mode === 'agent' ? 'Agent 面试' : '预制面试'
    }

    function interviewModeBadgeClass(mode) {
      return mode === 'agent' ? 'mode-badge agent' : 'mode-badge preset'
    }

    async function sendMessage(payload) {
      await store.sendMessage(payload)
    }

    watch(
      myThreads,
      (threads) => {
        const incomingMessages = threads
          .flatMap((thread) => thread.messages ?? [])
          .filter((message) => message.senderId !== currentUser.value?.id)

        if (!hasSeededIncomingMessages.value) {
          incomingMessages.forEach((message) => seenIncomingMessageIds.add(message.id))
          hasSeededIncomingMessages.value = true
          return
        }

        incomingMessages.forEach((message) => {
          if (seenIncomingMessageIds.has(message.id)) {
            return
          }

          seenIncomingMessageIds.add(message.id)
          store.pushNotification({
            userId: currentUser.value?.id,
            title: '收到新消息',
            body: message.text
          })
        })
      },
      { deep: true, immediate: true }
    )

    if (typeof window !== 'undefined') {
      liveSyncTimer = window.setInterval(() => {
        store.refreshCandidateWorkspace().catch(() => {})
      }, 15000)
    }

    onBeforeUnmount(() => {
      if (avatarPreviewUrl.value && typeof window !== 'undefined') {
        window.URL.revokeObjectURL(avatarPreviewUrl.value)
      }
      if (liveSyncTimer) {
        window.clearInterval(liveSyncTimer)
      }
    })

    return {
      store,
      currentUser,
      activeModule,
      modules,
      jobFilters,
      allJobs,
      selectedJobId,
      selectedJob,
      selectedInterviewId,
      selectedInterview,
      myInterviews,
      myThreads,
      notifications,
      profileForm,
      applyMessage,
      profileMessage,
      applyingJobId,
      avatarUploading,
      avatarInputRef,
      avatarFileName,
      avatarPreviewUrl,
      avatarUploadInputKey,
      resumeInputRef,
      resumeFileName,
      resumeUploadInputKey,
      avatarDisplayUrl,
      avatarFallbackText,
      hasApplied,
      applyToJob,
      triggerResumePicker,
      handleResumeSelected,
      saveProfile,
      handleAvatarSelected,
      triggerAvatarPicker,
      uploadAvatar,
      submitInterview,
      openInterview,
      collapseJobDetail,
      collapseInterviewDetail,
      sendMessage,
      dismissNotification: store.dismissNotification,
      candidateStatusText,
      interviewModeLabel,
      interviewModeBadgeClass,
      preview,
      formatScheduleDisplay: store.formatScheduleDisplay
    }
  },
  template: `
    <div class="workspace-page">
      <AppHeader />

      <div class="workspace-layout">
        <ModuleNav
          :items="modules"
          :active-key="activeModule"
          title="面试者工作区"
          :subtitle="currentUser?.name || ''"
          @select="activeModule = $event"
        />

        <main class="workspace-main">
          <NotificationStack :items="notifications" @dismiss="dismissNotification" />
          <template v-if="activeModule === 'jobs'">
            <SectionPanel title="岗位查看" subtitle="筛选岗位、查看信息并完成申请">
              <div class="detail-block">
                <strong>登录账号</strong>
                <p>{{ currentUser?.account || '--' }}</p>
              </div>

              <div class="toolbar-row">
                <input v-model="jobFilters.keyword" placeholder="搜索岗位、标签或职责" />
                <input v-model="jobFilters.salary" placeholder="薪资范围，例如 18K" />
                <select v-model="jobFilters.education">
                  <option value="all">全部学历</option>
                  <option value="大专">大专</option>
                  <option value="本科">本科</option>
                  <option value="硕士">硕士</option>
                  <option value="博士">博士</option>
                </select>
                <select v-model="jobFilters.graduateType">
                  <option value="all">全部届别</option>
                  <option value="不限">不限</option>
                  <option value="应届">应届</option>
                  <option value="往届">往届</option>
                </select>
                <select v-model="jobFilters.maxExperience">
                  <option value="all">全部经验</option>
                  <option value="0">0 年以内</option>
                  <option value="1">1 年以内</option>
                  <option value="3">3 年以内</option>
                  <option value="5">5 年以内</option>
                </select>
              </div>

              <div class="two-column">
                <div class="list-column">
                  <button
                    v-for="job in allJobs"
                    :key="job.id"
                    class="list-row-button"
                    :class="{ active: selectedJobId === job.id }"
                    type="button"
                    @click="selectedJobId = selectedJobId === job.id ? '' : job.id"
                  >
                    <strong>{{ job.title }}</strong>
                    <span>{{ job.salaryRange }} / {{ hasApplied(job.id) ? '已申请' : '可申请' }}</span>
                  </button>
                  <div v-if="!allJobs.length" class="empty-card">当前没有符合筛选条件的岗位。</div>
                </div>

                <div class="detail-column">
                  <template v-if="selectedJob">
                    <div class="detail-summary">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseJobDetail">▴</button>
                      <h4>{{ selectedJob.title }}</h4>
                      <p>{{ selectedJob.salaryRange }} / {{ selectedJob.education }} / {{ selectedJob.experienceYears }} 年及以上</p>
                      <div class="tag-row">
                        <span v-for="tag in selectedJob.tags" :key="tag">{{ tag }}</span>
                      </div>
                    </div>

                    <div class="detail-block">
                      <strong>岗位职责</strong>
                      <p>{{ selectedJob.responsibilities }}</p>
                    </div>

                    <div class="detail-block">
                      <strong>职位要求</strong>
                      <p>{{ selectedJob.requirements }}</p>
                    </div>

                    <div class="detail-block">
                      <div class="detail-block-head">
                        <strong>申请简历</strong>
                        <div class="detail-block-actions">
                          <button class="secondary-button simple" type="button" :disabled="hasApplied(selectedJob.id)" @click="triggerResumePicker">
                            {{ resumeFileName ? '重新选择简历' : '上传简历' }}
                          </button>
                          <input
                            ref="resumeInputRef"
                            class="visually-hidden-input"
                            :key="resumeUploadInputKey"
                            type="file"
                            accept=".txt,.md,.pdf,.docx"
                            @change="handleResumeSelected"
                          />
                        </div>
                      </div>
                      <p>申请岗位时请同步提交简历，系统会结合简历内容生成面试官初步建议。</p>
                      <p class="status-text">{{ resumeFileName || '当前未选择简历文件，支持 TXT、MD、PDF、DOCX。' }}</p>
                    </div>

                    <button
                      class="primary-button simple"
                      type="button"
                      :disabled="hasApplied(selectedJob.id) || applyingJobId === selectedJob.id"
                      @click="applyToJob(selectedJob.id)"
                    >
                      {{ hasApplied(selectedJob.id) ? '已申请该岗位' : (applyingJobId === selectedJob.id ? '提交中...' : '申请该岗位') }}
                    </button>

                    <p v-if="applyMessage" class="feedback success">{{ applyMessage }}</p>
                  </template>

                  <div v-else class="empty-card">请先从左侧岗位列表中选择一个岗位。</div>
                </div>
              </div>
            </SectionPanel>
          </template>

          <template v-else-if="activeModule === 'profile'">
            <SectionPanel title="个人信息" subtitle="维护基础资料，便于岗位匹配与面试评估">
              <div class="profile-layout-simple">
                <div class="detail-block profile-identity-card">
                  <div class="profile-identity-body">
                    <button
                      class="avatar-preview-box avatar-preview-box-lg avatar-trigger-button"
                      type="button"
                      :disabled="avatarUploading"
                      @click="triggerAvatarPicker"
                    >
                        <img v-if="avatarDisplayUrl" :src="avatarDisplayUrl" alt="头像预览" class="avatar-preview-image" />
                        <span v-else>{{ avatarFallbackText }}</span>
                    </button>
                    <input
                      ref="avatarInputRef"
                      class="visually-hidden-input"
                      :key="avatarUploadInputKey"
                      type="file"
                      accept="image/*"
                      @change="handleAvatarSelected"
                    />
                    <div class="profile-identity-copy">
                      <h4>{{ currentUser?.name || '未命名面试者' }}</h4>
                      <p>登录账号：{{ currentUser?.account || '--' }}</p>
                      <p>点击头像即可上传或更换头像。</p>
                      <p v-if="avatarUploading" class="status-text">头像上传中...</p>
                    </div>
                  </div>
                </div>

                <div class="detail-block">
                  <div class="profile-form-head">
                    <strong>基础信息</strong>
                    <span>完善资料后，岗位匹配、问题生成与评估结果会更准确。</span>
                  </div>
                  <div class="form-grid-2">
                    <label>
                      学历
                      <select v-model="profileForm.education">
                        <option>大专</option>
                        <option>本科</option>
                        <option>硕士</option>
                        <option>博士</option>
                      </select>
                    </label>
                    <label>
                      工作经验
                      <input v-model="profileForm.experienceYears" type="number" min="0" max="20" />
                    </label>
                    <label>
                      应届 / 往届
                      <select v-model="profileForm.graduateType">
                        <option>应届</option>
                        <option>往届</option>
                      </select>
                    </label>
                    <label>
                      薪资期望
                      <input v-model="profileForm.salaryExpectation" />
                    </label>
                    <label class="full">
                      个人技能
                      <input v-model="profileForm.skills" placeholder="例如：Vue 3、Java、数据分析、项目推进" />
                    </label>
                    <label class="full">
                      个人经历
                      <textarea v-model="profileForm.experienceSummary" placeholder="填写项目经历、实习经历或擅长方向"></textarea>
                    </label>
                  </div>
                  <div class="inline-actions">
                    <span class="status-text">信息会同步用于岗位匹配、面试问题生成与报告展示。</span>
                    <button class="primary-button simple" type="button" @click="saveProfile">保存信息</button>
                  </div>
                </div>
              </div>

              <p v-if="profileMessage" class="feedback success">{{ profileMessage }}</p>
            </SectionPanel>
          </template>

          <template v-else-if="activeModule === 'interviews'">
            <SectionPanel title="面试管理" subtitle="查看安排并在开放时间内完成作答">
              <div class="two-column">
                <div class="list-column">
                  <button
                    v-for="item in myInterviews"
                    :key="item.id"
                    class="list-row-button"
                    :class="{ active: selectedInterviewId === item.id }"
                    type="button"
                    @click="openInterview(item.id)"
                  >
                    <strong>{{ store.findJob(item.jobId)?.title }}</strong>
                    <span>
                      <span :class="interviewModeBadgeClass(item.interviewMode)">{{ interviewModeLabel(item.interviewMode) }}</span>
                      {{ candidateStatusText(item) }}
                    </span>
                  </button>
                  <div v-if="!myInterviews.length" class="empty-card">当前还没有面试安排。</div>
                </div>

                <div class="detail-column">
                  <template v-if="selectedInterview">
                    <div class="detail-summary">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseInterviewDetail">▴</button>
                      <h4>{{ store.findJob(selectedInterview.jobId)?.title }}</h4>
                      <p>
                        <span :class="interviewModeBadgeClass(selectedInterview.interviewMode)">{{ interviewModeLabel(selectedInterview.interviewMode) }}</span>
                        {{ candidateStatusText(selectedInterview) }}
                      </p>
                    </div>

                    <div v-if="selectedInterview.status === 'scheduled'" class="detail-block">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseInterviewDetail">▴</button>
                      <strong>开放时间</strong>
                      <p>开始：{{ formatScheduleDisplay(selectedInterview.openTimeStart) }}</p>
                      <p>结束：{{ formatScheduleDisplay(selectedInterview.openTimeEnd) }}</p>
                    </div>

                    <InterviewSimulator
                      v-else-if="selectedInterview.status === 'in_progress'"
                      :interview="selectedInterview"
                      @submit="submitInterview"
                    />

                    <div v-else-if="selectedInterview.status === 'completed'" class="detail-block">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseInterviewDetail">▴</button>
                      <strong>面试已结束</strong>
                      <div class="history-list">
                        <article v-for="record in selectedInterview.qaRecords" :key="record.round" class="history-item">
                          <strong>Q{{ record.round }} / {{ preview(record.question, 120) }}</strong>
                          <p>A{{ record.round }} / {{ preview(record.answerTranscript, 140) }}</p>
                          <div v-if="record.mediaUrl" class="media-preview-block">
                            <video v-if="record.mediaType === 'video'" :src="record.mediaUrl" controls preload="metadata"></video>
                            <audio v-else :src="record.mediaUrl" controls preload="metadata"></audio>
                          </div>
                          <p v-if="record.analysisStatus" class="status-text">分析状态：{{ record.analysisStatus === 'completed' ? '分析完成' : (record.analysisStatus === 'processing' ? 'AI 分析中' : (record.analysisStatus === 'failed' ? '分析失败' : '等待分析')) }}</p>
                          <p v-if="record.toneAnalysis?.summary" class="status-text">语音分析：{{ record.toneAnalysis.summary }}</p>
                          <p v-if="record.bodyLanguageAnalysis?.summary" class="status-text">表情与肢体：{{ record.bodyLanguageAnalysis.summary }}</p>
                          <small>{{ record.durationSec }}</small>
                        </article>
                      </div>
                    </div>

                    <div v-else class="detail-block">
                      <button class="collapse-icon-button" type="button" aria-label="收起详情" title="收起详情" @click="collapseInterviewDetail">▴</button>
                      <strong>当前状态</strong>
                      <p>{{ candidateStatusText(selectedInterview) }}</p>
                    </div>
                  </template>

                  <div v-else class="empty-card">请先从左侧面试列表中选择一场面试。</div>
                </div>
              </div>
            </SectionPanel>
          </template>

          <template v-else-if="activeModule === 'messages'">
            <SectionPanel title="信息邮箱" subtitle="查看系统内的沟通消息">
              <MessageCenter
                :threads="myThreads"
                :users="store.state.users"
                :current-user-id="currentUser?.id"
                @send="sendMessage"
              />
            </SectionPanel>
          </template>
        </main>
      </div>
    </div>
  `
}




