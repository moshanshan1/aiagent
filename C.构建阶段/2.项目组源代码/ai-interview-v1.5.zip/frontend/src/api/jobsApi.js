import { request } from './httpClient.js?v=20260716g'
import { mapApplicantFromApi, mapJobDocumentFromApi, mapJobFromApi } from './mappers.js?v=20260716g'

function unwrapPagedItems(response, mapper) {
  return {
    ...response,
    data: {
      ...response.data,
      items: Array.isArray(response.data.items) ? response.data.items.map(mapper) : []
    }
  }
}

export async function createJob(payload) {
  const response = await request('/jobs', {
    method: 'POST',
    body: {
      title: payload.title,
      salary_range: payload.salaryRange,
      education_requirement: payload.education,
      work_experience_requirement: payload.experienceYears,
      fresh_requirement: payload.graduateType,
      work_content: payload.responsibilities,
      position_requirements: payload.requirements
    }
  })

  return {
    ...response,
    data: mapJobFromApi(response.data)
  }
}

export async function listJobs(filters = {}) {
  const response = await request('/jobs', {
    query: {
      page: filters.page,
      size: filters.size,
      title: filters.keyword,
      education_requirement: filters.education,
      work_experience_requirement: filters.minExperience,
      fresh_requirement: filters.graduateType,
      sort: filters.sort,
      order: filters.order
    }
  })

  return unwrapPagedItems(response, mapJobFromApi)
}

export async function getJob(jobId) {
  const response = await request(`/jobs/${jobId}`)
  return {
    ...response,
    data: mapJobFromApi(response.data)
  }
}

export async function updateJob(jobId, payload) {
  const response = await request(`/jobs/${jobId}`, {
    method: 'PUT',
    body: {
      title: payload.title,
      salary_range: payload.salaryRange,
      education_requirement: payload.education,
      work_experience_requirement: payload.experienceYears,
      fresh_requirement: payload.graduateType,
      work_content: payload.responsibilities,
      position_requirements: payload.requirements
    }
  })

  return {
    ...response,
    data: mapJobFromApi(response.data)
  }
}

export async function deleteJob(jobId) {
  return request(`/jobs/${jobId}`, {
    method: 'DELETE'
  })
}

export async function listApplicants(jobId, options = {}) {
  const response = await request(`/jobs/${jobId}/applicants`, {
    query: {
      page: options.page,
      size: options.size
    }
  })

  return unwrapPagedItems(response, mapApplicantFromApi)
}

export async function createApplicantMessageChannel(jobId, intervieweeId) {
  return request(`/jobs/${jobId}/applicants/${intervieweeId}/message-channel`, {
    method: 'POST'
  })
}

export async function applyToJob(jobId, resumeFile = null) {
  const formData = new FormData()
  if (resumeFile) {
    formData.append('resume_file', resumeFile)
  }

  return request(`/jobs/${jobId}/apply`, {
    method: 'POST',
    body: formData
  })
}

export async function uploadJobDocument(jobId, file, title = '') {
  const formData = new FormData()
  formData.append('file', file)
  if (title) {
    formData.append('title', title)
  }

  const response = await request(`/jobs/${jobId}/jd-documents`, {
    method: 'POST',
    body: formData
  })

  return {
    ...response,
    data: mapJobDocumentFromApi(response.data)
  }
}

export async function listJobDocuments(jobId) {
  const response = await request(`/jobs/${jobId}/jd-documents`)

  return {
    ...response,
    data: {
      ...response.data,
      items: Array.isArray(response.data.items) ? response.data.items.map(mapJobDocumentFromApi) : [],
      total: Number(response.data.total ?? 0)
    }
  }
}




