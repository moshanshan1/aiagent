import { clearStoredAccessToken, setStoredAccessToken } from './config.js?v=20260716g'
import { request } from './httpClient.js?v=20260716g'
import { mapUserFromApi } from './mappers.js?v=20260716g'

export async function registerCandidate(payload) {
  const response = await request('/auth/register', {
    method: 'POST',
    auth: false,
    body: {
      name: payload.name,
      password: payload.password
    }
  })

  return {
    ...response,
    data: {
      account: response.data.account,
      name: response.data.name,
      role: response.data.role
    }
  }
}

export async function login(payload) {
  const response = await request('/auth/login', {
    method: 'POST',
    auth: false,
    body: {
      account: payload.account,
      password: payload.password
    }
  })

  setStoredAccessToken(response.data.access_token)

  return {
    ...response,
    data: {
      accessToken: response.data.access_token,
      tokenType: response.data.token_type,
      expiresIn: response.data.expires_in,
      user: mapUserFromApi(response.data.user)
    }
  }
}

export async function fetchCurrentUser() {
  const response = await request('/auth/me')
  return {
    ...response,
    data: mapUserFromApi(response.data)
  }
}

export async function updateCurrentUserProfile(profile) {
  return request('/auth/me/profile', {
    method: 'PUT',
    body: {
      education: profile.education,
      work_experience: profile.experienceYears,
      is_fresh: profile.graduateType,
      salary_expectation: profile.salaryExpectation,
      skills: Array.isArray(profile.skills) ? profile.skills.join(', ') : profile.skills,
      experience: profile.experienceSummary
    }
  })
}

export async function uploadAvatar(file) {
  const formData = new FormData()
  formData.append('avatar', file)

  return request('/auth/me/avatar', {
    method: 'POST',
    body: formData
  })
}

export function logout() {
  clearStoredAccessToken()
}




