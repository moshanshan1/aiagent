import { request } from './httpClient.js?v=20260716g'
import { mapReportFromApi } from './mappers.js?v=20260716g'

function unwrapPagedReports(response) {
  return {
    ...response,
    data: {
      ...response.data,
      items: Array.isArray(response.data.items) ? response.data.items.map(mapReportFromApi) : []
    }
  }
}

export async function generateInterviewReport(interviewId) {
  const response = await request(`/reports/${interviewId}/generate`, {
    method: 'POST'
  })

  return {
    ...response,
    data: mapReportFromApi(response.data)
  }
}

export async function listReports(filters = {}) {
  const response = await request('/reports', {
    query: {
      page: filters.page,
      size: filters.size,
      sort: filters.sort,
      order: filters.order,
      job_id: filters.jobId,
      rating: filters.rating,
      interviewee_name: filters.candidateName
    }
  })

  return unwrapPagedReports(response)
}

export async function getReport(reportId) {
  const response = await request(`/reports/${reportId}`)
  return {
    ...response,
    data: mapReportFromApi(response.data)
  }
}

export async function rateReport(reportId, rating) {
  return request(`/reports/${reportId}/rating`, {
    method: 'PUT',
    body: {
      rating
    }
  })
}

export async function downloadReportPdf(reportId) {
  return request(`/reports/${reportId}/download`, {
    responseType: 'blob'
  })
}

export async function createReportMessageChannel(reportId) {
  return request(`/reports/${reportId}/message-channel`, {
    method: 'POST'
  })
}




