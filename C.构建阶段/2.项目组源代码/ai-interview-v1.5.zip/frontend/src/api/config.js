import { getTabSessionValue, setTabSessionValue } from '../utils/tabSession.js?v=20260717a'

export const API_BASE_URL =
  globalThis.__AI_INTERVIEW_API_BASE_URL__ ?? 'http://127.0.0.1:8000/api'

export const TOKEN_STORAGE_KEY = 'ai-interview-api-access-token'

export function getStoredAccessToken() {
  return getTabSessionValue(TOKEN_STORAGE_KEY) ?? ''
}

export function setStoredAccessToken(token) {
  setTabSessionValue(TOKEN_STORAGE_KEY, token || '')
}

export function clearStoredAccessToken() {
  setStoredAccessToken('')
}




