﻿import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useAppStore } from '../store/appStore.js?v=20260717a'

export const MetricCard = {
  props: {
    label: String,
    value: [String, Number],
    hint: String
  },
  template: `
    <article class="metric-card-lite">
      <span class="metric-label-lite">{{ label }}</span>
      <strong class="metric-value-lite">{{ value ?? '--' }}</strong>
      <p class="metric-hint-lite">{{ hint }}</p>
    </article>
  `
}

export const SectionPanel = {
  props: {
    title: String,
    subtitle: String,
    compact: {
      type: Boolean,
      default: false
    }
  },
  template: `
    <section class="panel-card" :class="{ compact }">
      <header v-if="title || subtitle" class="panel-head">
        <div>
          <h3 v-if="title">{{ title }}</h3>
          <p v-if="subtitle">{{ subtitle }}</p>
        </div>
        <slot name="actions" />
      </header>
      <div class="panel-body">
        <slot />
      </div>
    </section>
  `
}

export const AppHeader = {
  setup() {
    const router = useRouter()
    const store = useAppStore()
    const refreshing = ref(false)

    const roleLabel = computed(() => {
      const role = store.currentUser.value?.role
      if (role === 'interviewer') return '面试官'
      if (role === 'candidate') return '面试者'
      return '未登录'
    })

    function goHome() {
      const user = store.currentUser.value
      if (!user) {
        router.push('/')
        return
      }
      router.push(user.role === 'interviewer' ? '/interviewer' : '/candidate')
    }

    function logout() {
      store.logout()
      router.push('/')
    }

    async function handleRefresh() {
      if (refreshing.value) {
        return
      }

      refreshing.value = true
      try {
        await store.resetDemo()
      } finally {
        refreshing.value = false
      }
    }

    return {
      store,
      roleLabel,
      goHome,
      logout,
      refreshing,
      handleRefresh
    }
  },
  template: `
    <header class="app-header-lite">
      <button class="brand-button" type="button" @click="goHome">
        <span class="brand-mark">AI</span>
        <span class="brand-copy">
          <strong>AI面试官与人才评估系统</strong>
          <small>统一工作台</small>
        </span>
      </button>

      <div class="header-user-block">
        <div v-if="store.currentUser.value" class="user-summary">
          <strong>{{ store.currentUser.value.name }}</strong>
          <span>{{ roleLabel }} / 账号 {{ store.currentUser.value.account }}</span>
        </div>
        <button class="text-button" type="button" :disabled="refreshing" @click="handleRefresh">
          {{ refreshing ? '刷新中...' : '刷新数据' }}
        </button>
        <button v-if="store.currentUser.value" class="primary-button simple" type="button" @click="logout">
          退出登录
        </button>
      </div>
    </header>
  `
}

export const ModuleNav = {
  props: {
    items: {
      type: Array,
      default: () => []
    },
    activeKey: String,
    title: String,
    subtitle: String
  },
  emits: ['select'],
  template: `
    <aside class="module-nav">
      <div class="module-nav-head">
        <strong>{{ title }}</strong>
        <span>{{ subtitle }}</span>
      </div>

      <button
        v-for="item in items"
        :key="item.key"
        class="module-nav-item"
        :class="{ active: item.key === activeKey }"
        type="button"
        @click="$emit('select', item.key)"
      >
        <strong>{{ item.label }}</strong>
        <span>{{ item.hint }}</span>
      </button>
    </aside>
  `
}

export const NotificationStack = {
  props: {
    items: {
      type: Array,
      default: () => []
    }
  },
  emits: ['dismiss'],
  template: `
    <div v-if="items.length" class="notice-list-stack">
      <div v-for="item in items" :key="item.id" class="notice-bar prominent success-banner">
        <div class="success-banner-copy">
          <strong>{{ item.title }}</strong>
          <span>{{ item.body }}</span>
        </div>
        <button
          class="success-banner-close"
          type="button"
          aria-label="关闭消息"
          title="关闭消息"
          @click="$emit('dismiss', item.id)"
        >
          ×
        </button>
      </div>
    </div>
  `
}

export const MessageCenter = {
  props: {
    threads: {
      type: Array,
      default: () => []
    },
    users: {
      type: Array,
      default: () => []
    },
    currentUserId: String,
    allowCreate: {
      type: Boolean,
      default: false
    }
  },
  emits: ['send'],
  setup(props, { emit }) {
    const activeThreadId = ref(props.threads[0]?.id ?? '')
    const draft = ref('')
    const selectedCandidateId = ref('')

    watch(
      () => props.threads,
      (threads) => {
        if (!threads.find((item) => item.id === activeThreadId.value)) {
          activeThreadId.value = threads[0]?.id ?? ''
        }
      },
      { deep: true, immediate: true }
    )

    const activeThread = computed(
      () => props.threads.find((item) => item.id === activeThreadId.value) ?? null
    )

    function labelForMessage(message) {
      return (
        message.senderLabel ||
        props.users.find((user) => user.id === message.senderId)?.name ||
        '系统'
      )
    }

    function submitMessage() {
      if (!draft.value.trim() || (!activeThread.value && !selectedCandidateId.value)) {
        return
      }

      emit('send', {
        threadId: activeThread.value?.id,
        candidateId: selectedCandidateId.value || activeThread.value?.candidateId,
        text: draft.value
      })

      draft.value = ''
      selectedCandidateId.value = ''
    }

    return {
      activeThreadId,
      activeThread,
      draft,
      selectedCandidateId,
      labelForMessage,
      submitMessage
    }
  },
  template: `
    <div class="message-layout">
      <div class="message-thread-list">
        <div class="message-list-head">
          <strong>会话列表</strong>
          <span>{{ threads.length }} 条</span>
        </div>

        <button
          v-for="thread in threads"
          :key="thread.id"
          class="message-thread-item"
          :class="{ active: thread.id === activeThreadId }"
          type="button"
          @click="activeThreadId = thread.id"
        >
          <strong>{{ thread.title }}</strong>
          <span>{{ thread.messages[thread.messages.length - 1]?.text ?? '暂无消息' }}</span>
        </button>

        <div v-if="!threads.length" class="empty-card">当前还没有可查看的会话。</div>
      </div>

      <div class="message-main">
        <div class="message-list-head message-main-head">
          <strong>{{ activeThread ? activeThread.title : '消息内容' }}</strong>
          <span>{{ activeThread ? '查看往来消息并继续沟通' : '从左侧选择一个会话后查看消息' }}</span>
        </div>

        <div v-if="allowCreate" class="message-toolbar">
          <select v-model="selectedCandidateId">
            <option value="">发送到当前会话</option>
            <option
              v-for="user in users.filter((item) => item.role === 'candidate')"
              :key="user.id"
              :value="user.id"
            >
              与 {{ user.name }} 新建会话
            </option>
          </select>
        </div>

        <div class="message-stream">
          <div
            v-for="message in activeThread?.messages ?? []"
            :key="message.id"
            class="message-bubble-lite"
            :class="{ mine: message.senderId === currentUserId }"
          >
            <strong>{{ labelForMessage(message) }}</strong>
            <p>{{ message.text }}</p>
            <small>{{ message.time }}</small>
          </div>

          <div v-if="activeThread && !(activeThread.messages?.length)" class="empty-card">当前会话暂无消息。</div>
          <div v-if="!activeThread" class="empty-card">请先在左侧选择一个会话。</div>
        </div>

        <div class="message-composer-lite">
          <textarea v-model="draft" placeholder="输入站内消息"></textarea>
          <button
            class="primary-button simple"
            type="button"
            :disabled="!draft.trim() || (!activeThread && !selectedCandidateId)"
            @click="submitMessage"
          >
            发送消息
          </button>
        </div>
      </div>
    </div>
  `
}

export const InterviewSimulator = {
  props: {
    interview: Object
  },
  emits: ['submit'],
  setup(props, { emit }) {
    const store = useAppStore()
    const phase = ref('idle')
    const timeLeft = ref(props.interview?.responseLimitSec ?? 90)
    const recorderError = ref('')
    const audioReady = ref(false)
    const isSubmitting = ref(false)
    const mediaMode = ref('audio')

    let timerId = null
    let mediaRecorder = null
    let mediaStream = null
    let audioChunks = []
    let audioBlob = null
    const refreshLockReason = 'candidate-interview-recording'

    function clearTimer() {
      if (timerId) {
        clearInterval(timerId)
        timerId = null
      }
    }

    function stopTracks() {
      if (mediaStream) {
        mediaStream.getTracks().forEach((track) => track.stop())
        mediaStream = null
      }
    }

    function resetLocalState() {
      // 录音中不重置，防止中断录制
      if (phase.value === 'recording' || phase.value === 'review') return
      store.resumeAutoRefresh(refreshLockReason)
      clearTimer()
      stopTracks()
      phase.value = 'idle'
      timeLeft.value = props.interview?.responseLimitSec ?? 90
      recorderError.value = ''
      audioReady.value = false
      isSubmitting.value = false
      mediaMode.value = 'audio'
      audioChunks = []
      audioBlob = null
      mediaRecorder = null
    }

    watch(
      () => [props.interview?.id, props.interview?.round, props.interview?.activeQuestion?.text],
      resetLocalState,
      { immediate: true }
    )

    onBeforeUnmount(() => {
      store.resumeAutoRefresh(refreshLockReason)
      clearTimer()
      stopTracks()
    })

    async function startRecording() {
      if (!props.interview?.activeQuestion || phase.value === 'recording' || phase.value === 'submitting') {
        return
      }

      recorderError.value = ''
      audioReady.value = false
      audioChunks = []
      audioBlob = null

      try {
        mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: mediaMode.value === 'video'
        })
        store.pauseAutoRefresh(refreshLockReason)
      } catch (error) {
        recorderError.value = error instanceof Error ? error.message : '无法访问麦克风。'
        return
      }

      const preferredMimeTypes = mediaMode.value === 'video'
        ? ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4']
        : ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4']
      const mimeType = preferredMimeTypes.find(
        (item) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(item)
      )

      try {
        mediaRecorder = mimeType
          ? new MediaRecorder(mediaStream, { mimeType })
          : new MediaRecorder(mediaStream)
      } catch (error) {
        stopTracks()
        recorderError.value = error instanceof Error ? error.message : '录音初始化失败。'
        return
      }

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunks.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        audioBlob = audioChunks.length
          ? new Blob(audioChunks, { type: mediaRecorder?.mimeType || 'audio/webm' })
          : null
        audioReady.value = Boolean(audioBlob && audioBlob.size > 0)
        stopTracks()
      }

      mediaRecorder.start()
      phase.value = 'recording'
      clearTimer()

      timerId = setInterval(() => {
        timeLeft.value -= 1
        if (timeLeft.value <= 0) {
          timeLeft.value = 0
          stopRecording()
        }
      }, 1000)
    }

    function stopRecording() {
      if (phase.value !== 'recording') {
        return
      }

      clearTimer()
      if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop()
      } else {
        stopTracks()
      }
      phase.value = 'review'
    }

    function submitAnswer() {
      if (!audioBlob) {
        recorderError.value = '请先完成录音，再提交本题。'
        return
      }

      const durationSec = Math.max(1, (props.interview?.responseLimitSec ?? 90) - timeLeft.value)
      isSubmitting.value = true
      phase.value = 'submitting'
      emit('submit', {
        interviewId: props.interview.id,
        mediaBlob: audioBlob,
        mediaMode: mediaMode.value,
        transcript: '',
        durationSec
      })
    }

    function analysisStatusLabel(status) {
      const map = {
        pending: '等待分析',
        processing: 'AI 分析中',
        completed: '分析完成',
        failed: '分析失败'
      }

      return map[status] ?? '已提交'
    }

    return {
      phase,
      timeLeft,
      recorderError,
      audioReady,
      isSubmitting,
      mediaMode,
      startRecording,
      stopRecording,
      submitAnswer,
      analysisStatusLabel
    }
  },
  template: `
    <div v-if="interview" class="simulator-card">
      <div class="simulator-top">
        <div>
          <strong>当前第 {{ interview.round }} / {{ interview.maxRounds }} 题</strong>
          <p>支持视频作答或仅音频作答，提交后系统会继续生成下一题。</p>
        </div>
        <span class="timer-badge">{{ timeLeft }}s</span>
      </div>

      <div class="history-list">
        <article v-for="record in interview.qaRecords" :key="record.round" class="history-item">
          <strong>Q{{ record.round }} / {{ record.question }}</strong>
          <p>A{{ record.round }} / {{ record.answerTranscript }}</p>
          <div v-if="record.mediaUrl" class="media-preview-block">
            <video v-if="record.mediaType === 'video'" :src="record.mediaUrl" controls preload="metadata"></video>
            <audio v-else :src="record.mediaUrl" controls preload="metadata"></audio>
          </div>
          <p v-if="record.analysisStatus" class="status-text">分析状态：{{ analysisStatusLabel(record.analysisStatus) }}</p>
          <p v-if="record.toneAnalysis?.summary" class="status-text">语音分析：{{ record.toneAnalysis.summary }}</p>
          <p v-if="record.bodyLanguageAnalysis?.summary" class="status-text">表情与肢体：{{ record.bodyLanguageAnalysis.summary }}</p>
          <small v-if="record.durationSec">作答时长 {{ record.durationSec }}</small>
        </article>
        <div v-if="!interview.qaRecords.length" class="empty-card">当前还没有历史问答记录。</div>
      </div>

      <div v-if="interview.activeQuestion" class="answer-box">
        <div class="current-question-box">
          <span>当前题目</span>
          <h4>{{ interview.activeQuestion.text }}</h4>
          <p>来源：{{ interview.activeQuestion.source }}</p>
        </div>

        <div class="media-mode-row">
          <button class="secondary-button simple" :class="{ active: mediaMode === 'audio' }" type="button" :disabled="phase === 'recording' || phase === 'submitting'" @click="mediaMode = 'audio'">仅音频</button>
          <button class="secondary-button simple" :class="{ active: mediaMode === 'video' }" type="button" :disabled="phase === 'recording' || phase === 'submitting'" @click="mediaMode = 'video'">视频作答</button>
        </div>
        <div class="answer-actions">
          <button v-if="phase === 'idle'" class="primary-button simple" type="button" @click="startRecording">{{ mediaMode === 'video' ? '开始录像' : '开始录音' }}</button>
          <button v-if="phase === 'recording'" class="secondary-button simple" type="button" @click="stopRecording">{{ mediaMode === 'video' ? '结束录像' : '结束录音' }}</button>
          <button v-if="phase === 'review'" class="primary-button simple" type="button" :disabled="!audioReady" @click="submitAnswer">提交回答</button>
          <button v-if="phase === 'submitting'" class="primary-button simple" type="button" disabled>提交中...</button>
        </div>

        <p v-if="recorderError" class="feedback error">{{ recorderError }}</p>
        <p v-if="audioReady" class="feedback success">{{ mediaMode === 'video' ? '视频已完成，可以提交本题。' : '录音已完成，可以提交本题。' }}</p>
      </div>
    </div>
  `
}




