# AI 面试官与人才评估系统

基于 FastAPI + Vue 3 的 AI 驱动面试与人才评估平台，支持语音/视频作答、AI 自动追问、多维度评估报告。

## 技术栈

| 层级 | 技术 |
|------|------|
| 前端 | Vue 3 (ESM + importmap, 免构建)、Nginx |
| 后端 | Python FastAPI、SQLAlchemy、PyMySQL |
| 数据库 | MySQL 8.4 |
| AI | DashScope Qwen-Omni (语音转写/语调/视频分析)、DeepSeek / Qwen (文本分析) |
| 容器化 | Docker Compose |

## 快速开始

### 方式一：Docker（推荐）

确保 Docker Desktop 已启动，双击 `start-docker.bat` 或运行：

```bash
docker compose up -d --build --wait
```

访问 http://localhost:8080

### 方式二：本地开发

**后端：**

```bash
cd backend
pip install -r requirements.txt
# 修改 .env 中的数据库连接
python init_db.py    # 初始化数据库
python main.py       # 启动 http://localhost:8000
```

**前端：**

```bash
cd ai-interview-frontend
python -m http.server 4173
# 访问 http://127.0.0.1:4173
```

## 项目结构

```
├── compose.yaml                 # Docker Compose 编排
├── start-docker.bat             # Docker 启动脚本
├── stop-docker.bat              # Docker 停止脚本
├── backend/                     # FastAPI 后端
│   ├── main.py                  # 应用入口
│   ├── config.py                # 配置
│   ├── database.py              # 数据库连接
│   ├── init_db.py               # 数据库初始化
│   ├── requirements.txt         # Python 依赖
│   ├── .env                     # 环境变量
│   ├── Dockerfile               # 后端 Docker 构建
│   ├── models/                  # 数据模型
│   ├── schemas/                 # Pydantic 请求/响应
│   ├── routers/                 # API 路由
│   ├── services/                # 业务逻辑
│   ├── ai/                      # AI 模块
│   └── utils/                   # 工具
└── ai-interview-frontend/       # Vue 3 前端
    ├── Dockerfile               # 前端 Docker 构建
    ├── nginx.conf               # Nginx 反向代理配置
    ├── index.html               # 入口页面
    └── src/                     # 源码
```

## Docker 部署架构

```
浏览器 → :8080 → Nginx (frontend)
  ├── /api/*       → 反向代理 → backend:8000
  ├── /uploads/*   → 反向代理 → backend:8000
  └── /*           → 静态文件
```

三个服务：db (MySQL 8.4) → backend (Python FastAPI) → frontend (Nginx)，顺序启动。

## 默认账号

| 角色 | 账号 | 密码 |
|------|------|------|
| 面试官 | 000001 | admin123 |
| 面试官 | 000002 | admin123 |
| 面试者 | 注册获取 | 自行设置 |

## API 概览

| 模块 | 路径前缀 | 说明 |
|------|----------|------|
| 认证 | `/api/auth` | 注册、登录、个人信息 |
| 岗位 | `/api/jobs` | 岗位 CRUD、报名、意向仓库 |
| 面试 | `/api/interviews` | 创建面试、签到、语音/视频答题 |
| 报告 | `/api/reports` | 生成报告、评级、下载 PDF |
| 通讯 | `/api/messages` | 通讯渠道、消息收发 |

启动后端后访问 `http://localhost:8000/docs` 查看 Swagger 文档。

## 环境变量

复制 `backend/.env.example` 为 `backend/.env` 并配置：

| 变量 | 说明 |
|------|------|
| `DB_PASSWORD` | MySQL 密码 |
| `DASHSCOPE_API_KEY` | DashScope API Key（Omni 多模态） |
| `LLM_API_KEY` | 文本模型 API Key |
| `LLM_BASE_URL` | 文本模型接口地址 |
| `LLM_MODEL` | 文本模型名称 |
