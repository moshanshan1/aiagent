@echo off
setlocal
cd /d "%~dp0"

docker info >nul 2>&1
if errorlevel 1 (
  echo Docker Desktop is not running. Start Docker Desktop and try again.
  pause
  exit /b 1
)

docker compose up -d --build --wait
if errorlevel 1 (
  echo Failed to start the application. Run "docker compose logs" for details.
  pause
  exit /b 1
)

echo Application started at http://localhost:8080
start "" http://localhost:8080
endlocal
