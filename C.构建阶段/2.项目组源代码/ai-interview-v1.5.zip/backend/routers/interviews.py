"""面试路由"""

import asyncio
import json
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, Query, Response, UploadFile
from sqlalchemy.orm import Session

from ai.agent_chain import generate_next_question
from database import get_db
from models.user import User
from schemas.interview import InterviewCreate, OpenTimeUpdate, QuestionUpdate
from services.interview_service import (
    build_qa_history,
    check_in,
    create_interview,
    get_answers,
    get_interview,
    get_interviews,
    update_open_time,
    update_question,
)
from services.message_service import create_channel
from services.voice_analysis_service import analyze_media_async
from utils.file_storage import save_media
from utils.security import get_current_user, require_interviewer

router = APIRouter(prefix="/interviews", tags=["面试"])


def _is_invalid_transcript(text: str) -> bool:
    if not isinstance(text, str):
        return True

    stripped = text.strip()
    if not stripped:
        return True

    invalid_markers = [
        "[",
        "分析失败",
        "文件不存在",
        "模型返回为空",
        "Error code:",
        "access_denied",
        "Workspace endpoint access denied",
        "服务未配置",
    ]
    return any(marker in stripped for marker in invalid_markers)


@router.post("", status_code=201)
def create(
    req: InterviewCreate,
    response: Response,
    user: User = Depends(require_interviewer),
    db: Session = Depends(get_db),
):
    interview, created = create_interview(
        db, req.job_id, req.interviewee_id, user.id,
        interview_mode=req.interview_mode, max_rounds=req.max_rounds
    )
    if not created:
        response.status_code = 200
        return {"code": 200, "data": _interview_to_dict(interview), "message": "已存在可用面试，已直接返回当前面试"}
    return {"code": 201, "data": _interview_to_dict(interview), "message": "面试创建成功，AI已生成5道问题"}


@router.get("")
def list_interviews(
    status: Optional[str] = None,
    job_id: Optional[int] = None,
    sort: Optional[str] = "created_at",
    order: Optional[str] = "desc",
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    filters = {"status": status, "job_id": job_id, "sort": sort, "order": order}
    result = get_interviews(db, user, filters, page, size)
    items = [_interview_to_dict(item) for item in result["items"]]
    return {"code": 200, "data": {"items": items, "total": result["total"], "page": page, "size": size}, "message": "ok"}


@router.get("/{interview_id}")
def get_detail(interview_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    interview = get_interview(db, interview_id)
    return {"code": 200, "data": _interview_to_dict(interview), "message": "ok"}


@router.put("/{interview_id}/open-time")
def set_open_time(
    interview_id: int,
    req: OpenTimeUpdate,
    user: User = Depends(require_interviewer),
    db: Session = Depends(get_db),
):
    interview = get_interview(db, interview_id)
    updated = update_open_time(db, interview, req.open_time_start, req.open_time_end, user)
    return {"code": 200, "data": _interview_to_dict(updated), "message": "ok"}


@router.put("/{interview_id}/questions/{question_id}")
def edit_question(
    interview_id: int,
    question_id: int,
    req: QuestionUpdate,
    user: User = Depends(require_interviewer),
    db: Session = Depends(get_db),
):
    interview = get_interview(db, interview_id)
    question = update_question(db, interview, question_id, req.question_text, user)
    return {"code": 200, "data": {"id": question.id, "question_text": question.question_text}, "message": "ok"}


@router.get("/{interview_id}/check-in")
def checkin(interview_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    interview = get_interview(db, interview_id)
    data = check_in(db, interview, user)
    return {"code": 200, "data": data, "message": "可以进入面试"}


@router.post("/{interview_id}/answers", status_code=201)
async def submit_media_answer(
    interview_id: int,
    media_file: UploadFile = File(...),
    question_id: int = Form(...),
    transcript_text: str = Form(""),
    background_tasks: BackgroundTasks = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    from models.interview import Answer, Question

    interview = get_interview(db, interview_id)
    media_type, media_url = await save_media(media_file, interview_id, question_id)

    manual_transcript = transcript_text.strip() if isinstance(transcript_text, str) else ""

    # Agent 模式如果没有手动转写，需要同步拿到转写文本才能生成下一题
    sync_result_for_agent: dict | None = None
    if interview.interview_mode == "agent" and not manual_transcript:
        from pathlib import Path
        from main import BASE_DIR as _BASE_DIR
        from ai.video_analyzer import analyze_media
        media_path = Path(_BASE_DIR) / media_url.lstrip("/")
        sync_result_for_agent = await asyncio.to_thread(analyze_media, str(media_path))

    # 确定用于生成下一题/保存的转写文本
    if sync_result_for_agent is not None:
        transcript = sync_result_for_agent.get("transcript", "")
        transcript = transcript.strip() if isinstance(transcript, str) else ""
        if _is_invalid_transcript(transcript):
            transcript = ""
        if not transcript:
            transcript = "（待分析）"
    else:
        transcript = manual_transcript or "（待分析）"

    # 保存本轮回答占位（Agent 模式下 build_qa_history 需要读到当前回答）
    answer = db.query(Answer).filter(Answer.interview_id == interview_id, Answer.question_id == question_id).first()
    if answer:
        answer.media_type = media_type
        answer.media_url = media_url
        answer.audio_path = media_url
        answer.transcript = transcript
        answer.analysis_status = "pending"
    else:
        answer = Answer(
            interview_id=interview_id,
            question_id=question_id,
            media_type=media_type,
            media_url=media_url,
            audio_path=media_url,
            transcript=transcript,
            analysis_status="pending",
        )
        db.add(answer)
    db.commit()

    completed = db.query(Answer).filter(Answer.interview_id == interview.id).count()
    total = len(interview.questions)

    # 构造岗位/候选人信息，供 Agent 模式使用
    job_info = {
        "title": interview.job.title,
        "education_requirement": interview.job.education_requirement,
        "work_experience_requirement": interview.job.work_experience_requirement,
        "work_content": interview.job.work_content,
        "position_requirements": interview.job.position_requirements,
    }
    candidate_info = {
        "name": interview.interviewee.name,
        "education": interview.interviewee.education,
        "work_experience": interview.interviewee.work_experience,
        "skills": interview.interviewee.skills,
        "experience": interview.interviewee.experience,
    }

    # 注入简历文本（Agent 追问时也参考简历）
    from models.job import JobApplication
    application = db.query(JobApplication).filter(
        JobApplication.job_id == interview.job_id,
        JobApplication.interviewee_id == interview.interviewee_id
    ).first()
    if application and application.resume_text:
        candidate_info["resume_text"] = application.resume_text

    # 生成/返回下一题
    next_question_data = None
    if interview.interview_mode == "agent":
        if completed >= interview.max_rounds:
            interview.status = "已结束"
        else:
            history = build_qa_history(db, interview_id)
            next_q = await generate_next_question(
                job_info, candidate_info, history, completed + 1, interview.max_rounds, job_id=interview.job_id
            )
            if next_q is None:
                interview.status = "已结束"
            else:
                new_question = Question(
                    interview_id=interview.id,
                    question_text=next_q["question_text"],
                    question_type=next_q.get("question_type", "技术"),
                    sort_order=completed + 1,
                )
                db.add(new_question)
                db.flush()
                next_question_data = {
                    "id": new_question.id,
                    "question_text": new_question.question_text,
                    "current_index": completed + 1,
                    "total_questions": interview.max_rounds,
                }
    else:
        if completed < total:
            next_question = interview.questions[completed]
            next_question_data = {
                "id": next_question.id,
                "question_text": next_question.question_text,
                "current_index": completed + 1,
                "total_questions": total,
            }
        else:
            interview.status = "已结束"

    # 媒体分析（转写 + 语调/表情/肢体 + 内容）放到后台执行，不阻塞返回下一题
    background_tasks.add_task(
        analyze_media_async,
        interview_id=interview_id,
        question_id=question_id,
        media_type=media_type,
        media_url=media_url,
        manual_transcript=manual_transcript,
        sync_result=sync_result_for_agent,
    )

    db.commit()
    return {"code": 201, "data": {"answer_id": answer.id, "next_question": next_question_data}, "message": "回答已保存"}


@router.get("/{interview_id}/answers")
def list_answers(interview_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = get_answers(db, interview_id)
    return {"code": 200, "data": data, "message": "ok"}


@router.post("/{interview_id}/message-channel", status_code=201)
def create_msg_channel(interview_id: int, user: User = Depends(require_interviewer), db: Session = Depends(get_db)):
    interview = get_interview(db, interview_id)
    channel = create_channel(db, user.id, interview.interviewee_id, "面试")
    return {"code": 201, "data": {"channel_id": channel.id}, "message": "通讯渠道已创建"}


def _interview_to_dict(interview):
    return {
        "id": interview.id,
        "job": {"id": interview.job.id, "title": interview.job.title} if interview.job else {},
        "interviewee": {"id": interview.interviewee.id, "name": interview.interviewee.name} if interview.interviewee else {},
        "status": interview.status,
        "interview_mode": interview.interview_mode,
        "max_rounds": interview.max_rounds,
        "questions": [
            {
                "id": question.id,
                "question_text": question.question_text,
                "question_type": question.question_type,
                "sort_order": question.sort_order,
            }
            for question in interview.questions
        ],
        "open_time_start": interview.open_time_start,
        "open_time_end": interview.open_time_end,
    }
