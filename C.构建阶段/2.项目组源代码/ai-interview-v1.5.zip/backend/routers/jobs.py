﻿"""岗位路由"""
from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, Query, UploadFile
from typing import Optional
from sqlalchemy.orm import Session
from database import get_db
from schemas.job import JobCreate, JobUpdate
from services.job_service import create_job, get_jobs, get_job, update_job, delete_job, apply_job, get_applicants
from services.message_service import create_channel
from services.jd_document_service import (
    create_rag_document,
    list_rag_documents,
    process_rag_document,
    rag_search,
)
from utils.file_storage import save_jd_document
from utils.security import get_current_user, require_interviewer
from models.user import User
from models.job import Job, JobApplication

router = APIRouter(prefix="/jobs", tags=["岗位"])

@router.post("", status_code=201)
def create(req: JobCreate, user: User = Depends(require_interviewer), db: Session = Depends(get_db)):
    job = create_job(db, user.id, req.dict())
    return {"code": 201, "data": _job_to_dict(job), "message": "ok"}

@router.get("")
def list_jobs(
    title: Optional[str] = None, education_requirement: Optional[str] = None,
    work_experience_requirement: Optional[int] = None, fresh_requirement: Optional[str] = None,
    sort: Optional[str] = "created_at", order: Optional[str] = "desc",
    page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=100),
    user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    filters = {"title": title, "education_requirement": education_requirement,
               "work_experience_requirement": work_experience_requirement,
               "fresh_requirement": fresh_requirement, "sort": sort, "order": order}
    result = get_jobs(db, filters, page, size)
    items = []
    for job in result["items"]:
        d = _job_to_dict(job)
        if user.role == "interviewee":
            applied = db.query(JobApplication).filter(JobApplication.job_id == job.id, JobApplication.interviewee_id == user.id).first()
            d["has_applied"] = applied is not None
        items.append(d)
    return {"code": 200, "data": {"items": items, "total": result["total"], "page": page, "size": size}, "message": "ok"}

@router.get("/{job_id}")
def get_job_detail(job_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    job = get_job(db, job_id)
    d = _job_to_dict(job)
    if user.role == "interviewee":
        applied = db.query(JobApplication).filter(JobApplication.job_id == job.id, JobApplication.interviewee_id == user.id).first()
        d["has_applied"] = applied is not None
    return {"code": 200, "data": d, "message": "ok"}

@router.put("/{job_id}")
def update(job_id: int, req: JobUpdate, user: User = Depends(require_interviewer), db: Session = Depends(get_db)):
    job = get_job(db, job_id)
    updated = update_job(db, job, req.dict(exclude_unset=True), user)
    return {"code": 200, "data": _job_to_dict(updated), "message": "ok"}

@router.delete("/{job_id}")
def delete(job_id: int, user: User = Depends(require_interviewer), db: Session = Depends(get_db)):
    job = get_job(db, job_id)
    delete_job(db, job, user)
    return {"code": 200, "data": None, "message": "ok"}

@router.post("/{job_id}/apply", status_code=201)
def apply(job_id: int, resume_file: UploadFile | None = File(None),
          user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "interviewee":
        return {"code": 403, "data": None, "message": "仅面试者可报名岗位"}
    application = apply_job(db, job_id, user, resume_file)
    return {"code": 201, "data": {"id": application.id}, "message": "报名成功"}

@router.get("/{job_id}/applicants")
def list_applicants(job_id: int, page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=100),
                    user: User = Depends(require_interviewer), db: Session = Depends(get_db)):
    job = get_job(db, job_id)
    if job.created_by != user.id:
        return {"code": 403, "data": None, "message": "仅创建者可查看意向面试者"}
    result = get_applicants(db, job_id, page, size)
    items = []
    for app in result["items"]:
        interviewee = db.query(User).filter(User.id == app.interviewee_id).first()
        # 将 AI 备注按 ▲ 拆分为多条建议
        ai_notes = []
        if app.ai_note:
            for line in app.ai_note.strip().split("\n"):
                line = line.strip()
                if line.startswith("▲"):
                    ai_notes.append(line)
        if not ai_notes and app.ai_note:
            ai_notes = [app.ai_note.strip()]
        items.append({
            "interviewee_id": interviewee.id, "name": interviewee.name,
            "profile": {
                "education": interviewee.education,
                "experienceYears": interviewee.work_experience,
                "graduateType": interviewee.is_fresh,
            },
            "education": interviewee.education, "work_experience": interviewee.work_experience,
            "is_fresh": interviewee.is_fresh, "skills": interviewee.skills,
            "ai_note": app.ai_note, "aiNotes": ai_notes, "applied_at": app.applied_at,
            "resumeUploaded": bool(app.resume_url),
            "resumeFileName": app.resume_file_name,
            "resumeFileUrl": app.resume_url,
            "resumeExcerpt": (app.resume_text or "")[:200] if app.resume_text else "",
        })
    return {"code": 200, "data": {"items": items, "total": result["total"], "page": page, "size": size}, "message": "ok"}

@router.post("/{job_id}/applicants/{interviewee_id}/message-channel", status_code=201)
def create_msg_channel_from_applicants(job_id: int, interviewee_id: int,
                                       user: User = Depends(require_interviewer), db: Session = Depends(get_db)):
    channel = create_channel(db, user.id, interviewee_id, "意向仓库")
    return {"code": 201, "data": {"channel_id": channel.id}, "message": "通讯渠道已创建"}

@router.post("/{job_id}/jd-documents", status_code=202)
async def upload_rag_document(
    job_id: int,
    file: UploadFile = File(...),
    title: str = Form(""),
    background_tasks: BackgroundTasks = None,
    user: User = Depends(require_interviewer),
    db: Session = Depends(get_db),
):
    job = get_job(db, job_id)
    file_url = await save_jd_document(file, job_id)
    doc_title = title.strip() or (file.filename.rsplit(".", 1)[0] if "." in file.filename else "未命名文档")
    doc = create_rag_document(db, job_id, doc_title, file_url, user)
    background_tasks.add_task(_process_rag_background, doc.id)
    return {
        "code": 202,
        "data": {
            "document_id": doc.id,
            "job_id": doc.job_id,
            "title": doc.title,
            "file_url": doc.file_url,
            "status": doc.status,
            "created_at": doc.created_at,
        },
        "message": "文档上传成功，正在异步解析构建向量索引",
    }


async def _process_rag_background(document_id: int):
    """在后台任务中重新获取独立 session 异步处理文档。"""
    from database import SessionLocal
    session = SessionLocal()
    try:
        await process_rag_document(session, document_id)
    finally:
        session.close()


@router.get("/{job_id}/jd-documents")
def list_rag_docs(job_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    job = get_job(db, job_id)
    docs = list_rag_documents(db, job_id)
    items = []
    for doc in docs:
        item = {
            "document_id": doc.id,
            "title": doc.title,
            "status": doc.status,
            "parsed_chunks": doc.parsed_chunks,
            "created_at": doc.created_at,
        }
        if user.role == "interviewer" and job.created_by == user.id:
            item["file_url"] = doc.file_url
        if doc.status == "failed":
            item["error_message"] = doc.error_message
        items.append(item)
    return {"code": 200, "data": {"items": items, "total": len(items)}, "message": "ok"}


@router.post("/{job_id}/jd-documents/query")
async def query_rag_docs(
    job_id: int,
    query: str = Form(...),
    top_k: int = Form(3),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    job = get_job(db, job_id)
    results = await rag_search(db, job_id, query, top_k=top_k)
    return {"code": 200, "data": {"query": query, "results": results}, "message": "ok"}


def _job_to_dict(job):
    return {
        "id": job.id, "title": job.title, "salary_range": job.salary_range,
        "education_requirement": job.education_requirement,
        "work_experience_requirement": job.work_experience_requirement,
        "fresh_requirement": job.fresh_requirement, "work_content": job.work_content,
        "position_requirements": job.position_requirements, "created_by": job.created_by,
        "created_at": job.created_at, "updated_at": job.updated_at
    }