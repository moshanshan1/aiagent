"""媒体分析后台任务。

把媒体分析（视频/音频分析 + 内容分析）从 HTTP 请求主链路中拆出来，
通过 FastAPI BackgroundTasks 异步执行，让 submit_answer 能立即返回下一题。
"""

import asyncio
import json

from sqlalchemy.orm import Session

from ai.assessor import analyze_content
from ai.video_analyzer import analyze_media
from database import SessionLocal
from models.interview import Answer, Question


def _is_invalid_transcript(text: str) -> bool:
    """与 routers/interviews.py 保持一致的判断逻辑。"""
    if not isinstance(text, str):
        return True

    stripped = text.strip()
    if not stripped:
        return True

    invalid_markers = [
        "[",
        "分析失败",
        "文件不存在",
        "模型返回为空",
        "Error code:",
        "access_denied",
        "Workspace endpoint access denied",
        "服务未配置",
    ]
    return any(marker in stripped for marker in invalid_markers)


async def analyze_media_async(
    interview_id: int,
    question_id: int,
    media_type: str,
    media_url: str,
    manual_transcript: str = "",
    sync_result: dict | None = None,
) -> None:
    """后台执行媒体分析：转写 + 语调/表情/肢体 + 内容分析，并更新 Answer。

    Args:
        interview_id: 面试 ID。
        question_id: 题目 ID。
        media_type: "video" 或 "audio"。
        media_url: 媒体文件相对路径（如 /uploads/answers/xxx.mp4）。
        manual_transcript: 面试者手动提供的转写文本，作为 fallback。
        sync_result: 如果主链路已同步完成分析，可直接传入避免重复调用。
    """
    db: Session = SessionLocal()
    try:
        answer = (
            db.query(Answer)
            .filter(Answer.interview_id == interview_id, Answer.question_id == question_id)
            .first()
        )
        if not answer:
            answer = Answer(
                interview_id=interview_id,
                question_id=question_id,
                media_type=media_type,
                media_url=media_url,
                analysis_status="processing",
            )
            db.add(answer)
        else:
            answer.media_type = media_type
            answer.media_url = media_url
            answer.analysis_status = "processing"
        db.commit()

        # 实际分析
        from pathlib import Path
        from main import BASE_DIR as _BASE_DIR
        media_path = Path(_BASE_DIR) / media_url.lstrip("/")

        if sync_result is None:
            sync_result = await asyncio.to_thread(analyze_media, str(media_path))

        transcript = sync_result.get("transcript", "")
        transcript = transcript.strip() if isinstance(transcript, str) else ""
        raw_invalid = _is_invalid_transcript(transcript)

        tone_result = {k: v for k, v in sync_result.items() if k != "body_language"}
        tone_str = json.dumps(tone_result, ensure_ascii=False)
        body_language = sync_result.get("body_language")
        body_language_str = json.dumps(body_language, ensure_ascii=False) if body_language else None

        answer.tone_features = tone_str
        answer.body_language_analysis = body_language_str

        if raw_invalid:
            # 分析返回了无效转写 → 标记失败，保留原始返回原文供排查
            answer.transcript = transcript or sync_result.get("raw_output", "")[:200] or "（转写无效）"
            answer.content_analysis = f"语音分析失败：模型返回内容异常。原始返回摘要：{json.dumps(sync_result, ensure_ascii=False)[:200]}"
            answer.analysis_status = "failed"
            db.commit()
            print(f"[WARN] media_analysis_service: 转写无效 - transcript='{transcript[:100]}'")
            return

        if not transcript and manual_transcript:
            transcript = manual_transcript.strip()
        if not transcript:
            transcript = "（分析完成，未提取到语音内容）"

        answer.transcript = transcript

        # 内容分析：仅当转写有效时调用
        question = db.query(Question).filter(Question.id == question_id).first()
        if question and transcript and transcript not in ("（待分析）", "（分析完成，未提取到语音内容）"):
            try:
                content_analysis = await analyze_content(
                    question.question_text, transcript, tone_str
                )
                answer.content_analysis = content_analysis
            except Exception as e:
                print(f"[WARN] media_analysis_service: 内容分析失败 - {e}")
                if not answer.content_analysis:
                    answer.content_analysis = "内容分析暂不可用"
        elif not answer.content_analysis:
            answer.content_analysis = "内容分析暂不可用"

        answer.analysis_status = "completed"
        db.commit()
    except Exception as e:
        import traceback
        print(f"[ERROR] media_analysis_service: 后台媒体分析失败 - {e}")
        traceback.print_exc()
        try:
            if answer:
                answer.analysis_status = "failed"
                db.commit()
        except Exception:
            pass
    finally:
        db.close()


# 保留旧函数名，避免未同步更新的调用方报错
async def analyze_voice_async(
    interview_id: int,
    question_id: int,
    audio_path: str,
    manual_transcript: str = "",
    tone_result: dict | None = None,
) -> None:
    """兼容旧音频分析的入口。"""
    media_url = audio_path
    if audio_path and not audio_path.startswith("/uploads"):
        media_url = audio_path.replace(str(__import__('pathlib').Path(__file__).resolve().parent.parent / "uploads"), "/uploads").replace("\\", "/")
    await analyze_media_async(
        interview_id=interview_id,
        question_id=question_id,
        media_type="audio",
        media_url=media_url,
        manual_transcript=manual_transcript,
        sync_result=tone_result,
    )
