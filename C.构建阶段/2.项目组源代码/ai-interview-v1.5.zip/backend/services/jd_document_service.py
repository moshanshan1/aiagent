"""JD 文档上传 / 解析 / RAG 检索服务。

使用 ChromaDB 作为向量数据库，DashScope text-embedding-v4 生成向量。
"""

import json
import os
from pathlib import Path

from openai import AsyncOpenAI
from sqlalchemy.orm import Session
from fastapi import HTTPException

from ai.logger import log_ai_request, log_ai_response
from config import CHROMADB_DIR, DASHSCOPE_API_KEY, DASHSCOPE_BASE_URL, EMBEDDING_DIMENSIONS, EMBEDDING_MODEL, JD_DOC_DIR
from models.job import Job
from models.jd_document import JdDocument, JdDocumentChunk

CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

# 全局 ChromaDB 客户端和 DashScope 客户端（延迟加载，复用）
_chroma_client = None
_dashscope_client: AsyncOpenAI | None = None

_COLLECTION_NAME = "jd_chunks"


def _get_chroma_client():
    """获取或创建全局 ChromaDB PersistentClient。"""
    global _chroma_client
    if _chroma_client is None:
        import chromadb
        from chromadb.config import Settings
        CHROMADB_DIR.mkdir(parents=True, exist_ok=True)
        _chroma_client = chromadb.PersistentClient(
            path=str(CHROMADB_DIR),
            settings=Settings(anonymized_telemetry=False),
        )
    return _chroma_client


def _get_collection():
    """获取或创建 ChromaDB 集合。"""
    client = _get_chroma_client()
    try:
        return client.get_collection(_COLLECTION_NAME)
    except Exception:
        return client.create_collection(_COLLECTION_NAME)


def _rebuild_collection_if_mismatch(db: Session):
    """如集合维度与当前模型不匹配，删除重建并清空所有旧分块。"""
    client = _get_chroma_client()
    try:
        col = client.get_collection(_COLLECTION_NAME)
        if col.count() > 0:
            sample = col.get(limit=1, include=["embeddings"])
            if sample["embeddings"] and len(sample["embeddings"][0]) != EMBEDDING_DIMENSIONS:
                print(f"[RAG] 集合维度 {len(sample['embeddings'][0])} → {EMBEDDING_DIMENSIONS}，重建...")
                client.delete_collection(_COLLECTION_NAME)
                client.create_collection(_COLLECTION_NAME)
                # 清空所有旧 SQL 分块 + 重置文档状态
                db.query(JdDocumentChunk).delete()
                db.query(JdDocument).update({"status": "pending", "error_message": "向量模型已升级，请重新解析"})
                db.commit()
                print("[RAG] 集合已重建，所有文档状态已重置为 pending")
    except Exception:
        pass  # 集合不存在，首次创建时无需处理


def _get_dashscope_client() -> AsyncOpenAI:
    """获取或创建全局异步 DashScope 客户端。"""
    global _dashscope_client
    if _dashscope_client is None:
        base_url = (DASHSCOPE_BASE_URL or "https://dashscope.aliyuncs.com/compatible-mode/v1").rstrip("/")
        _dashscope_client = AsyncOpenAI(api_key=DASHSCOPE_API_KEY, base_url=base_url)
    return _dashscope_client


async def _embed_texts(texts: list[str]) -> list[list[float]]:
    """异步调用 DashScope text-embedding-v4 批量生成向量。"""
    if not DASHSCOPE_API_KEY or DASHSCOPE_API_KEY.startswith("your-"):
        raise RuntimeError("DASHSCOPE_API_KEY 未配置")

    log_ai_request("jd_document_service._embed_texts", metadata={"chunks": len(texts), "model": EMBEDDING_MODEL})
    client = _get_dashscope_client()
    resp = await client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=texts,
        dimensions=EMBEDDING_DIMENSIONS,
    )
    vectors = [item.embedding for item in resp.data]

    log_ai_response(
        "jd_document_service._embed_texts",
        response={"vectors": len(vectors)},
        note=f"DashScope 向量生成完成 | {len(texts)} 个片段 → {len(vectors)} 个向量",
        metadata={"model": EMBEDDING_MODEL},
    )
    return vectors


def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """简单按字符切分文本。"""
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks


def _parse_document(file_path: str) -> str:
    """解析 txt / md / docx / pdf。"""
    path = Path(file_path)
    ext = path.suffix.lower()

    if ext in (".txt", ".md"):
        return path.read_text(encoding="utf-8")

    if ext == ".docx":
        from docx import Document
        doc = Document(str(path))
        return "\n".join(p.text for p in doc.paragraphs)

    if ext == ".pdf":
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(path))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        except Exception:
            return ""

    return ""


def create_rag_document(db: Session, job_id: int, title: str, file_path: str, user) -> JdDocument:
    """创建 JD 文档记录并触发后台解析。"""
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="岗位不存在")
    if job.created_by != user.id:
        raise HTTPException(status_code=403, detail="仅岗位创建者可上传文档")

    doc = JdDocument(
        job_id=job_id,
        title=title,
        file_url=file_path,
        status="processing",
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)
    return doc


def _delete_chroma_entries(document_id: int):
    """删除 ChromaDB 中指定文档的所有切片。"""
    try:
        collection = _get_collection()
        existing = collection.get(where={"document_id": document_id})
        if existing and existing["ids"]:
            collection.delete(ids=existing["ids"])
    except Exception as e:
        print(f"[WARN] ChromaDB 删除旧切片失败: {e}")


async def process_rag_document(db: Session, document_id: int) -> None:
    """后台异步解析文档：切分、向量化、存入 ChromaDB + MySQL。"""
    _rebuild_collection_if_mismatch(db)

    doc = db.query(JdDocument).filter(JdDocument.id == document_id).first()
    if not doc:
        print(f"[WARN] process_rag_document: 文档 {document_id} 不存在")
        return

    try:
        from main import BASE_DIR as _BASE_DIR
        file_path = Path(_BASE_DIR) / doc.file_url.lstrip("/")
        text = _parse_document(str(file_path))
        if not text.strip():
            raise ValueError("文档内容为空或解析失败")

        chunks = _chunk_text(text)
        if not chunks:
            raise ValueError("文档切分后为空")

        # DashScope 向量生成
        vectors = await _embed_texts(chunks)
        if len(vectors) != len(chunks):
            raise ValueError(f"向量数量与切片数量不一致: {len(vectors)} vs {len(chunks)}")

        # ── 写入 ChromaDB ──
        _delete_chroma_entries(document_id)
        collection = _get_collection()
        chroma_ids = [f"{document_id}_{i}" for i in range(len(chunks))]
        chroma_metadatas = [
            {
                "job_id": doc.job_id,
                "document_id": document_id,
                "document_title": doc.title,
                "chunk_index": i,
            }
            for i in range(len(chunks))
        ]
        collection.add(
            ids=chroma_ids,
            documents=chunks,
            embeddings=vectors,
            metadatas=chroma_metadatas,
        )

        # ── 写入 MySQL（仅存文本，向量已存 ChromaDB）──
        db.query(JdDocumentChunk).filter(JdDocumentChunk.document_id == document_id).delete()
        for idx, chunk_text in enumerate(chunks):
            chunk = JdDocumentChunk(
                document_id=document_id,
                job_id=doc.job_id,
                chunk_text=chunk_text,
                embedding_vector=None,
                chunk_index=idx,
            )
            db.add(chunk)

        doc.status = "completed"
        doc.parsed_chunks = len(chunks)
        doc.error_message = None
        db.commit()
        print(f"[INFO] RAG 文档 {document_id} 解析完成，共 {len(chunks)} 个切片 → ChromaDB")
    except Exception as e:
        print(f"[ERROR] process_rag_document: 文档 {document_id} 解析失败 - {e}")
        doc.status = "failed"
        doc.error_message = str(e)
        db.commit()


def list_rag_documents(db: Session, job_id: int) -> list[JdDocument]:
    return db.query(JdDocument).filter(JdDocument.job_id == job_id).order_by(JdDocument.created_at.desc()).all()


async def rag_search(db: Session, job_id: int, query: str, top_k: int = 3) -> list[dict]:
    """对指定岗位的 JD 文档做异步 RAG 检索（ChromaDB ANN 搜索）。"""
    query_vector = (await _embed_texts([query]))[0]

    collection = _get_collection()
    results = collection.query(
        query_embeddings=[query_vector],
        n_results=top_k * 3,
        include=["documents", "metadatas", "distances"],
    )

    # 按 job_id 过滤
    filtered = []
    if results and results["ids"] and results["ids"][0]:
        for i in range(len(results["ids"][0])):
            meta = results["metadatas"][0][i] if results["metadatas"] else {}
            if meta.get("job_id") == job_id:
                filtered.append({
                    "document_id": meta.get("document_id"),
                    "document_title": meta.get("document_title", ""),
                    "chunk_text": results["documents"][0][i] if results["documents"] else "",
                    "score": round(1.0 - (results["distances"][0][i] if results["distances"] else 0), 3),
                })

    return filtered[:top_k]
