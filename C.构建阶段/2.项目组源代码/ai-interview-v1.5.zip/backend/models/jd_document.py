"""岗位 JD 文档模型（用于 RAG）。"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, func
from sqlalchemy.orm import relationship
from database import Base


class JdDocument(Base):
    __tablename__ = "jd_documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    title = Column(String(255), nullable=False)
    file_url = Column(String(255), nullable=True)
    status = Column(String(20), nullable=False, default="processing")  # processing / completed / failed
    parsed_chunks = Column(Integer, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    job = relationship("Job")


class JdDocumentChunk(Base):
    __tablename__ = "jd_document_chunks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey("jd_documents.id"), nullable=False)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    chunk_text = Column(Text, nullable=False)
    embedding_vector = Column(Text, nullable=True)  # JSON 存储向量，便于调试/迁移
    chunk_index = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, server_default=func.now())

    document = relationship("JdDocument")
