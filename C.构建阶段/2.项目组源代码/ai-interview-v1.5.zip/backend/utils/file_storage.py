﻿"""文件存储工具"""
import os
import uuid
from pathlib import Path
import ffmpegio
from fastapi import UploadFile
from config import AVATAR_DIR, MEDIA_DIR, REPORT_DIR, JD_DOC_DIR, RESUME_DIR, \
    MAX_AVATAR_SIZE, MAX_AUDIO_SIZE, MAX_VIDEO_SIZE, MAX_JD_DOC_SIZE, MAX_RESUME_SIZE

ALLOWED_AVATAR_TYPES = {"image/jpeg", "image/png", "image/jpg"}
ALLOWED_AUDIO_TYPES = {"audio/wav", "audio/mpeg", "audio/mp3", "audio/m4a", "audio/x-m4a", "audio/mp4", "audio/ogg", "audio/flac"}
ALLOWED_VIDEO_TYPES = {"video/mp4", "video/quicktime", "video/webm", "video/x-matroska"}
ALLOWED_MEDIA_EXTENSIONS = {"mp4", "mov", "webm", "mkv", "wav", "mp3", "m4a", "ogg", "flac"}
ALLOWED_JD_DOC_TYPES = {"text/plain", "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/markdown"}
ALLOWED_JD_DOC_EXTENSIONS = {"txt", "pdf", "docx", "md"}
ALLOWED_RESUME_TYPES = {"application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "text/markdown"}
ALLOWED_RESUME_EXTENSIONS = {"pdf", "docx", "txt", "md"}


def _get_media_type(filename: str, content_type: str | None = None) -> str:
    """根据文件名后缀和 MIME 类型判断媒体类型。

    webm 后缀含混需要 content_type 辅助判断：
    - audio/webm → audio
    - video/webm → video
    - 无 content_type 时默认 video。
    """
    ext = os.path.splitext(filename)[1].lower().lstrip(".")
    if ext == "webm":
        if content_type and content_type.startswith("audio/"):
            return "audio"
        return "video"
    if ext in {"mp4", "mov", "mkv"}:
        return "video"
    if ext in {"wav", "mp3", "m4a", "ogg", "flac"}:
        return "audio"
    raise ValueError(f"不支持的媒体格式: .{ext}")


async def save_avatar(file: UploadFile, account: str) -> str:
    if file.content_type not in ALLOWED_AVATAR_TYPES:
        raise ValueError("仅支持 jpg/png 格式头像")
    content = await file.read()
    if len(content) > MAX_AVATAR_SIZE:
        raise ValueError("头像文件大小不能超过 2MB")
    AVATAR_DIR.mkdir(parents=True, exist_ok=True)
    ext = "jpg" if "jpeg" in file.content_type or "jpg" in file.content_type else "png"
    filename = f"{account}.{ext}"
    filepath = AVATAR_DIR / filename
    with open(filepath, "wb") as f:
        f.write(content)
    return f"/uploads/avatars/{filename}"


def _transcode_to_h264(src_path: Path) -> Path:
    """将视频转码为 H.264/AAC 的标准 MP4 格式。

    使用 ffmpegio 进行转码，输出到临时文件后替换原文件。
    若 FFmpeg 不可用或转码失败，返回原文件路径并打印警告。
    """
    if not os.environ.get("VIDEO_TRANSCODE"):
        print("[INFO] VIDEO_TRANSCODE 已设置，跳过视频转码")
        return src_path

    import tempfile
    tmp_fd, tmp_path_str = tempfile.mkstemp(suffix=".mp4", dir=str(src_path.parent))
    os.close(tmp_fd)
    tmp_path = Path(tmp_path_str)

    try:
        ffmpegio.transcode(
            str(src_path), str(tmp_path),
            overwrite=True,
            vcodec="libx264", preset="fast", crf=23,
            acodec="aac", ab="128k",
            movflags="+faststart",
            vf="scale=trunc(iw/2)*2:trunc(ih/2)*2",
        )
        # 转码成功：用临时文件替换原文件
        final_path = src_path.with_suffix(".mp4")
        if final_path.exists():
            final_path.unlink(missing_ok=True)
        tmp_path.rename(final_path)
        return final_path
    except FileNotFoundError:
        print("[WARN] FFmpeg 未安装，跳过视频转码")
        tmp_path.unlink(missing_ok=True)
        return src_path
    except Exception as e:
        print(f"[WARN] FFmpeg 转码异常: {e}")
        tmp_path.unlink(missing_ok=True)
        return src_path


async def save_media(file: UploadFile, interview_id: int, question_id: int) -> tuple[str, str]:
    """统一保存面试回答媒体文件（视频/音频）。

    视频文件保存后会自动转码为 H.264/AAC 的标准 MP4，
    确保 Qwen-Omni 模型能够正确解析。

    Returns:
        (media_type, media_url)
    """
    content = await file.read()
    media_type = _get_media_type(file.filename or "", file.content_type)

    if media_type == "video" and len(content) > MAX_VIDEO_SIZE:
        raise ValueError("视频文件大小不能超过 50MB")
    if media_type == "audio" and len(content) > MAX_AUDIO_SIZE:
        raise ValueError("音频文件大小不能超过 10MB")

    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    ext = file.filename.rsplit(".", 1)[-1] if "." in file.filename else ("mp4" if media_type == "video" else "wav")
    filename = f"interview_{interview_id}_q{question_id}_{uuid.uuid4().hex[:8]}.{ext}"
    filepath = MEDIA_DIR / filename
    with open(filepath, "wb") as f:
        f.write(content)

    # 视频自动转码为标准 MP4 (H.264/AAC)
    if media_type == "video":
        final_path = _transcode_to_h264(filepath)
        if final_path != filepath:
            filename = final_path.name
            print(f"[INFO] 视频已转码: {filepath.name} -> {filename}")

    return media_type, f"/uploads/answers/{filename}"


async def save_jd_document(file: UploadFile, job_id: int) -> str:
    """保存 JD 参考文档。

    Returns:
        file_url: 文件相对路径
    """
    content = await file.read()
    if len(content) > MAX_JD_DOC_SIZE:
        raise ValueError("JD 文档大小不能超过 10MB")
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED_JD_DOC_EXTENSIONS:
        raise ValueError(f"不支持的 JD 文档格式: .{ext}")

    JD_DOC_DIR.mkdir(parents=True, exist_ok=True)
    job_dir = JD_DOC_DIR / str(job_id)
    job_dir.mkdir(parents=True, exist_ok=True)

    filename = f"{uuid.uuid4().hex[:8]}.{ext}"
    filepath = job_dir / filename
    with open(filepath, "wb") as f:
        f.write(content)
    return f"/uploads/jd-docs/{job_id}/{filename}"

def _find_cn_font(pdf) -> str | None:
    """查找系统中文字体，返回字体名称；找不到返回 None"""
    # 1. 项目目录下的 NotoSansSC
    local = Path(__file__).resolve().parent / "NotoSansSC-VariableFont_wght.ttf"
    if local.exists():
        pdf.add_font("NotoSansSC", "", str(local), uni=True)
        return "NotoSansSC"
    # 2. Linux 系统字体（文泉驿）
    linux_candidates = [
        ("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", "WQYZenHei"),
        ("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", "NotoSansCJK"),
    ]
    for path, name in linux_candidates:
        if Path(path).exists():
            try:
                pdf.add_font(name, "", path, uni=True)
                return name
            except Exception:
                continue
    # 3. Windows 系统字体
    candidates = [
        (r"C:\Windows\Fonts\msyh.ttc", "YaHei"),
        (r"C:\Windows\Fonts\simsun.ttc", "SimSun"),
        (r"C:\Windows\Fonts\simhei.ttf", "SimHei"),
    ]
    for path, name in candidates:
        if Path(path).exists():
            try:
                pdf.add_font(name, "", path, uni=True)
                return name
            except Exception:
                continue
    return None


def save_report_pdf(report_data: dict, report_id: int) -> str:
    """使用 fpdf2 生成面试报告 PDF

    Args:
        report_data: {
            "interviewee_name", "job_title", "answer_summary",
            "highlights", "risks", "recommendation",
            "skill_score", "communication_score", "logic_score", "culture_score",
            "interviewer_rating"
        }
        report_id: 报告 ID（用于文件名）

    Returns:
        PDF 文件的绝对路径
    """
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    filepath = REPORT_DIR / f"report_{report_id}.pdf"

    from fpdf import FPDF

    pdf = FPDF()
    pdf.add_page()

    cn_font = _find_cn_font(pdf)
    if not cn_font:
        # 无中文字体，降级为 HTML
        html_path = filepath.with_suffix(".html")
        edu = report_data.get('education') or '未填写'
        exp = report_data.get('work_experience')
        exp_str = f"{int(exp)}年" if exp is not None else "未填写"
        fresh = report_data.get('is_fresh') or '未填写'
        salary = report_data.get('salary_expectation') or '未填写'
        skills = report_data.get('skills') or '未填写'
        avatar = report_data.get('avatar_url') or ''

        html_parts = [
            "<html><head><meta charset='utf-8'><title>面试报告</title></head><body>",
            ('<img src="' + avatar + '" width=100>') if avatar else '',
            "<h1>面试评估报告</h1>",
            f"<p><b>面试者:</b> {report_data.get('interviewee_name')}</p>",
            f"<p><b>应聘岗位:</b> {report_data.get('job_title')}</p>",
            f"<p><b>学历:</b> {edu}  |  <b>经验:</b> {exp_str}  |  {fresh}</p>",
            f"<p><b>期望薪资:</b> {salary}</p>",
            f"<p><b>技能:</b> {skills}</p>",
            f"<h2>回答摘要</h2><p>{report_data.get('answer_summary', '无')}</p>",
            f"<h2>亮点</h2><p>{report_data.get('highlights', '无')}</p>",
            f"<h2>风险点</h2><p>{report_data.get('risks', '无')}</p>",
            f"<h2>录用建议</h2><p>{report_data.get('recommendation', '无')}</p>",
            "<h2>评分</h2><ul>",
            *[f"<li>{k}: {report_data.get(k, '未评分')}</li>"
              for k in ("skill_score", "communication_score", "logic_score", "culture_score")],
            "</ul>",
            f"<p><b>系统评级:</b> {report_data.get('rating') or '待计算'}  |  <b>面试官评级:</b> {report_data.get('interviewer_rating') or '未评级'}</p>",
            "</body></html>",
        ]
        html_path.write_text("\n".join(html_parts), encoding="utf-8")
        print("[INFO] 未找到中文字体，已生成 HTML 替代")
        return str(html_path)

    # ── 标题 ──
    pdf.set_font(cn_font, "", 20)
    pdf.cell(0, 15, "面试评估报告", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)

    # ── 个人头像 ──
    from config import BASE_DIR
    avatar_url = report_data.get("avatar_url")
    if avatar_url:
        avatar_path = BASE_DIR / avatar_url.lstrip("/")
        if avatar_path.exists():
            try:
                pdf.image(str(avatar_path), x=160, y=12, w=30, h=30)
            except Exception:
                pass

    # ── 基本信息 ──
    pdf.set_font(cn_font, "", 11)
    name = report_data.get("interviewee_name", "未知")
    job_title = report_data.get("job_title", "未知")
    edu = report_data.get("education") or "未填写"
    exp = report_data.get("work_experience")
    exp_str = f"{int(exp)}年" if exp is not None else "未填写"
    fresh = report_data.get("is_fresh") or "未填写"
    salary = report_data.get("salary_expectation") or "未填写"
    skills = report_data.get("skills") or "未填写"

    pdf.cell(0, 8, f"面试者: {name}", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, f"应聘岗位: {job_title}", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, f"学历: {edu}  |  工作经验: {exp_str}  |  {fresh}", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, f"期望薪资: {salary}", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font(cn_font, "", 10)
    pdf.cell(0, 8, f"技能: {skills}", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)

    # ── 各部分 ──
    sections = [
        ("一、回答摘要", report_data.get("answer_summary")),
        ("二、亮点", report_data.get("highlights")),
        ("三、风险点", report_data.get("risks")),
        ("四、录用建议", report_data.get("recommendation")),
    ]
    for title, content in sections:
        pdf.set_font(cn_font, "", 13)
        pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font(cn_font, "", 10)
        pdf.multi_cell(0, 6, content or "无")
        pdf.ln(3)

    # ── 评分 ──
    pdf.set_font(cn_font, "", 13)
    pdf.cell(0, 10, "五、评分", new_x="LMARGIN", new_y="NEXT")
    scores = [
        ("专业技能", "skill_score"),
        ("沟通能力", "communication_score"),
        ("逻辑思维", "logic_score"),
        ("文化匹配", "culture_score"),
    ]
    pdf.set_font(cn_font, "", 10)
    for label, key in scores:
        score = report_data.get(key)
        pdf.cell(40, 8, label)
        score_val = float(score) if score is not None else 0
        bar_w = min(score_val / 100 * 80, 80)
        pdf.set_fill_color(76, 129, 190)
        if bar_w > 0:
            pdf.cell(bar_w, 8, "", fill=True)
        pdf.set_fill_color(255, 255, 255)
        pdf.cell(80 - bar_w, 8, "")
        pdf.cell(0, 8, f"  {score}" if score is not None else "  未评分",
                 new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)

    # ── 评级 ──
    auto_rating = report_data.get("rating")
    manual_rating = report_data.get("interviewer_rating")
    pdf.set_font(cn_font, "", 11)
    pdf.cell(0, 8, f"系统评级: {auto_rating if auto_rating else '待计算'}",
             new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 8, f"面试官评级: {manual_rating if manual_rating else '未评级'}",
             new_x="LMARGIN", new_y="NEXT")

    # ── 页脚 ──
    pdf.ln(10)
    pdf.set_font(cn_font, "", 8)
    from datetime import date
    pdf.cell(0, 6, f"生成日期: {date.today().isoformat()}", align="C",
             new_x="LMARGIN", new_y="NEXT")

    pdf.output(str(filepath))
    return str(filepath)


# ═══════════════════════════════════════════
# 简历上传
# ═══════════════════════════════════════════

def _parse_resume_text(file_path: str) -> str:
    """解析简历文件（pdf / docx / txt / md）为纯文本，供 AI 分析。"""
    path = Path(file_path)
    ext = path.suffix.lower()

    if ext in (".txt", ".md"):
        return path.read_text(encoding="utf-8")

    if ext == ".docx":
        from docx import Document
        doc = Document(str(path))
        return "\n".join(p.text for p in doc.paragraphs)

    if ext == ".pdf":
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(path))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        except Exception:
            return ""

    return ""


async def save_resume(file: UploadFile, interviewee_id: int) -> dict:
    """保存面试者上传的简历文件，返回 {url, file_name, text}。"""
    if file.content_type and file.content_type not in ALLOWED_RESUME_TYPES:
        raise ValueError(f"不支持的简历格式，仅支持 PDF / DOCX / TXT，收到: {file.content_type}")

    ext = os.path.splitext(file.filename)[1].lower().lstrip(".")
    if ext not in ALLOWED_RESUME_EXTENSIONS:
        raise ValueError(f"不支持的简历后缀: .{ext}")

    content = await file.read()
    if len(content) > MAX_RESUME_SIZE:
        raise ValueError(f"简历文件不能超过 {MAX_RESUME_SIZE // (1024*1024)}MB")

    RESUME_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"{interviewee_id}_{uuid.uuid4().hex[:8]}.{ext}"
    filepath = RESUME_DIR / filename
    with open(filepath, "wb") as f:
        f.write(content)

    resume_text = _parse_resume_text(str(filepath))

    return {
        "url": f"/uploads/resumes/{filename}",
        "file_name": file.filename,
        "text": resume_text,
    }
