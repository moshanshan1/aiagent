"""通用 LLM 客户端封装。

提供基于 OpenAI 兼容接口的异步调用能力，供 question_generator、assessor 等模块复用。
"""

import time
from openai import AsyncOpenAI
from ai.logger import log_ai_request, log_ai_response, log_ai_error
from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL, LLM_TIMEOUT

# 全局异步 OpenAI 客户端
_async_client: AsyncOpenAI | None = None


def get_client() -> AsyncOpenAI:
    """获取或创建全局异步 OpenAI 客户端。"""
    global _async_client
    if _async_client is None:
        _async_client = AsyncOpenAI(
            api_key=LLM_API_KEY,
            base_url=LLM_BASE_URL,
            timeout=LLM_TIMEOUT,
        )
    return _async_client


def reset_client() -> None:
    """重置全局客户端，便于配置变更后重新初始化。"""
    global _async_client
    _async_client = None


async def call_llm(prompt: str, temperature: float = 0.7, model: str | None = None, **kwargs) -> str:
    """调用 LLM（OpenAI 兼容格式），成功返回响应文本，失败抛出 RuntimeError。

    Args:
        prompt: 发送给模型的用户消息内容。
        temperature: 采样温度，默认 0.7。
        model: 指定模型，默认使用配置中的 LLM_MODEL。
        **kwargs: 额外传递给 chat.completions.create 的参数。

    Returns:
        模型生成的文本内容。

    Raises:
        RuntimeError: API Key 未配置、调用超时、鉴权失败、频率超限或其他调用异常。
    """
    if not LLM_API_KEY or LLM_API_KEY.startswith("your-"):
        raise RuntimeError("API Key 未配置")

    model_name = model or LLM_MODEL
    log_ai_request(
        "llm_client.call_llm",
        metadata={"model": model_name, "temperature": temperature, **kwargs},
    )
    start = time.perf_counter()

    try:
        client = get_client()
        resp = await client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            **kwargs,
        )
        content = resp.choices[0].message.content or ""
        duration_ms = round((time.perf_counter() - start) * 1000)

        usage = resp.usage
        usage_info = {}
        if usage:
            usage_info = {
                "prompt_tokens": usage.prompt_tokens,
                "completion_tokens": usage.completion_tokens,
                "total_tokens": usage.total_tokens,
            }

        log_ai_response(
            "llm_client.call_llm",
            response=content,
            duration_ms=duration_ms,
            note=f"完成 | {len(content)} 字符",
            metadata={
                "model": model_name,
                "temperature": temperature,
                "usage": usage_info,
                **kwargs,
            },
        )
        return content
    except Exception as e:
        duration_ms = round((time.perf_counter() - start) * 1000)
        err = str(e)
        if "timeout" in err.lower() or "timed out" in err.lower():
            log_ai_error(
                "llm_client.call_llm", error="超时",
                metadata={"model": model_name, "temperature": temperature, **kwargs},
                duration_ms=duration_ms,
            )
            raise RuntimeError("模型调用超时")
        if "401" in err or "Unauthorized" in err:
            log_ai_error(
                "llm_client.call_llm", error="API Key 无效",
                metadata={"model": model_name, "temperature": temperature, **kwargs},
                duration_ms=duration_ms,
            )
            raise RuntimeError("API Key 无效")
        if "429" in err or "Rate limit" in err:
            log_ai_error(
                "llm_client.call_llm", error="频率超限",
                metadata={"model": model_name, "temperature": temperature, **kwargs},
                duration_ms=duration_ms,
            )
            raise RuntimeError("请求频率超限")
        log_ai_error(
            "llm_client.call_llm", error=err,
            metadata={"model": model_name, "temperature": temperature, **kwargs},
            duration_ms=duration_ms,
        )
        raise RuntimeError(f"模型调用异常: {err}")
