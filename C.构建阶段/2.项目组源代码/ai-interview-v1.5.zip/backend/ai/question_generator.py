﻿"""AI 面试问题生成器"""
import json
from ai.llm_client import call_llm
from ai.logger import log_ai_response
from ai.fallbacks import fallback_questions
from ai.prompts import QUESTION_GENERATION_PROMPT, APPLICANT_AI_NOTE_PROMPT

# 延迟导入避免循环依赖
_rag_query_func = None

def _get_rag_query_func():
    global _rag_query_func
    if _rag_query_func is None:
        from services.jd_document_service import rag_search
        _rag_query_func = rag_search
    return _rag_query_func


async def _build_rag_context(job_id: int | None) -> str:
    """检索岗位 JD 文档并格式化为文本片段。"""
    if not job_id:
        return "（该岗位暂无上传的 JD 参考文档）"
    try:
        query_func = _get_rag_query_func()
        from database import SessionLocal
        db = SessionLocal()
        try:
            results = await query_func(db, job_id, "岗位职责 技术要求 项目经验 必备技能", top_k=3)
        finally:
            db.close()
        if not results:
            return "（该岗位暂无已解析的 JD 参考文档片段）"
        lines = []
        for i, r in enumerate(results, 1):
            lines.append(f"片段 {i}（来自《{r.get('document_title', '未知文档')}》，相似度 {r.get('score', 0)}）：\n{r.get('chunk_text', '')}")
        return "\n\n".join(lines)
    except Exception as e:
        print(f"[WARN] question_generator: RAG 知识检索失败 - {e}")
        return "（RAG 知识检索暂不可用）"


async def generate_questions(job_info: dict, candidate_info: dict, job_id: int | None = None) -> list:
    rag_context = await _build_rag_context(job_id)
    resume_text = candidate_info.get("resume_text", "") or "（未上传简历）"
    prompt = QUESTION_GENERATION_PROMPT.format(
        job_title=job_info.get("title", ""),
        education=job_info.get("education_requirement", "不限"),
        work_exp=job_info.get("work_experience_requirement", 0),
        work_content=job_info.get("work_content", ""),
        position_req=job_info.get("position_requirements", ""),
        rag_context=rag_context,
        name=candidate_info.get("name", ""),
        candidate_edu=candidate_info.get("education", "未填写"),
        candidate_exp=candidate_info.get("work_experience", 0),
        skills=candidate_info.get("skills", "未填写"),
        experience=candidate_info.get("experience", "未填写"),
        resume_text=resume_text[:2500] if resume_text else "（未上传简历）",
    )
    try:
        result = await call_llm(prompt, temperature=0.7)
    except RuntimeError as e:
        print(f"[WARN] question_generator: 模型调用错误 - {e}，使用 fallback 数据")
        return fallback_questions()

    try:
        start = result.find("[")
        end = result.rfind("]") + 1
        if start < 0 or end <= start:
            print("[WARN] question_generator: 返回格式异常（未找到 JSON 数组），使用 fallback 数据")
            print(f"  [原始响应前200字符]: {result[:200]}")
            log_ai_response(
                "question_generator.generate_questions",
                response={"raw": result, "error": "未找到 JSON 数组"},
                metadata={"status": "format_error"},
            )
            return fallback_questions()
        questions = json.loads(result[start:end])
        if len(questions) != 5:
            print(f"[WARN] question_generator: 返回格式异常（题目数={len(questions)}，期望5道），使用 fallback 数据")
            log_ai_response(
                "question_generator.generate_questions",
                response={"raw": result, "parsed_count": len(questions), "error": "题目数异常"},
                metadata={"status": "count_error"},
            )
            return fallback_questions()
        log_ai_response(
            "question_generator.generate_questions",
            response=questions,
            metadata={"status": "success", "count": len(questions)},
        )
        return questions
    except json.JSONDecodeError as e:
        print(f"[WARN] question_generator: 返回格式异常（JSON 解析失败 - {e}），使用 fallback 数据")
        print(f"  [原始响应前200字符]: {result[:200]}")
        log_ai_response(
            "question_generator.generate_questions",
            response={"raw": result, "error": f"JSON 解析失败: {e}"},
            metadata={"status": "json_error"},
        )
        return fallback_questions()

async def generate_applicant_note(job_info: dict, candidate_info: dict, resume_text: str = "", job_id: int | None = None) -> str:
    rag_context = await _build_rag_context(job_id)
    prompt = APPLICANT_AI_NOTE_PROMPT.format(
        job_title=job_info.get("title", ""),
        education_req=job_info.get("education_requirement", "不限"),
        work_exp_req=job_info.get("work_experience_requirement", 0),
        fresh_req=job_info.get("fresh_requirement", "不限"),
        work_content=job_info.get("work_content", ""),
        position_req=job_info.get("position_requirements", ""),
        rag_context=rag_context,
        name=candidate_info.get("name", ""),
        education=candidate_info.get("education", "未填写"),
        work_experience=candidate_info.get("work_experience", 0),
        is_fresh=candidate_info.get("is_fresh", "未填写"),
        skills=candidate_info.get("skills", "未填写"),
        resume_text=resume_text[:2000] if resume_text else "（未上传简历）",
    )
    try:
        note = await call_llm(prompt)
        log_ai_response(
            "question_generator.generate_applicant_note",
            response=note,
            metadata={"status": "success"},
        )
        return note
    except RuntimeError as e:
        print(f"[WARN] question_generator: AI 备注生成失败（模型调用错误 - {e}），使用 fallback 数据")
        return "AI备注生成失败"
    except Exception as e:
        print(f"[WARN] question_generator: AI 备注生成失败（未知错误 - {e}），使用 fallback 数据")
        return "AI备注生成失败"