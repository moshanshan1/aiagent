"""AI 模块日志工具。

记录 AI 请求与响应的摘要（不保留完整 prompt/response 文本），
便于追踪调用链路与排查问题。
"""

import json
import logging
import logging.handlers
import time
from pathlib import Path
from datetime import datetime

# 日志目录放在 ai 模块同级，便于集中查看
LOG_DIR = Path(__file__).resolve().parent / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

LOG_FILE = LOG_DIR / "ai_responses.log"


def _ensure_logger() -> logging.Logger:
    """初始化并返回专用 logger，按大小滚动保留最近 7 个文件。"""
    logger = logging.getLogger("ai_responses")
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    logger.propagate = False

    handler = logging.handlers.RotatingFileHandler(
        LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 单个日志 10MB
        backupCount=7,
        encoding="utf-8",
    )
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


def _summarize(obj: object, max_len: int = 120) -> str:
    """将对象转为简短摘要，仅保留前 max_len 字符。"""
    if obj is None:
        return ""
    try:
        text = json.dumps(obj, ensure_ascii=False, default=str)
    except Exception:
        text = str(obj)
    text = text.strip()
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"... ({len(text)} 字符略)"


def log_ai_request(function_name: str, *, metadata: dict | None = None) -> None:
    """记录一次 AI 调用请求的开始（调用前调用）。

    Args:
        function_name: 调用方函数名，例如 "question_generator.generate_questions"。
        metadata: 额外元信息，例如 model、temperature、round_index 等。
    """
    logger = _ensure_logger()
    entry = {
        "action": "request",
        "function": function_name,
        "metadata": metadata or {},
    }
    try:
        message = json.dumps(entry, ensure_ascii=False, default=str)
    except Exception:
        message = str(entry)
    logger.info(message)


def log_ai_response(
    function_name: str,
    *,
    response: object = None,
    metadata: dict | None = None,
    duration_ms: float | None = None,
    note: str = "",
    level: int = logging.INFO,
) -> None:
    """记录一次 AI 调用的返回结果（调用后调用）。

    不保存完整 prompt/response 文本，仅记录摘要与元信息。

    Args:
        function_name: 调用方函数名，例如 "question_generator.generate_questions"。
        response: 模型返回的结果（仅用于摘要提取，不保存全文）。
        metadata: 额外元信息，例如 model、temperature、round_index 等。
        duration_ms: 调用耗时（毫秒）。
        note: 简短描述本次返回的结果（例如 "转写完成，123 字"、"报告生成成功，skill=85"）。
        level: 日志级别，默认 INFO。
    """
    logger = _ensure_logger()
    summary = _summarize(response)
    entry = {
        "action": "response",
        "function": function_name,
        "response_summary": summary,
        "note": note,
        "duration_ms": duration_ms,
        "metadata": metadata or {},
    }
    try:
        message = json.dumps(entry, ensure_ascii=False, default=str)
    except Exception:
        message = str(entry)
    logger.log(level, message)


def log_ai_error(
    function_name: str,
    *,
    error: Exception | str | None = None,
    metadata: dict | None = None,
    duration_ms: float | None = None,
) -> None:
    """记录 AI 调用失败信息。"""
    err_msg = str(error) if error is not None else "未知错误"
    logger = _ensure_logger()
    entry = {
        "action": "response",
        "function": function_name,
        "response_summary": "",
        "note": f"错误: {err_msg}",
        "duration_ms": duration_ms,
        "metadata": metadata or {},
    }
    try:
        message = json.dumps(entry, ensure_ascii=False, default=str)
    except Exception:
        message = str(entry)
    logger.error(message)
