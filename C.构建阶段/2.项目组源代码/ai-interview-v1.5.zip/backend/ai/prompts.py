﻿"""Prompt 模板库"""

QUESTION_GENERATION_PROMPT = """你是一位资深的面试出题专家。请根据以下岗位信息和面试者信息，生成5道面试题目。

## 岗位信息
- 职位名称: {job_title}
- 学历要求: {education}
- 工作经验要求: {work_exp}年
- 工作内容: {work_content}
- 职位要求: {position_req}

## 岗位 JD 知识片段（来自已上传并解析完成的 JD 参考文档，供参考）
{rag_context}

## 面试者信息
- 姓名: {name}
- 学历: {candidate_edu}
- 工作经验: {candidate_exp}年
- 技能: {skills}
- 个人经历: {experience}

## 面试者简历
{resume_text}

请生成5道题目，包含技术题、行为题、情景题，难度适配面试者水平。
如果提供了简历内容，请针对简历中提到的项目经验、技术栈设计题目，让面试者结合实际经历回答。
JD 知识片段中可能包含「配套面试题示例」，这些是供参考的优秀题目，
请参考其难度和风格生成全新题目，不要照搬原文中的示例。
严格按以下JSON格式返回，不要包含其他内容:
[
  {{"question_text": "题目内容", "question_type": "技术"}},
  {{"question_text": "题目内容", "question_type": "技术"}},
  {{"question_text": "题目内容", "question_type": "行为"}},
  {{"question_text": "题目内容", "question_type": "情景"}},
  {{"question_text": "题目内容", "question_type": "情景"}}
]"""

APPLICANT_AI_NOTE_PROMPT = """你是一位HR助手。请对比以下面试者信息与岗位要求，给出面试官初步建议。

## 岗位要求
- 职位名称: {job_title}
- 学历要求: {education_req}
- 经验要求: {work_exp_req}年
- 应届/往届: {fresh_req}
- 工作内容: {work_content}
- 职位要求: {position_req}

## 岗位 JD 知识片段
{rag_context}

## 面试者信息
- 姓名: {name}
- 学历: {education}
- 工作经验: {work_experience}年
- 应届/往届: {is_fresh}
- 技能: {skills}

## 简历内容
{resume_text}

请从以下角度分析并输出两条建议（每条30字以内，用"▲"开头）：
1. 该候选人匹配岗位的优势
2. 面试时需重点考察的薄弱点

输出格式：
▲ 优势：xxx
▲ 注意：xxx"""

CONTENT_ANALYSIS_PROMPT = """你是一位面试评估专家。请分析以下面试回答的转写文本和语调特征，给出内容分析评价。

## 面试题目
{question_text}

## 面试者回答（语音转写）
{transcript}

## 语调特征
{tone_features}

请从以下角度分析（100字以内）：
1. 回答是否切题
2. 逻辑是否清晰
3. 表达是否流畅
4. 语调反映的自信程度

只返回分析文本，不要返回其他内容。"""

REPORT_ASSESSMENT_PROMPT = """你是一位资深HR总监。请根据以下面试信息，生成一份结构化的面试评估报告。

## 面试者: {interviewee_name}
## 应聘岗位: {job_title}

## 岗位 JD 参考片段（来自已上传并解析完成的 JD 文档，供评估时参考）
{rag_context}

## 面试回答汇总
{answers_summary}

请严格按以下JSON格式返回评估结果，不要包含其他内容:
{{
  "answer_summary": "对面试者整体回答的概括性总结（100字以内）",
  "highlights": "面试者的亮点（分条列出，用换行分隔）",
  "risks": "面试者的风险点（分条列出，用换行分隔）",
  "recommendation": "录用建议（一句话）",
  "skill_score": 85,
  "communication_score": 80,
  "logic_score": 82,
  "culture_score": 78,
  "body_language_score": 80
}}

评分标准：
- skill_score: 专业技能（0-100）
- communication_score: 沟通能力（0-100）
- logic_score: 逻辑思维（0-100）
- culture_score: 文化匹配（0-100）
- body_language_score: 表情与肢体语言表达（0-100），结合语调、表情、肢体语言综合评估"""