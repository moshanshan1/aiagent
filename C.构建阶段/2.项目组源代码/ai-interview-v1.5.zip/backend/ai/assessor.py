﻿"""五维度评估 + 报告生成"""
import json
import logging
from ai.llm_client import call_llm
from ai.logger import log_ai_request, log_ai_response, log_ai_error
from ai.fallbacks import fallback_assessment
from ai.prompts import REPORT_ASSESSMENT_PROMPT, CONTENT_ANALYSIS_PROMPT

# 延迟导入避免循环依赖
_rag_query_func = None

def _get_rag_query_func():
    global _rag_query_func
    if _rag_query_func is None:
        from services.jd_document_service import rag_search
        _rag_query_func = rag_search
    return _rag_query_func


async def _build_rag_context(job_id: int | None) -> str:
    """检索岗位 JD 文档并格式化为文本片段。"""
    if not job_id:
        return "（该岗位暂无上传的 JD 参考文档）"
    try:
        query_func = _get_rag_query_func()
        from database import SessionLocal
        db = SessionLocal()
        try:
            results = await query_func(db, job_id, "岗位要求 职责 技术栈 必备技能", top_k=5)
        finally:
            db.close()
        if not results:
            return "（该岗位暂无已解析的 JD 参考文档片段）"
        lines = []
        for i, r in enumerate(results, 1):
            lines.append(f"片段 {i}（来自《{r.get('document_title', '未知文档')}》，相似度 {r.get('score', 0)}）：\n{r.get('chunk_text', '')}")
        return "\n\n".join(lines)
    except Exception as e:
        print(f"[WARN] assessor: JD 知识检索失败 - {e}")
        return "（JD 知识检索暂不可用）"

async def analyze_content(question_text: str, transcript: str, tone_features: str) -> str:
    prompt = CONTENT_ANALYSIS_PROMPT.format(
        question_text=question_text, transcript=transcript, tone_features=tone_features)
    log_ai_request("assessor.analyze_content")
    try:
        analysis = await call_llm(prompt, temperature=0.5)
        log_ai_response(
            "assessor.analyze_content",
            response=analysis,
            note=f"内容分析完成 | {len(analysis)} 字",
        )
        return analysis
    except RuntimeError as e:
        print(f"[WARN] assessor: 内容分析失败（模型调用错误 - {e}），使用 fallback 数据")
        log_ai_error("assessor.analyze_content", error=str(e))
        return "内容分析暂不可用"
    except Exception as e:
        print(f"[WARN] assessor: 内容分析失败（未知错误 - {e}），使用 fallback 数据")
        log_ai_error("assessor.analyze_content", error=str(e))
        return "内容分析暂不可用"

async def assess_and_build_report(interviewee_name: str, job_title: str, answers_summary: str, job_id: int | None = None) -> dict:
    log_ai_request("assessor.assess_and_build_report", metadata={"interviewee": interviewee_name, "job": job_title})
    prompt = REPORT_ASSESSMENT_PROMPT.format(
        interviewee_name=interviewee_name,
        job_title=job_title,
        answers_summary=answers_summary,
        rag_context=await _build_rag_context(job_id),
    )
    try:
        result = await call_llm(prompt, temperature=0.5)
    except RuntimeError as e:
        print(f"[WARN] assessor: 报告生成失败（模型调用错误 - {e}），使用 fallback 数据")
        log_ai_error("assessor.assess_and_build_report", error=str(e))
        return fallback_assessment()

    try:
        start = result.find("{")
        end = result.rfind("}") + 1
        if start < 0 or end <= start:
            print("[WARN] assessor: 报告生成失败（返回格式异常，未找到 JSON 对象），使用 fallback 数据")
            log_ai_response(
                "assessor.assess_and_build_report",
                response={"error": "未找到 JSON 对象"},
                note="格式异常：解析结果中未找到 JSON 对象",
                level=logging.ERROR,
            )
            return fallback_assessment()
        report = json.loads(result[start:end])
        scores = {k: report.get(k) for k in ("skill_score", "communication_score", "logic_score", "culture_score", "body_language_score")}
        log_ai_response(
            "assessor.assess_and_build_report",
            response=report,
            note=f"报告生成成功 | 评分: {scores}",
        )
        return report
    except json.JSONDecodeError as e:
        print(f"[WARN] assessor: 报告生成失败（JSON 解析错误 - {e}），使用 fallback 数据")
        log_ai_response(
            "assessor.assess_and_build_report",
            response={"error": str(e)},
            note=f"JSON 解析失败: {e}",
            level=logging.ERROR,
        )
        return fallback_assessment()