"""语音分析后台任务。

把语调分析（analyze_tone）和内容分析（analyze_content）从 HTTP 请求主链路中拆出来，
通过 FastAPI BackgroundTasks 异步执行，让 submit_voice_answer 能立即返回下一题。
"""

import asyncio
import json

from sqlalchemy.orm import Session

from ai.assessor import analyze_content
from ai.tone_analyzer import analyze_tone
from database import SessionLocal
from models.interview import Answer, Question


def _is_invalid_transcript(text: str) -> bool:
    """与 routers/interviews.py 保持一致的判断逻辑。"""
    if not isinstance(text, str):
        return True

    stripped = text.strip()
    if not stripped:
        return True

    invalid_markers = [
        "[",
        "分析失败",
        "文件不存在",
        "模型返回为空",
        "Error code:",
        "access_denied",
        "Workspace endpoint access denied",
        "服务未配置",
    ]
    return any(marker in stripped for marker in invalid_markers)


async def analyze_voice_async(
    interview_id: int,
    question_id: int,
    audio_path: str,
    manual_transcript: str = "",
    tone_result: dict | None = None,
) -> None:
    """后台执行语音分析：转写 + 语调 + 内容分析，并更新 Answer。

    Args:
        interview_id: 面试 ID。
        question_id: 题目 ID。
        audio_path: 音频文件路径。
        manual_transcript: 面试者手动提供的转写文本，作为 fallback。
        tone_result: 如果已经同步完成 tone 分析，可直接传入避免重复调用。
    """
    db: Session = SessionLocal()
    try:
        if tone_result is None:
            tone_result = await asyncio.to_thread(analyze_tone, audio_path)
        transcript = tone_result.get("transcript", "")
        transcript = transcript.strip() if isinstance(transcript, str) else ""
        raw_invalid = _is_invalid_transcript(transcript)

        if raw_invalid:
            transcript = ""
        if not transcript and manual_transcript:
            transcript = manual_transcript.strip()
        if not transcript:
            transcript = "已提交语音回答。"

        tone_str = json.dumps(tone_result, ensure_ascii=False)

        answer = (
            db.query(Answer)
            .filter(Answer.interview_id == interview_id, Answer.question_id == question_id)
            .first()
        )
        if not answer:
            answer = Answer(
                interview_id=interview_id,
                question_id=question_id,
                audio_path=audio_path,
                transcript=transcript,
                tone_features=tone_str,
            )
            db.add(answer)
        else:
            answer.audio_path = audio_path
            answer.transcript = transcript
            answer.tone_features = tone_str

        question = db.query(Question).filter(Question.id == question_id).first()
        if question and transcript and transcript != "已提交语音回答。":
            try:
                content_analysis = await analyze_content(
                    question.question_text, transcript, tone_str
                )
                answer.content_analysis = content_analysis
            except Exception as e:
                print(f"[WARN] voice_analysis_service: 内容分析失败 - {e}")
                if not answer.content_analysis:
                    answer.content_analysis = "内容分析暂不可用"
        elif not answer.content_analysis:
            answer.content_analysis = "内容分析暂不可用"

        db.commit()
    except Exception as e:
        print(f"[ERROR] voice_analysis_service: 后台语音分析失败 - {e}")
    finally:
        db.close()
