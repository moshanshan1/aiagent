"""测试 ai 模块各接口的串行/并行性能。

直接在 conda agent 虚拟环境中运行：
    conda activate agent
    cd backend/doc
    python test_ai_parallel.py

运行前请确保：
- 已配置环境变量 LLM_API_KEY / LLM_BASE_URL / LLM_MODEL
- 已配置 DASHSCOPE_API_KEY（如需测试 tone_analyzer）
"""

import asyncio
import os
import time
from pathlib import Path

# 把 backend 目录加入 Python 路径，便于导入 ai 模块
BACKEND_DIR = Path(__file__).parent.parent.resolve()
import sys
sys.path.insert(0, str(BACKEND_DIR))

from ai.agent_chain import generate_initial_question, generate_next_question
from ai.assessor import analyze_content
from ai.llm_client import call_llm
from ai.question_generator import generate_questions
from ai.tone_analyzer import analyze_tone


# ───────────────────────────────────────────
# 测试数据
# ───────────────────────────────────────────
JOB_INFO = {
    "title": "Java后端开发工程师",
    "education_requirement": "本科",
    "work_experience_requirement": 5,
    "work_content": "负责电商核心交易系统的设计与开发，参与高并发、高可用架构演进。",
    "position_requirements": "精通Java、Spring Boot、Spring Cloud；熟悉MySQL、Redis、RocketMQ；有分布式事务经验。",
}

CANDIDATE_INFO = {
    "name": "张三",
    "education": "本科",
    "work_experience": 5,
    "skills": "Java, Spring Boot, MySQL, Redis",
    "experience": "5年Java后端开发经验，参与过电商订单系统建设。",
}

HISTORY = [
    {
        "round": 1,
        "question": "请介绍一下你最近一个项目的技术架构。",
        "question_type": "技术",
        "answer": "我最近参与的是一个电商订单系统，使用Spring Cloud微服务架构，MySQL做持久化，Redis做缓存。",
    }
]

PROMPT = "请用一句话总结Java后端开发的核心技能。"


def _audio_path() -> str | None:
    """查找一个可用的测试音频文件。"""
    candidates = [
        BACKEND_DIR / "uploads" / "audios" / "test.wav",
        BACKEND_DIR / "uploads" / "audios" / "test.mp3",
        Path(__file__).parent / "test.wav",
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    return None


# ───────────────────────────────────────────
# 测试任务定义
# ───────────────────────────────────────────
async def _task_call_llm():
    return await call_llm(PROMPT, temperature=0.7)


async def _task_generate_questions():
    return await generate_questions(JOB_INFO, CANDIDATE_INFO)


async def _task_generate_initial_question():
    return await generate_initial_question(JOB_INFO, CANDIDATE_INFO, max_rounds=5)


async def _task_generate_next_question():
    return await generate_next_question(
        JOB_INFO, CANDIDATE_INFO, HISTORY, round_index=2, max_rounds=5
    )


async def _task_analyze_content():
    return await analyze_content(
        "请介绍一下你最近一个项目的技术架构。",
        "我最近参与的是一个电商订单系统，使用Spring Cloud微服务架构。",
        '{"emotion_hint": "平稳自然", "confidence": "自信"}',
    )


async def _task_analyze_tone():
    audio = _audio_path()
    if audio is None:
        return "[SKIP] 未找到测试音频"
    # analyze_tone 是同步函数，扔到线程池执行
    return await asyncio.to_thread(analyze_tone, audio)


TASKS = [
    ("call_llm", _task_call_llm),
    ("generate_questions", _task_generate_questions),
    ("generate_initial_question", _task_generate_initial_question),
    ("generate_next_question", _task_generate_next_question),
    ("analyze_content", _task_analyze_content),
    ("analyze_tone", _task_analyze_tone),
]


# ───────────────────────────────────────────
# 测试执行
# ───────────────────────────────────────────
async def run_serial():
    """串行执行所有 AI 任务。"""
    results = {}
    start = time.perf_counter()
    for name, task in TASKS:
        t0 = time.perf_counter()
        try:
            result = await task()
            results[name] = {"status": "ok", "time": time.perf_counter() - t0, "preview": str(result)[:80]}
        except Exception as e:
            results[name] = {"status": "error", "time": time.perf_counter() - t0, "error": str(e)}
    total = time.perf_counter() - start
    return results, total


async def run_parallel():
    """并行执行所有 AI 任务。"""
    start = time.perf_counter()

    async def _run_one(name, task):
        t0 = time.perf_counter()
        try:
            result = await task()
            return name, {"status": "ok", "time": time.perf_counter() - t0, "preview": str(result)[:80]}
        except Exception as e:
            return name, {"status": "error", "time": time.perf_counter() - t0, "error": str(e)}

    coros = [_run_one(name, task) for name, task in TASKS]
    results = dict(await asyncio.gather(*coros))
    total = time.perf_counter() - start
    return results, total


def _print_results(label: str, results: dict, total: float):
    print(f"\n{'=' * 60}")
    print(f"[{label}] 总耗时: {total:.2f}s")
    print("=" * 60)
    for name, r in results.items():
        status = r["status"]
        t = r["time"]
        if status == "ok":
            preview = r.get("preview", "")
            print(f"  {name:30s} {t:6.2f}s  OK  {preview}")
        else:
            err = r.get("error", "")
            print(f"  {name:30s} {t:6.2f}s  ERROR: {err}")


async def main():
    print("AI 模块并行能力测试")
    print(f"LLM_MODEL: {os.getenv('LLM_MODEL', '未设置')}")
    print(f"测试音频: {_audio_path() or '未找到'}")

    serial_results, serial_total = await run_serial()
    _print_results("串行执行", serial_results, serial_total)

    parallel_results, parallel_total = await run_parallel()
    _print_results("并行执行", parallel_results, parallel_total)

    print(f"\n并行加速比: {serial_total / parallel_total:.2f}x")


if __name__ == "__main__":
    asyncio.run(main())
