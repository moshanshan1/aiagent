"""AI 模块日志工具。

将 AI 返回信息写入 ai/logs/ai_responses.log，便于排查模型输出、格式异常等问题。
"""

import json
import logging
import logging.handlers
from pathlib import Path
from datetime import datetime

# 日志目录放在 ai 模块同级，便于集中查看
LOG_DIR = Path(__file__).resolve().parent / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

LOG_FILE = LOG_DIR / "ai_responses.log"

# 限制单条记录长度，避免极端情况下日志过大
MAX_PROMPT_LEN = 4000
MAX_RESPONSE_LEN = 8000


def _ensure_logger() -> logging.Logger:
    """初始化并返回专用 logger，按大小滚动保留最近 7 个文件。"""
    logger = logging.getLogger("ai_responses")
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    logger.propagate = False

    handler = logging.handlers.RotatingFileHandler(
        LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 单个日志 10MB
        backupCount=7,
        encoding="utf-8",
    )
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


def _truncate(text: str | None, max_len: int) -> str:
    """截断文本并在超出时标注。"""
    if text is None:
        return ""
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"\n... [截断，原长度 {len(text)}]"


def log_ai_response(
    function_name: str,
    *,
    prompt: str | None = None,
    response: object = None,
    metadata: dict | None = None,
    level: int = logging.INFO,
) -> None:
    """记录一次 AI 调用与返回。

    Args:
        function_name: 调用方函数名，例如 "question_generator.generate_questions"。
        prompt: 发送给模型的提示词，可选。
        response: 模型返回的原始或结构化结果，会被 json.dumps 序列化。
        metadata: 额外元信息，例如 model、temperature、round_index 等。
        level: 日志级别，默认 INFO。
    """
    logger = _ensure_logger()

    try:
        response_text = json.dumps(response, ensure_ascii=False, default=str, indent=2)
    except Exception:
        response_text = str(response)

    entry = {
        "function": function_name,
        "prompt": _truncate(prompt, MAX_PROMPT_LEN),
        "response": _truncate(response_text, MAX_RESPONSE_LEN),
        "metadata": metadata or {},
    }

    try:
        message = json.dumps(entry, ensure_ascii=False, default=str)
    except Exception:
        message = str(entry)

    logger.log(level, message)


def log_ai_error(
    function_name: str,
    *,
    prompt: str | None = None,
    error: Exception | str | None = None,
    metadata: dict | None = None,
) -> None:
    """记录 AI 调用失败信息。"""
    err_msg = str(error) if error is not None else "未知错误"
    log_ai_response(
        function_name,
        prompt=prompt,
        response={"error": err_msg},
        metadata=metadata,
        level=logging.ERROR,
    )
