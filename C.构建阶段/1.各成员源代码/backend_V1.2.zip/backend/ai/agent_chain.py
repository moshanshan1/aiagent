"""基于 LangChain 的交互式面试 Agent。

负责在 agent 面试模式下动态生成初始题目与下一题。
面试者使用语音作答，语音会被转写为文本后作为历史回答传入本模块。
"""

import json
from typing import Any

from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field

from ai.logger import log_ai_response
from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL


class NextQuestionOutput(BaseModel):
    """Agent 下一题的结构化输出。"""

    question_text: str = Field(description="下一道面试题的内容，要求口语化、适合语音回答")
    question_type: str = Field(description="题目类型：技术/行为/情景")
    is_done: bool = Field(description="是否结束面试。达到最大轮数或信息已足够时设为 true")
    reason: str = Field(description="给出本题或结束面试的简要理由")


_parser = PydanticOutputParser(pydantic_object=NextQuestionOutput)


def _build_llm(temperature: float = 0.7) -> ChatOpenAI:
    """创建 LangChain ChatOpenAI 实例。"""
    return ChatOpenAI(
        model=LLM_MODEL,
        api_key=LLM_API_KEY,
        base_url=LLM_BASE_URL,
        temperature=temperature,
        max_retries=2,
    )


def _format_history(history: list[dict]) -> str:
    """将问答历史格式化为 JSON 字符串，便于 Prompt 阅读。"""
    if not history:
        return "暂无历史回答。"
    return json.dumps(history, ensure_ascii=False, indent=2)


def _fallback_next_question(round_index: int, max_rounds: int) -> dict:
    """LangChain 解析失败时的默认题目。"""
    if round_index > max_rounds:
        return {
            "question_text": "",
            "question_type": "",
            "is_done": True,
            "reason": "已达到最大回合数",
        }
    return {
        "question_text": "请结合你的项目经验，谈谈你认为自己最匹配这个岗位的能力。",
        "question_type": "技术",
        "is_done": False,
        "reason": "默认追问",
    }


def _build_prompt(is_initial: bool) -> ChatPromptTemplate:
    """构建 ChatPromptTemplate，初始题与追问题共用同一系统设定。"""
    system_template = """你是一位资深 AI 面试官，正在进行一场语音面试。
面试者通过麦克风语音作答，其回答已经被转写为文本。

## 岗位信息
- 职位名称: {job_title}
- 学历要求: {education}
- 工作经验要求: {work_exp}年
- 工作内容: {work_content}
- 职位要求: {position_req}

## 面试者信息
- 姓名: {name}
- 学历: {candidate_edu}
- 工作经验: {candidate_exp}年
- 技能: {skills}
- 个人经历: {experience}

## 面试规则
1. 当前是第 {round_index} 轮，最多 {max_rounds} 轮。
2. 每道题应适合语音回答，长度控制在 30-80 字。
3. 题目应基于历史回答进行追问、深挖或自然切换方向。
4. 如果已经收集到足够评价信息，或已经达到最大轮数，请设置 is_done=true 并返回空 question_text。
5. 题目类型只能是：技术、行为、情景之一。

{format_instructions}
"""

    human_template = """## 历史问答记录
{history}

请决定下一道面试题（或结束面试）。"""

    if is_initial:
        return ChatPromptTemplate.from_messages(
            [
                ("system", system_template),
                (
                    "human",
                    "这是面试的第一题，请根据岗位与候选人信息给出一道开场问题。",
                ),
            ]
        )
    return ChatPromptTemplate.from_messages(
        [
            ("system", system_template),
            ("human", human_template),
        ]
    )


async def generate_initial_question(
    job_info: dict, candidate_info: dict, max_rounds: int = 5
) -> dict:
    """生成 Agent 面试的第一道题。"""
    prompt = _build_prompt(is_initial=True)
    chain = prompt | _build_llm(temperature=0.7) | _parser

    try:
        inputs = {
            "job_title": job_info.get("title", ""),
            "education": job_info.get("education_requirement", "不限"),
            "work_exp": job_info.get("work_experience_requirement", 0),
            "work_content": job_info.get("work_content", ""),
            "position_req": job_info.get("position_requirements", ""),
            "name": candidate_info.get("name", ""),
            "candidate_edu": candidate_info.get("education", "未填写"),
            "candidate_exp": candidate_info.get("work_experience", 0),
            "skills": candidate_info.get("skills", "未填写"),
            "experience": candidate_info.get("experience", "未填写"),
            "round_index": 1,
            "max_rounds": max_rounds,
            "history": "暂无历史回答。",
            "format_instructions": _parser.get_format_instructions(),
        }
        result: NextQuestionOutput = await chain.ainvoke(inputs)
        output = {
            "question_text": result.question_text,
            "question_type": result.question_type,
            "is_done": result.is_done,
            "reason": result.reason,
        }
        log_ai_response(
            "agent_chain.generate_initial_question",
            prompt=prompt.format(**inputs),
            response=output,
            metadata={"round_index": 1, "max_rounds": max_rounds},
        )
        return output
    except Exception as e:
        print(f"[WARN] agent_chain: 初始题生成失败 - {e}，使用 fallback")
        return _fallback_next_question(1, max_rounds)


async def generate_next_question(
    job_info: dict,
    candidate_info: dict,
    history: list[dict],
    round_index: int,
    max_rounds: int,
) -> dict | None:
    """根据历史问答生成下一道题；返回 None 表示面试结束。

    Args:
        job_info: 岗位信息字典。
        candidate_info: 候选人信息字典。
        history: 历史问答列表，每项包含 round、question、answer、question_type。
        round_index: 当前要生成的题号（从 1 开始）。
        max_rounds: 最大回合数。

    Returns:
        dict 包含 question_text、question_type、is_done、reason；
        若 is_done 为 True 或解析失败达到上限，则返回 None。
    """
    prompt = _build_prompt(is_initial=False)
    chain = prompt | _build_llm(temperature=0.7) | _parser

    try:
        inputs = {
            "job_title": job_info.get("title", ""),
            "education": job_info.get("education_requirement", "不限"),
            "work_exp": job_info.get("work_experience_requirement", 0),
            "work_content": job_info.get("work_content", ""),
            "position_req": job_info.get("position_requirements", ""),
            "name": candidate_info.get("name", ""),
            "candidate_edu": candidate_info.get("education", "未填写"),
            "candidate_exp": candidate_info.get("work_experience", 0),
            "skills": candidate_info.get("skills", "未填写"),
            "experience": candidate_info.get("experience", "未填写"),
            "round_index": round_index,
            "max_rounds": max_rounds,
            "history": _format_history(history),
            "format_instructions": _parser.get_format_instructions(),
        }
        result: NextQuestionOutput = await chain.ainvoke(inputs)
        if result.is_done:
            log_ai_response(
                "agent_chain.generate_next_question",
                prompt=prompt.format(**inputs),
                response={"is_done": True, "reason": result.reason},
                metadata={"round_index": round_index, "max_rounds": max_rounds},
            )
            return None
        output = {
            "question_text": result.question_text,
            "question_type": result.question_type,
            "is_done": False,
            "reason": result.reason,
        }
        log_ai_response(
            "agent_chain.generate_next_question",
            prompt=prompt.format(**inputs),
            response=output,
            metadata={"round_index": round_index, "max_rounds": max_rounds},
        )
        return output
    except Exception as e:
        print(f"[WARN] agent_chain: 第{round_index}题生成失败 - {e}，使用 fallback")
        fallback = _fallback_next_question(round_index, max_rounds)
        return None if fallback.get("is_done") else fallback
