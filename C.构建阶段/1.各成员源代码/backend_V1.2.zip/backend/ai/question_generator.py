﻿"""AI 面试问题生成器"""
import json
from ai.llm_client import call_llm
from ai.logger import log_ai_response
from ai.fallbacks import fallback_questions
from ai.prompts import QUESTION_GENERATION_PROMPT, APPLICANT_AI_NOTE_PROMPT

async def generate_questions(job_info: dict, candidate_info: dict) -> list:
    prompt = QUESTION_GENERATION_PROMPT.format(
        job_title=job_info.get("title", ""),
        education=job_info.get("education_requirement", "不限"),
        work_exp=job_info.get("work_experience_requirement", 0),
        work_content=job_info.get("work_content", ""),
        position_req=job_info.get("position_requirements", ""),
        name=candidate_info.get("name", ""),
        candidate_edu=candidate_info.get("education", "未填写"),
        candidate_exp=candidate_info.get("work_experience", 0),
        skills=candidate_info.get("skills", "未填写"),
        experience=candidate_info.get("experience", "未填写"),
    )
    try:
        result = await call_llm(prompt, temperature=0.7)
    except RuntimeError as e:
        print(f"[WARN] question_generator: 模型调用错误 - {e}，使用 fallback 数据")
        return fallback_questions()

    try:
        start = result.find("[")
        end = result.rfind("]") + 1
        if start < 0 or end <= start:
            print("[WARN] question_generator: 返回格式异常（未找到 JSON 数组），使用 fallback 数据")
            print(f"  [原始响应前200字符]: {result[:200]}")
            log_ai_response(
                "question_generator.generate_questions",
                prompt=prompt,
                response={"raw": result, "error": "未找到 JSON 数组"},
                metadata={"status": "format_error"},
            )
            return fallback_questions()
        questions = json.loads(result[start:end])
        if len(questions) != 5:
            print(f"[WARN] question_generator: 返回格式异常（题目数={len(questions)}，期望5道），使用 fallback 数据")
            log_ai_response(
                "question_generator.generate_questions",
                prompt=prompt,
                response={"raw": result, "parsed_count": len(questions), "error": "题目数异常"},
                metadata={"status": "count_error"},
            )
            return fallback_questions()
        log_ai_response(
            "question_generator.generate_questions",
            prompt=prompt,
            response=questions,
            metadata={"status": "success", "count": len(questions)},
        )
        return questions
    except json.JSONDecodeError as e:
        print(f"[WARN] question_generator: 返回格式异常（JSON 解析失败 - {e}），使用 fallback 数据")
        print(f"  [原始响应前200字符]: {result[:200]}")
        log_ai_response(
            "question_generator.generate_questions",
            prompt=prompt,
            response={"raw": result, "error": f"JSON 解析失败: {e}"},
            metadata={"status": "json_error"},
        )
        return fallback_questions()

async def generate_applicant_note(job_info: dict, candidate_info: dict) -> str:
    prompt = APPLICANT_AI_NOTE_PROMPT.format(
        job_title=job_info.get("title", ""),
        education_req=job_info.get("education_requirement", "不限"),
        work_exp_req=job_info.get("work_experience_requirement", 0),
        fresh_req=job_info.get("fresh_requirement", "不限"),
        name=candidate_info.get("name", ""),
        education=candidate_info.get("education", "未填写"),
        work_experience=candidate_info.get("work_experience", 0),
        is_fresh=candidate_info.get("is_fresh", "未填写"),
        skills=candidate_info.get("skills", "未填写"),
    )
    try:
        note = await call_llm(prompt)
        log_ai_response(
            "question_generator.generate_applicant_note",
            prompt=prompt,
            response=note,
            metadata={"status": "success"},
        )
        return note
    except RuntimeError as e:
        print(f"[WARN] question_generator: AI 备注生成失败（模型调用错误 - {e}），使用 fallback 数据")
        return "AI备注生成失败"
    except Exception as e:
        print(f"[WARN] question_generator: AI 备注生成失败（未知错误 - {e}），使用 fallback 数据")
        return "AI备注生成失败"