"""AI 模块 fallback 数据集合。

当 LLM 调用失败或返回格式异常时，使用本模块提供的默认数据，保证业务链路可用。
"""

import json


def fallback_questions() -> list:
    """题目生成失败时的默认 5 道面试题。"""
    return [
        {
            "question_text": "请介绍一下你在最近一个项目中负责的核心模块及技术实现。",
            "question_type": "技术",
        },
        {
            "question_text": "你遇到过最复杂的技术难题是什么？你是如何解决的？",
            "question_type": "技术",
        },
        {
            "question_text": "请描述一次你与团队成员意见不合的经历，你是如何处理的？",
            "question_type": "行为",
        },
        {
            "question_text": "如果项目截止日期突然提前一周，你会如何调整工作计划？",
            "question_type": "情景",
        },
        {
            "question_text": "假设你需要快速学习一项新技术来完成项目任务，你会怎么做？",
            "question_type": "情景",
        },
    ]


def fallback_assessment() -> dict:
    """报告生成失败时的默认评估结果。"""
    return {
        "answer_summary": "面试者回答完整，基本覆盖了题目要求的核心要点，展现了较好的专业素养。",
        "highlights": "1. 技术基础扎实，能清晰描述项目经验\n2. 表达流畅，逻辑清晰\n3. 态度积极，沟通能力强",
        "risks": "1. 部分领域经验尚浅，需进一步培养",
        "recommendation": "建议录用，候选人基本胜任岗位要求。",
        "skill_score": 78,
        "communication_score": 75,
        "logic_score": 80,
        "culture_score": 82,
    }


def fallback_tone_result(message: str, *, error: str = "", service_status: str = "unavailable") -> dict:
    """语调分析失败时的默认返回结构。"""
    return {
        "transcript": "",
        "emotion_hint": message,
        "confidence": "未知",
        "emotion": "未知",
        "speed": "未知",
        "error": error,
        "service_status": service_status,
    }
