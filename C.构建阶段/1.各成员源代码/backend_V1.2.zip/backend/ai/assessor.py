﻿"""四维度评估 + 报告生成"""
import json
from ai.llm_client import call_llm
from ai.logger import log_ai_response
from ai.fallbacks import fallback_assessment
from ai.prompts import REPORT_ASSESSMENT_PROMPT, CONTENT_ANALYSIS_PROMPT

async def analyze_content(question_text: str, transcript: str, tone_features: str) -> str:
    prompt = CONTENT_ANALYSIS_PROMPT.format(
        question_text=question_text, transcript=transcript, tone_features=tone_features)
    try:
        analysis = await call_llm(prompt, temperature=0.5)
        log_ai_response(
            "assessor.analyze_content",
            prompt=prompt,
            response=analysis,
            metadata={"status": "success"},
        )
        return analysis
    except RuntimeError as e:
        print(f"[WARN] assessor: 内容分析失败（模型调用错误 - {e}），使用 fallback 数据")
        return "内容分析暂不可用"
    except Exception as e:
        print(f"[WARN] assessor: 内容分析失败（未知错误 - {e}），使用 fallback 数据")
        return "内容分析暂不可用"

async def assess_and_build_report(interviewee_name: str, job_title: str, answers_summary: str) -> dict:
    prompt = REPORT_ASSESSMENT_PROMPT.format(
        interviewee_name=interviewee_name, job_title=job_title, answers_summary=answers_summary)
    try:
        result = await call_llm(prompt, temperature=0.5)
    except RuntimeError as e:
        print(f"[WARN] assessor: 报告生成失败（模型调用错误 - {e}），使用 fallback 数据")
        return fallback_assessment()

    try:
        start = result.find("{")
        end = result.rfind("}") + 1
        if start < 0 or end <= start:
            print("[WARN] assessor: 报告生成失败（返回格式异常，未找到 JSON 对象），使用 fallback 数据")
            print(f"  [原始响应前200字符]: {result[:200]}")
            log_ai_response(
                "assessor.assess_and_build_report",
                prompt=prompt,
                response={"raw": result, "error": "未找到 JSON 对象"},
                metadata={"status": "format_error"},
            )
            return fallback_assessment()
        report = json.loads(result[start:end])
        log_ai_response(
            "assessor.assess_and_build_report",
            prompt=prompt,
            response=report,
            metadata={"status": "success"},
        )
        return report
    except json.JSONDecodeError as e:
        print(f"[WARN] assessor: 报告生成失败（JSON 解析错误 - {e}），使用 fallback 数据")
        print(f"  [原始响应前200字符]: {result[:200]}")
        log_ai_response(
            "assessor.assess_and_build_report",
            prompt=prompt,
            response={"raw": result, "error": f"JSON 解析错误: {e}"},
            metadata={"status": "json_error"},
        )
        return fallback_assessment()