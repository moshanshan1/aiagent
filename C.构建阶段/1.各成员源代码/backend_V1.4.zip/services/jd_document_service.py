"""JD 文档上传 / 解析 / RAG 检索服务。

使用 DashScope text-embedding-v4 生成向量，存储到 MySQL 的 jd_document_chunks 表。
"""

import json
import os
from pathlib import Path

from openai import AsyncOpenAI
from sqlalchemy.orm import Session
from fastapi import HTTPException

from ai.logger import log_ai_request, log_ai_response
from config import DASHSCOPE_API_KEY, DASHSCOPE_BASE_URL, EMBEDDING_DIMENSIONS, EMBEDDING_MODEL, JD_DOC_DIR
from models.job import Job
from models.jd_document import JdDocument, JdDocumentChunk

CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

# 全局异步 DashScope 客户端（复用连接池）
_dashscope_async_client: AsyncOpenAI | None = None


def _get_dashscope_async_client() -> AsyncOpenAI:
    """获取或创建全局异步 DashScope 客户端。"""
    global _dashscope_async_client
    if _dashscope_async_client is None:
        base_url = (DASHSCOPE_BASE_URL or "https://dashscope.aliyuncs.com/compatible-mode/v1").rstrip("/")
        _dashscope_async_client = AsyncOpenAI(api_key=DASHSCOPE_API_KEY, base_url=base_url)
    return _dashscope_async_client


async def _embed_texts(texts: list[str]) -> list[list[float]]:
    """异步调用 DashScope text-embedding-v4 批量生成向量。"""
    if not DASHSCOPE_API_KEY or DASHSCOPE_API_KEY.startswith("your-"):
        raise RuntimeError("DASHSCOPE_API_KEY 未配置")

    log_ai_request("jd_document_service._embed_texts", metadata={"chunks": len(texts), "model": EMBEDDING_MODEL})
    client = _get_dashscope_async_client()
    resp = await client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=texts,
        dimensions=EMBEDDING_DIMENSIONS,
    )
    vectors = [item.embedding for item in resp.data]

    log_ai_response(
        "jd_document_service._embed_texts",
        response={"vectors": len(vectors)},
        note=f"向量生成完成 | {len(texts)} 个片段 → {len(vectors)} 个向量",
        metadata={"model": EMBEDDING_MODEL},
    )
    return vectors


def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """简单按字符切分文本。"""
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks


def _parse_document(file_path: str) -> str:
    """解析 txt / docx / pdf。"""
    path = Path(file_path)
    ext = path.suffix.lower()

    if ext == ".txt":
        return path.read_text(encoding="utf-8")

    if ext == ".docx":
        from docx import Document
        doc = Document(str(path))
        return "\n".join(p.text for p in doc.paragraphs)

    if ext == ".pdf":
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(path))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        except Exception:
            return ""

    return ""


def create_jd_document(db: Session, job_id: int, title: str, file_path: str, user) -> JdDocument:
    """创建 JD 文档记录并触发后台解析。"""
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="岗位不存在")
    if job.created_by != user.id:
        raise HTTPException(status_code=403, detail="仅岗位创建者可上传文档")

    doc = JdDocument(
        job_id=job_id,
        title=title,
        file_url=file_path,
        status="processing",
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)
    return doc


async def process_jd_document(db: Session, document_id: int) -> None:
    """后台异步解析文档：切分、向量化、存入数据库。"""
    doc = db.query(JdDocument).filter(JdDocument.id == document_id).first()
    if not doc:
        print(f"[WARN] process_jd_document: 文档 {document_id} 不存在")
        return

    try:
        from main import BASE_DIR as _BASE_DIR
        file_path = Path(_BASE_DIR) / doc.file_url.lstrip("/")
        text = _parse_document(str(file_path))
        if not text.strip():
            raise ValueError("文档内容为空或解析失败")

        chunks = _chunk_text(text)
        if not chunks:
            raise ValueError("文档切分后为空")

        vectors = await _embed_texts(chunks)
        if len(vectors) != len(chunks):
            raise ValueError(f"向量数量与切片数量不一致: {len(vectors)} vs {len(chunks)}")

        # 删除旧切片
        db.query(JdDocumentChunk).filter(JdDocumentChunk.document_id == document_id).delete()

        for idx, (chunk_text, vector) in enumerate(zip(chunks, vectors)):
            chunk = JdDocumentChunk(
                document_id=document_id,
                job_id=doc.job_id,
                chunk_text=chunk_text,
                embedding_vector=json.dumps(vector),
                chunk_index=idx,
            )
            db.add(chunk)

        doc.status = "completed"
        doc.parsed_chunks = len(chunks)
        doc.error_message = None
        db.commit()
        print(f"[INFO] JD 文档 {document_id} 解析完成，共 {len(chunks)} 个切片")
    except Exception as e:
        print(f"[ERROR] process_jd_document: 文档 {document_id} 解析失败 - {e}")
        doc.status = "failed"
        doc.error_message = str(e)
        db.commit()


def list_jd_documents(db: Session, job_id: int) -> list[JdDocument]:
    return db.query(JdDocument).filter(JdDocument.job_id == job_id).order_by(JdDocument.created_at.desc()).all()


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    import math
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


async def query_jd_documents(db: Session, job_id: int, query: str, top_k: int = 3) -> list[dict]:
    """对指定岗位的 JD 文档做异步 RAG 检索。"""
    query_vector = (await _embed_texts([query]))[0]

    chunks = (
        db.query(JdDocumentChunk)
        .join(JdDocument)
        .filter(JdDocumentChunk.job_id == job_id, JdDocument.status == "completed")
        .all()
    )

    scored = []
    for chunk in chunks:
        try:
            vector = json.loads(chunk.embedding_vector)
            score = _cosine_similarity(query_vector, vector)
            scored.append((score, chunk))
        except Exception:
            continue

    scored.sort(key=lambda x: x[0], reverse=True)
    results = []
    for score, chunk in scored[:top_k]:
        results.append({
            "document_id": chunk.document_id,
            "document_title": chunk.document.title if chunk.document else None,
            "chunk_text": chunk.chunk_text,
            "score": round(score, 3),
        })
    return results
