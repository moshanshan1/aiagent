"""JD RAG 可行性测试脚本（本地 Embedding 模型）。

不修改项目其他文件，独立运行。

依赖：
    pip install chromadb sentence-transformers python-docx

运行：
    cd backend/rag_test
    python rag_demo.py
"""

import json
import os
import sys
from pathlib import Path

# 使用本地中文 Embedding 模型，首次运行会自动下载
EMBEDDING_MODEL = "BAAI/bge-small-zh-v1.5"
TOP_K = 2


def _check_dependencies():
    try:
        import chromadb
        import sentence_transformers
    except ImportError as e:
        print("[ERROR] 缺少依赖，请先安装：")
        print("    pip install chromadb sentence-transformers python-docx")
        print(f"详细错误: {e}")
        sys.exit(1)


def _load_seed_jobs() -> list[dict]:
    seed_path = Path(__file__).parent / "seed_jobs.json"
    with open(seed_path, "r", encoding="utf-8") as f:
        return json.load(f)["jobs"]


def _parse_txt(file_path: Path) -> str:
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def _parse_docx(file_path: Path) -> str:
    from docx import Document
    doc = Document(str(file_path))
    return "\n".join(p.text for p in doc.paragraphs)


def _parse_document(file_path: Path) -> str:
    """解析 TXT / DOCX 文件为文本。"""
    ext = file_path.suffix.lower()
    if ext == ".txt":
        return _parse_txt(file_path)
    if ext == ".docx":
        return _parse_docx(file_path)
    return ""


def _load_seed_documents() -> list[dict]:
    """加载 seed_docs/ 目录下的文档，解析为 JD 文本。"""
    docs_dir = Path(__file__).parent / "seed_docs"
    if not docs_dir.exists():
        return []

    results = []
    for file_path in sorted(docs_dir.iterdir()):
        if file_path.suffix.lower() not in (".txt", ".docx", ".pdf"):
            continue
        text = _parse_document(file_path)
        if text.strip():
            results.append({
                "job_id": f"doc_{file_path.stem}",
                "title": file_path.stem,
                "doc_text": text,
                "source": str(file_path),
            })
    return results


def _jd_text(job: dict) -> str:
    """把岗位信息拼成一段文本用于向量化。"""
    return (
        f"职位名称: {job.get('title', '')}\n"
        f"工作内容: {job.get('work_content', '')}\n"
        f"职位要求: {job.get('position_requirements', '')}\n"
        f"学历要求: {job.get('education_requirement', '')}\n"
        f"经验要求: {job.get('work_experience_requirement', 0)}年"
    )


def _build_vector_store(jobs: list[dict], docs: list[dict]):
    """用本地 Embedding 模型把 JD 向量化并存入 ChromaDB。"""
    from chromadb.config import Settings
    import chromadb
    from sentence_transformers import SentenceTransformer

    print(f"[INFO] 正在加载本地 Embedding 模型: {EMBEDDING_MODEL} ...")
    model = SentenceTransformer(EMBEDDING_MODEL)

    db_dir = Path(__file__).parent / "chroma_db"
    db_dir.mkdir(parents=True, exist_ok=True)

    client = chromadb.PersistentClient(
        path=str(db_dir),
        settings=Settings(anonymized_telemetry=False),
    )
    collection = client.get_or_create_collection("jd_questions")

    documents = []
    metadatas = []
    ids = []

    # 1. JSON 种子岗位
    for job in jobs:
        documents.append(_jd_text(job))
        metadatas.append({
            "job_id": job["job_id"],
            "title": job["title"],
            "questions": json.dumps(job["questions"], ensure_ascii=False),
            "source": "seed_jobs.json",
        })
        ids.append(job["job_id"])

    # 2. 文档岗位
    for doc in docs:
        documents.append(doc["doc_text"])
        metadatas.append({
            "job_id": doc["job_id"],
            "title": doc["title"],
            "questions": "[]",
            "source": doc["source"],
        })
        ids.append(doc["job_id"])

    if not documents:
        print("[WARN] 没有可向量化的岗位数据")
        return client, model, collection

    print(f"[INFO] 正在向量化 {len(documents)} 条岗位数据（JSON: {len(jobs)}, 文档: {len(docs)}）并写入向量库 ...")
    collection.add(
        ids=ids,
        documents=documents,
        metadatas=metadatas,
    )
    print(f"[INFO] 向量库构建完成，存储路径: {db_dir}")
    return client, model, collection


def _retrieve_similar(collection, model, query_job: dict, top_k: int = TOP_K) -> list[dict]:
    """根据新 JD 检索最相似的岗位及其示例题目。"""
    query_text = _jd_text(query_job)
    query_embedding = model.encode(query_text).tolist()

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k,
        include=["documents", "metadatas", "distances"],
    )

    examples = []
    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        try:
            questions = json.loads(meta.get("questions", "[]"))
        except Exception:
            questions = []
        examples.append({
            "job_id": meta.get("job_id", ""),
            "title": meta.get("title", ""),
            "job_text": doc,
            "questions": questions,
            "source": meta.get("source", "unknown"),
            "distance": dist,
        })
    return examples


def _build_augmented_prompt(query_job: dict, examples: list[dict]) -> str:
    """把检索到的示例拼进 prompt，展示 RAG 增强后的效果。"""
    rag_block = "## 参考的同类型岗位面试题（仅供参考，请生成新题，不要照搬）\n\n"
    if not examples:
        rag_block = "（未检索到相似岗位示例）\n"
    for i, ex in enumerate(examples, 1):
        rag_block += f"### 参考岗位 {i}：{ex['title']}（来源: {ex['source']}）\n"
        rag_block += f"{ex['job_text']}\n\n"
        if ex["questions"]:
            rag_block += "示例题目：\n"
            for q in ex["questions"]:
                rag_block += f"- [{q['question_type']}] {q['question_text']}\n"
        rag_block += "\n"

    prompt = f"""你是一位资深的面试出题专家。请根据以下岗位信息生成 5 道面试题目。

## 目标岗位信息
- 职位名称: {query_job.get('title', '')}
- 学历要求: {query_job.get('education_requirement', '')}
- 工作经验要求: {query_job.get('work_experience_requirement', 0)}年
- 工作内容: {query_job.get('work_content', '')}
- 职位要求: {query_job.get('position_requirements', '')}

{rag_block}
## 出题要求
- 生成 5 道题，包含技术题、行为题、情景题
- 难度适配岗位要求
- 严格按以下 JSON 数组格式返回，不要包含其他内容：
[
  {{"question_text": "题目内容", "question_type": "技术"}},
  {{"question_text": "题目内容", "question_type": "技术"}},
  {{"question_text": "题目内容", "question_type": "行为"}},
  {{"question_text": "题目内容", "question_type": "情景"}},
  {{"question_text": "题目内容", "question_type": "情景"}}
]
"""
    return prompt


def _try_llm_call(prompt: str) -> str | None:
    """如果环境变量配置了 LLM，尝试调用项目里的 ai.llm_client；否则返回 None。"""
    if not os.getenv("LLM_API_KEY"):
        return None
    try:
        # 把项目根目录加入 path，从而能导入 backend 下的 ai 模块
        backend_dir = Path(__file__).parent.parent.resolve()
        sys.path.insert(0, str(backend_dir))
        import asyncio
        from ai.llm_client import call_llm
        return asyncio.run(call_llm(prompt, temperature=0.7))
    except Exception as e:
        print(f"[WARN] 调用 LLM 失败，仅打印 prompt: {e}")
        return None


def main():
    _check_dependencies()

    jobs = _load_seed_jobs()
    docs = _load_seed_documents()
    client, model, collection = _build_vector_store(jobs, docs)

    if docs:
        print("\n" + "=" * 60)
        print("[TEST] 已解析的文档岗位")
        print("=" * 60)
        for doc in docs:
            print(f"\n  来源: {doc['source']}")
            print(f"  内容前 200 字: {doc['doc_text'][:200]}...")

    # 测试用的新 JD：与 "Java后端开发工程师" 相似，但偏向金融/支付领域
    query_job = {
        "title": "Java高级后端开发（支付方向）",
        "education_requirement": "本科",
        "work_experience_requirement": 5,
        "work_content": "负责支付清算系统的核心模块开发，保障资金安全和高可用，参与分布式架构设计与性能优化。",
        "position_requirements": "精通Java、Spring Cloud；熟悉MySQL、Redis、Kafka；有支付、金融或高并发项目经验；了解分布式一致性。",
    }

    print("\n" + "=" * 60)
    print("[TEST] 新岗位 JD")
    print("=" * 60)
    print(_jd_text(query_job))

    print("\n" + "=" * 60)
    print(f"[TEST] 检索 Top-{TOP_K} 相似岗位")
    print("=" * 60)
    examples = _retrieve_similar(collection, model, query_job, top_k=TOP_K)
    for i, ex in enumerate(examples, 1):
        print(f"\n[第 {i} 条] 相似度距离: {ex['distance']:.4f}")
        print(f"  岗位: {ex['title']}")
        print(f"  来源: {ex['source']}")
        print(f"  示例题目数: {len(ex['questions'])}")
        for q in ex["questions"][:2]:
            print(f"    - [{q['question_type']}] {q['question_text']}")

    prompt = _build_augmented_prompt(query_job, examples)

    print("\n" + "=" * 60)
    print("[TEST] 增强后的 Prompt（前 2000 字符）")
    print("=" * 60)
    print(prompt[:2000])
    print("..." if len(prompt) > 2000 else "")

    print("\n" + "=" * 60)
    print("[TEST] 尝试调用 LLM 生成题目")
    print("=" * 60)
    llm_response = _try_llm_call(prompt)
    if llm_response:
        print(llm_response)
    else:
        print("[INFO] 未配置 LLM_API_KEY，跳过 LLM 调用。")
        print("       如需测试生成效果，可在环境变量中配置 LLM_API_KEY / LLM_BASE_URL / LLM_MODEL。")


if __name__ == "__main__":
    main()
