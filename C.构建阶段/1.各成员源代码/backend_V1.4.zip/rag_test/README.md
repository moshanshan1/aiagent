# JD RAG 可行性测试

独立测试脚本，不修改项目其他文件。

## 文件说明

- `seed_jobs.json`：5 条示例岗位 JD 及对应面试题，作为 RAG 种子库
- `seed_docs/`：可放置 TXT / Word / PDF 格式的岗位 JD 文件，测试文档解析
- `rag_demo.py`：完整 demo，包含文档解析、向量库构建、相似 JD 检索、增强 Prompt 生成
- `chroma_db/`：运行后自动生成的向量库存储目录（可删除重建）

## 依赖安装

```bash
cd backend/rag_test
pip install chromadb sentence-transformers python-docx
```

依赖说明：

- `chromadb`：本地向量库
- `sentence-transformers`：本地中文 Embedding 模型
- `python-docx`：解析 `.docx` 文件

## 运行测试

```bash
python rag_demo.py
```

首次运行会自动下载本地 Embedding 模型：

```text
BAAI/bge-small-zh-v1.5
```

模型大小约 100MB 左右，下载一次后缓存到本地。

## 测试内容

1. 加载 `seed_docs/` 目录下 TXT / Word / PDF 格式的岗位 JD 文件
2. 用 `BAAI/bge-small-zh-v1.5` 把 JD 文本转换为向量
3. 存入本地 `chroma_db` 向量库
4. 输入一条新的测试 JD（Java 高级后端 / 支付方向）
5. 检索最相似的 Top-2 岗位
6. 打印增强后的 prompt
7. 如果配置了 `LLM_API_KEY`，会尝试调用 LLM 生成 5 道面试题

## 可选：接入项目 LLM

在运行前设置环境变量：

```bash
set LLM_API_KEY=your-key
set LLM_BASE_URL=https://your-api-endpoint
set LLM_MODEL=qwen-3.6plus
```

如果未配置，脚本只会展示检索结果和增强后的 prompt，不会报错。

## 评估可行性

运行后重点看：

- 检索出的岗位是否确实与测试 JD 相关
- 检索出的示例题目是否能被复用到目标岗位
- 增强后的 prompt 是否比原 prompt 信息量更大

如果 Top-K 检索结果相关度高，说明 JD RAG 在该项目里可行。
