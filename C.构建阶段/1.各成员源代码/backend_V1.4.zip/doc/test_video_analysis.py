r"""千问 Omni 视频/截图分析测试脚本。

基于 Qwen-Omni 多模态能力，分析面试者视频中的肢体语言、表情、眼神等。

依赖：
    pip install openai

运行（agent 环境）：
    cd backend/doc
    python test_video_analysis.py --video C:\path\to\interview.mp4

运行前请设置环境变量：
    set DASHSCOPE_API_KEY=your-key
    set DASHSCOPE_BASE_URL=https://{WorkspaceId}.cn-beijing.maas.aliyuncs.com/compatible-mode/v1
"""

import argparse
import base64
import json
import os
import sys
from pathlib import Path

from openai import OpenAI


# ═══════════════════════════════════════════════════
# 配置
# ═══════════════════════════════════════════════════
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY", "sk-ws-H.EMHLPMI.c9HI.MEUCIQDANZ9dGrq4cq-_p_ZGm5TZJcz4Jj5AaEERDimwI3cKhgIgKW17iQb6ActCrpx1BUEzJySBzju8l92hoAW8y8ISCF8")
DASHSCOPE_BASE_URL = os.getenv(
    "DASHSCOPE_BASE_URL",
    "https://ws-83p69eaoba9g00a6.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
)
VIDEO_MODEL = os.getenv("VIDEO_MODEL", "qwen3.5-omni-plus")
MAX_VIDEO_MB = 10  # 建议单个视频不超过 10MB，否则 base64 后很大


# ═══════════════════════════════════════════════════
# 工具函数
# ══════════════════════════════════════════════════
def _encode_video(video_path: str) -> str:
    """将视频文件编码为 Base64。"""
    with open(video_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def _check_video_size(video_path: str, max_mb: int = MAX_VIDEO_MB) -> None:
    """检查视频文件大小。"""
    size_mb = Path(video_path).stat().st_size / (1024 * 1024)
    if size_mb > max_mb:
        print(f"[WARN] 视频文件 {size_mb:.1f}MB，建议压缩到 {max_mb}MB 以内，否则上传很慢")
    return size_mb


def _build_analysis_prompt() -> str:
    """构建面试视频分析 prompt，要求模型输出结构化 JSON。"""
    return """你是一位专业的面试肢体语言评估专家。请仔细观察视频中面试者的表现，并严格按以下 JSON 格式返回分析结果，不要包含其他内容：

{
  "overall_impression": "总体印象，30字以内",
  "text":"面试者说了什么内容，完整复述",
  "eye_contact": "眼神交流：优秀/良好/一般/较差",
  "posture": "坐姿/姿态：端正/自然/松懈/驼背",
  "facial_expression": "面部表情：自信/紧张/自然/严肃/积极",
  "gesture": "手势运用：适当/较少/过多/不自然",
  "emotion": "情绪状态：积极/中性/紧张/消极",
  "confidence": "自信程度：高/中/低",
  "notes": "其他值得注意的观察，50字以内",
}

注意：
1. 如果视频中没有出现人脸，请说明无法分析。
2. 评价要客观，基于视频中可观察到的内容。
3. 必须严格返回 JSON，不要添加 markdown 代码块标记。"""


def analyze_video(video_path: str) -> dict:
    """调用 Qwen-Omni 分析面试视频。"""
    if not DASHSCOPE_API_KEY or DASHSCOPE_API_KEY.startswith("your-"):
        raise RuntimeError("请先设置 DASHSCOPE_API_KEY 环境变量")

    if "{WorkspaceId}" in DASHSCOPE_BASE_URL:
        raise RuntimeError("请将 DASHSCOPE_BASE_URL 中的 {WorkspaceId} 替换为实际的业务空间ID")

    if not Path(video_path).is_file():
        raise FileNotFoundError(f"视频文件不存在: {video_path}")

    size_mb = _check_video_size(video_path)
    print(f"[INFO] 正在分析视频: {video_path} ({size_mb:.1f}MB)")
    print(f"[INFO] 使用模型: {VIDEO_MODEL}")

    client = OpenAI(
        api_key=DASHSCOPE_API_KEY,
        base_url=DASHSCOPE_BASE_URL,
    )

    base64_video = _encode_video(video_path)
    print(f"[INFO] Base64 编码完成，长度: {len(base64_video)} 字符")

    completion = client.chat.completions.create(
        model=VIDEO_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "video_url",
                        "video_url": {"url": f"data:;base64,{base64_video}"},
                    },
                    {"type": "text", "text": _build_analysis_prompt()},
                ],
            },
        ],
        modalities=["text"],  # 只需要文本分析结果
        stream=True,
        stream_options={"include_usage": True},
    )

    full_content = ""
    for chunk in completion:
        if chunk.choices and chunk.choices[0].delta.content:
            full_content += chunk.choices[0].delta.content
        if hasattr(chunk, "usage") and chunk.usage:
            print(f"[INFO] Token 使用: {chunk.usage}")

    if not full_content.strip():
        raise RuntimeError("模型返回为空")

    # 尝试解析 JSON
    try:
        # 有时模型会包 markdown 代码块
        text = full_content.strip()
        if text.startswith("```"):
            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:].strip()
        result = json.loads(text)
        return result
    except json.JSONDecodeError as e:
        print(f"[WARN] JSON 解析失败: {e}")
        print(f"[WARN] 原始输出:\n{full_content}")
        return {
            "raw_output": full_content,
            "parse_error": str(e),
        }


def main():
    parser = argparse.ArgumentParser(description="面试视频肢体语言分析测试")
    parser.add_argument("--video", required=True, help="要分析的视频文件路径")
    parser.add_argument("--output", default=None, help="结果保存路径（可选）")
    args = parser.parse_args()

    try:
        result = analyze_video(args.video)

        print("\n" + "=" * 60)
        print("[RESULT] 视频分析结果")
        print("=" * 60)
        print(json.dumps(result, ensure_ascii=False, indent=2))

        if args.output:
            Path(args.output).write_text(
                json.dumps(result, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            print(f"\n[INFO] 结果已保存到: {args.output}")

    except Exception as e:
        print(f"\n[ERROR] 分析失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
