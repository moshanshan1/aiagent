"""面试媒体分析诊断脚本。

模拟后端 submit_media_answer → analyze_media → 归一化完整链路，
逐步输出每一阶段结果，帮助定位问题出在哪个环节。

用法：
    cd backend/doc
    conda activate agent
    python diag_media_analysis.py --file C:/path/to/answer.mp4
    python diag_media_analysis.py --file C:/path/to/answer.webm
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path
import subprocess

def _transcode_to_h264(src_path: Path) -> Path:
    """将视频转码为 H.264/AAC 的标准 MP4 格式。

    使用 FFmpeg 进行转码，输出到临时文件后替换原文件。
    若 FFmpeg 不可用或转码失败，返回原文件路径并打印警告。
    """
    import tempfile
    tmp_fd, tmp_path_str = tempfile.mkstemp(suffix=".mp4", dir=str(src_path.parent))
    os.close(tmp_fd)
    tmp_path = Path(tmp_path_str)

    cmd = [
        "ffmpeg", "-y", "-i", str(src_path),
        "-c:v", "libx264", "-preset", "fast", "-crf", "23",
        "-c:a", "aac", "-b:a", "128k",
        "-movflags", "+faststart",
        "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",  # 确保宽高为偶数（H.264 要求）
        str(tmp_path),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            print(f"[WARN] FFmpeg 转码失败 (code={result.returncode}): {result.stderr[:400]}")
            tmp_path.unlink(missing_ok=True)
            return src_path
        # 转码成功：用临时文件替换原文件
        final_path = src_path.with_suffix(".mp4")
        if final_path.exists():
            final_path.unlink(missing_ok=True)
        tmp_path.rename(final_path)
        return final_path
    except FileNotFoundError:
        print("[WARN] FFmpeg 未安装，跳过视频转码")
        tmp_path.unlink(missing_ok=True)
        return src_path
    except Exception as e:
        print(f"[WARN] FFmpeg 转码异常: {e}")
        tmp_path.unlink(missing_ok=True)
        return src_path


# 将项目根目录加入 sys.path 以便导入后端模块
_BACKEND = str(Path(__file__).resolve().parent.parent)
if _BACKEND not in sys.path:
    sys.path.insert(0, _BACKEND)


def step(msg: str, indent: int = 0) -> None:
    prefix = "  " * indent + "•"
    print(f"\n{prefix} {msg}")


def pretty(obj: object, label: str = "") -> None:
    if label:
        print(f"  [{label}]")
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description="面试媒体分析诊断工具")
    parser.add_argument("--file", required=True, help="要分析的媒体文件路径")
    parser.add_argument("--dump-raw", action="store_true", help="同时打印原始 Base64 和 API 返回")
    args = parser.parse_args()

    file_path = Path(args.file)
    if not file_path.is_file():
        print(f"[ERROR] 文件不存在: {file_path}")
        sys.exit(1)

    from utils.file_storage import _get_media_type

    # ── 第 1 步：文件基础信息 ──────────────────────────────
    step("文件信息")
    ext = file_path.suffix.lower()
    size_kb = file_path.stat().st_size / 1024
    print(f"  路径: {file_path.resolve()}")
    print(f"  大小: {size_kb:.1f} KB ({file_path.stat().st_size} bytes)")
    print(f"  后缀: {ext}")

    # ── 第 2 步：模拟 _get_media_type（不含 content_type 推断） ──
    step("媒体类型识别 (通过后缀)")
    try:
        media_type = _get_media_type(file_path.name, None)
        print(f"  判定结果: {media_type}")
    except ValueError as e:
        print(f"  判定失败: {e}")
        sys.exit(1)

    #sym:_transcode_to_h264 载入测试
    print("  [SYM] 准备转码 ...")
    result_path = _transcode_to_h264(file_path)
    if result_path != file_path:
        print(f"  [SYM] 转码完成: {file_path.name} -> {result_path.name}")
        file_path = result_path  # 后续分析使用转码后的文件
    else:
        print(f"  [SYM] 无需转码或转码失败，继续使用原文件")
    # 确保视频为 H.264 编码，避免 API 报错

    # ── 第 3 步：调用 analyze_media ──────────────────────────
    from ai.video_analyzer import analyze_media

    step(f"调用 analyze_media('{file_path}')")
    print("  此步骤会实际请求 Qwen-Omni API，请耐心等待...")
    start = time.perf_counter()

    try:
        result = analyze_media(str(file_path))
        elapsed = time.perf_counter() - start
    except Exception as e:
        elapsed = time.perf_counter() - start
        print(f"  [ERROR] analyze_media 抛出异常（耗时 {elapsed:.1f}s）: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    print(f"  耗时: {elapsed:.1f}s")
    pretty(result, label="analyze_media 原始返回")

    # ── 第 4 步：检查关键字段 ──────────────────────────────
    step("字段完整性检查")

    transcript = result.get("transcript", "")
    transcript_ok = bool(transcript and transcript.strip() and transcript != "已提交语音回答。")

    from routers.interviews import _is_invalid_transcript

    invalid_reason = None
    if _is_invalid_transcript(transcript):
        invalid_reason = f"转写文本无效: '{transcript[:80]}...'"
        transcript_ok = False

    checks = {
        "transcript": f"{'✅' if transcript_ok else '❌'} 转写文本 (长度 {len(transcript)})",
        "emotion_hint": f"{'✅' if result.get('emotion_hint') else '❌'} 语调提示",
        "confidence": f"{'✅' if result.get('confidence') else '❌'} 自信程度",
        "emotion": f"{'✅' if result.get('emotion') else '❌'} 情绪",
        "service_status": f"{'✅' if result.get('service_status') == 'ok' else '❌'} 服务状态",
    }

    if media_type == "video":
        bl = result.get("body_language")
        if bl is not None:
            checks["body_language"] = f"{'✅' if isinstance(bl, dict) else '❌'} 肢体语言分析"
        else:
            checks["body_language"] = "⚠️  body_language 为 None（音频模式正常）"

    for field, msg in checks.items():
        print(f"  {msg}")

    if invalid_reason:
        print(f"  ❌ {invalid_reason}")

    # ── 第 5 步：完整归一化结果展示 ────────────────────────
    step("归一化结果（供下游使用）")

    normalized = {
        "transcript": transcript,
        "tone_analysis": {
            "pace": result.get("speed", "未知"),
            "emotion": result.get("emotion", "未知"),
            "fluency": result.get("emotion_hint", "未知"),
        },
        "body_language_analysis": None,
    }

    if media_type == "video" and result.get("body_language"):
        bl = result["body_language"]
        normalized["body_language_analysis"] = {
            "posture": bl.get("body_language", "未知"),
            "eye_contact": bl.get("facial_expression", "未知"),
            "gestures": bl.get("facial_expression", "未知"),
            "facial_expression": bl.get("facial_expression", "未知"),
            "summary": bl.get("notes", ""),
        }

    pretty(normalized, label="下游用到的字段")

    # ── 第 6 步：总结 ──────────────────────────────────────
    step("诊断结论")
    if not transcript_ok:
        print("  ❌ 转写失败或返回无效文本 → 请检查 API Key / 模型 / 文件格式")
        print(f"     原始 transcript: '{transcript[:200]}'")
    elif result.get("service_status") != "ok":
        print(f"  ❌ 服务状态异常: {result.get('service_status')}")
    elif media_type == "video" and result.get("body_language") is None:
        print("  ⚠️  视频模式下 body_language 为空 → 可能是音频文件被误判为视频")
    else:
        print("  ✅ 分析链路正常，若前端仍显示异常请进一步检查前端轮询逻辑")


if __name__ == "__main__":
    main()
