"""视频编解码诊断脚本。

用于排查 "Invalid video file" 错误是否由 Base64 编解码环节引起。

功能：
1. 验证二进制读取 → Base64 编码 → 解码 → 二进制 的完整性
2. 检查 Base64 字符串是否包含异常字符（换行、空格等）
3. 对比原始文件与解码后文件的 MD5 和大小
4. 检测视频封装格式、编码格式（需要 ffprobe 或 ffmpeg）
5. 生成可直接用于 API 测试的 Base64 片段

用法：
    cd backend/doc
    conda activate agent
    python test_video_codec.py --video C:/path/to/answer.mp4
    python test_video_codec.py --video C:/path/to/good.mp4 C:/path/to/bad.mp4  # 对比两个文件
"""

import argparse
import base64
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def md5_file(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def md5_bytes(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


def analyze_video_file(video_path: str, index: int = 1) -> dict:
    """对单个视频文件进行完整的编解码诊断。"""
    print(f"\n{'='*60}")
    print(f"[{index}] 文件: {video_path}")
    print("=" * 60)

    if not os.path.isfile(video_path):
        print(f"  ❌ 文件不存在")
        return {"path": video_path, "exists": False}

    # 1. 基础信息
    size = os.path.getsize(video_path)
    print(f"  文件大小: {size:,} bytes ({size/1024/1024:.2f} MB)")

    # 2. 二进制读取
    with open(video_path, "rb") as f:
        raw_bytes = f.read()
    print(f"  二进制读取: {len(raw_bytes):,} bytes")

    # 3. Base64 编码
    b64 = base64.b64encode(raw_bytes).decode("utf-8")
    print(f"  Base64 长度: {len(b64):,} 字符")
    print(f"  Base64 前 80 字符: {b64[:80]}")
    print(f"  Base64 后 80 字符: {b64[-80:]}")

    # 4. 检查异常字符
    has_newline = "\n" in b64 or "\r" in b64
    has_space = " " in b64
    has_tab = "\t" in b64
    print(f"  包含换行(\\n/\\r): {has_newline}")
    print(f"  包含空格: {has_space}")
    print(f"  包含制表符: {has_tab}")
    if has_newline or has_space or has_tab:
        print(f"  ⚠️  警告: Base64 字符串包含异常字符！")

    # 5. Base64 解码验证
    decoded = base64.b64decode(b64)
    print(f"  解码后大小: {len(decoded):,} bytes")

    # 6. 完整性对比
    raw_md5 = md5_bytes(raw_bytes)
    decoded_md5 = md5_bytes(decoded)
    print(f"  原始 MD5:    {raw_md5}")
    print(f"  解码后 MD5:  {decoded_md5}")
    if raw_md5 == decoded_md5:
        print(f"  ✅ Base64 编解码无损，数据完整性正常")
    else:
        print(f"  ❌ Base64 编解码有损，数据不一致！")

    # 7. 解码后文件写入验证
    tmp_path = Path(tempfile.gettempdir()) / f"codec_test_{Path(video_path).name}"
    with open(tmp_path, "wb") as f:
        f.write(decoded)
    disk_md5 = md5_file(str(tmp_path))
    print(f"  写入磁盘 MD5: {disk_md5}")
    if disk_md5 == raw_md5:
        print(f"  ✅ 磁盘写入验证通过")
    else:
        print(f"  ❌ 磁盘写入验证失败（可能是磁盘/权限问题）")

    # 8. 视频格式检测（ffprobe）
    probe_info = {}
    try:
        import subprocess
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-show_format", "-show_streams",
             "-of", "json", video_path],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            probe = json.loads(result.stdout)
            probe_info = probe
            fmt = probe.get("format", {})
            streams = probe.get("streams", [])
            print(f"  封装格式: {fmt.get('format_name', 'unknown')}")
            print(f"  时长: {fmt.get('duration', 'unknown')}s")
            for s in streams:
                codec_type = s.get("codec_type")
                codec_name = s.get("codec_name")
                if codec_type == "video":
                    print(f"  视频流: {codec_name} | {s.get('width')}x{s.get('height')} | {s.get('pix_fmt')}")
                elif codec_type == "audio":
                    print(f"  音频流: {codec_name} | {s.get('sample_rate')}Hz | {s.get('channels')}ch")
        else:
            print(f"  ⚠️ ffprobe 失败: {result.stderr[:200]}")
    except FileNotFoundError:
        print(f"  ⚠️ ffprobe 未安装，跳过视频格式检测")
    except Exception as e:
        print(f"  ⚠️ ffprobe 异常: {e}")

    # 9. 生成 API 测试用的 data URI 片段
    ext = Path(video_path).suffix.lower().lstrip(".")
    mime = {"mp4": "video/mp4", "mov": "video/quicktime", "webm": "video/webm", "mkv": "video/x-matroska"}.get(ext, "video/mp4")
    data_uri = f"data:{mime};base64,{b64}"
    print(f"  Data URI 前 120 字符: {data_uri[:120]}")
    print(f"  Data URI 总长度: {len(data_uri):,} 字符")

    return {
        "path": video_path,
        "exists": True,
        "size": size,
        "b64_length": len(b64),
        "has_newline": has_newline,
        "has_space": has_space,
        "md5_match": raw_md5 == decoded_md5,
        "disk_md5_match": disk_md5 == raw_md5,
        "probe": probe_info,
    }


def main():
    parser = argparse.ArgumentParser(description="视频编解码诊断工具")
    parser.add_argument("--video", nargs="+", required=True, help="要诊断的视频文件路径（可多个）")
    args = parser.parse_args()

    print("=" * 60)
    print("视频编解码诊断")
    print("=" * 60)

    results = []
    for idx, path in enumerate(args.video, 1):
        result = analyze_video_file(path, idx)
        results.append(result)

    # 汇总对比
    if len(results) > 1:
        print(f"\n{'='*60}")
        print("汇总对比")
        print("=" * 60)
        for r in results:
            status = "✅" if r.get("md5_match") and r.get("disk_md5_match") else "❌"
            print(f"  {status} {Path(r['path']).name}: size={r.get('size',0):,} | md5_ok={r.get('md5_match')} | b64_len={r.get('b64_length',0):,}")

    print(f"\n{'='*60}")
    print("诊断完成")
    print("=" * 60)


if __name__ == "__main__":
    main()
