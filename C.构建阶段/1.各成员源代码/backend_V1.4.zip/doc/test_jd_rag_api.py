"""JD 文档 RAG — API 集成检测脚本。

检测内容：
1. JD 文档上传 → 异步解析 → 状态变为 completed
2. JD 文档 RAG 检索（query）返回相关片段
3. Agent 生成问题时是否正确加载了 JD 知识片段

运行方式：
    cd backend
    conda activate agent
    python doc/test_jd_rag_api.py

环境要求：
    - DASHSCOPE_API_KEY 已配置（.env 或 config.py）
    - MySQL 数据库可连接
    - 后端无需启动（使用 FastAPI TestClient）
"""

import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient
from sqlalchemy.orm import Session
from database import SessionLocal
from models.job import Job
from models.user import User
from models.jd_document import JdDocument, JdDocumentChunk
from utils.security import create_access_token

# 延迟导入 main（依赖其他模块）
from main import app

client = TestClient(app)

# ═══════════════════════════════════════════
# 辅助函数
# ═══════════════════════════════════════════

def _create_test_user(db: Session) -> User:
    """创建或获取测试面试官用户。"""
    user = db.query(User).filter(User.account == "TINT").first()
    if not user:
        user = User(
            account="TINT",
            name="测试面试官",
            password_hash="test_hash",
            role="interviewer",
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    return user


def _create_test_job(db: Session, user_id: int) -> Job:
    """创建或获取测试岗位。"""
    job = db.query(Job).filter(Job.id == 99991).first()
    if not job:
        job = Job(
            id=99991,
            title="Python 后端开发工程师",
            salary_range="20k-35k",
            education_requirement="本科及以上",
            work_experience_requirement=3,
            fresh_requirement="不限",
            work_content="负责 AI 面试系统后端开发，包括 API 设计、数据库建模、系统性能优化",
            position_requirements="精通 Python，熟悉 FastAPI/Flask，熟悉 MySQL 和 Redis，有 AI 项目经验优先",
            created_by=user_id,
        )
        db.add(job)
        db.commit()
        db.refresh(job)
    return job


def get_token(user: User) -> str:
    """生成测试用 JWT token。"""
    return create_access_token(user_id=user.id, role=user.role)


def print_sep(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('=' * 60)


# ═══════════════════════════════════════════
# 测试 1：JD 文档上传 + 异步解析
# ═══════════════════════════════════════════
def test_upload_and_parse(db: Session, token: str, job_id: int):
    print_sep("测试 1：JD 文档上传 + 异步解析")

    # 创建临时测试文档
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("岗位职责：\n")
        f.write("1. 负责 AI 面试系统的后端架构设计与核心模块开发\n")
        f.write("2. 使用 FastAPI 构建高性能 RESTful API，支持高并发访问\n")
        f.write("3. 设计并优化 MySQL 数据库表结构，编写复杂查询和存储过程\n")
        f.write("4. 集成 Redis 缓存，提升系统响应速度\n")
        f.write("5. 编写单元测试和集成测试，保障代码质量\n")
        f.write("6. 参与系统架构评审和技术方案选型\n\n")
        f.write("任职要求：\n")
        f.write("1. 计算机相关专业本科及以上学历\n")
        f.write("2. 3 年以上 Python 开发经验，精通 FastAPI 或 Flask 框架\n")
        f.write("3. 熟悉 SQLAlchemy ORM 和 MySQL 数据库调优\n")
        f.write("4. 了解 Redis、RabbitMQ 等中间件\n")
        f.write("5. 熟悉 Git 工作流和 CI/CD 流程\n")
        f.write("6. 有大模型或 AI 应用开发经验者优先\n")
        f.write("7. 良好的沟通能力和团队协作精神\n")
        tmp_path = f.name

    # 上传文档
    with open(tmp_path, "rb") as f:
        response = client.post(
            f"/api/jobs/{job_id}/jd-documents",
            files={"file": ("test_jd.txt", f, "text/plain")},
            data={"title": "Python 后端开发岗位说明书"},
            headers={"Authorization": f"Bearer {token}"},
        )
    Path(tmp_path).unlink(missing_ok=True)

    assert response.status_code == 202, f"上传失败: status={response.status_code} body={response.text}"
    data = response.json()
    doc_id = data["data"]["document_id"]
    print(f"  [上传] 文档 ID: {doc_id}")
    print(f"  [上传] 状态: {data['data']['status']} (期望 processing)")
    print(f"  [上传] 标题: {data['data']['title']}")
    assert data["data"]["status"] == "processing"
    print("  ✅ 上传接口正常，返回 202 Accepted")

    # 轮询等待解析完成
    print("  [等待] 异步解析中 ...")
    import time
    for attempt in range(15):
        time.sleep(2)
        resp = client.get(
            f"/api/jobs/{job_id}/jd-documents",
            headers={"Authorization": f"Bearer {token}"},
        )
        items = resp.json()["data"]["items"]
        for doc in items:
            if doc["document_id"] == doc_id:
                status = doc["status"]
                print(f"  轮询 {attempt+1}: status={status}", end="")
                if doc.get("parsed_chunks"):
                    print(f" chunks={doc['parsed_chunks']}")
                else:
                    print()
                if status == "completed":
                    print(f"  ✅ 异步解析完成，切片数: {doc['parsed_chunks']}")
                    return doc_id
                if status == "failed":
                    print(f"  ❌ 解析失败: {doc.get('error_message', '未知错误')}")
                    return doc_id
                break
    print("  ⚠️  超时，解析仍未完成")
    return doc_id


# ═══════════════════════════════════════════
# 测试 2：RAG 检索
# ═══════════════════════════════════════════
def test_rag_query(token: str, job_id: int):
    print_sep("测试 2：JD 文档 RAG 检索")

    queries = [
        "Python FastAPI 开发经验",
        "数据库设计 性能优化",
        "团队协作 沟通能力",
    ]

    all_ok = True
    for q in queries:
        response = client.post(
            f"/api/jobs/{job_id}/jd-documents/query",
            data={"query": q, "top_k": 2},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200, f"检索失败: {response.text}"
        result = response.json()
        items = result["data"]["results"]
        print(f"  查询: '{q}'")
        print(f"  返回: {len(items)} 条结果")
        for item in items:
            score = item["score"]
            text = item["chunk_text"][:60]
            print(f"    - [{score:.3f}] {text}...")
        if not items:
            print(f"    ⚠️  无结果返回")
            all_ok = False
        else:
            # 至少有一个结果分数 > 0.3
            if max(item["score"] for item in items) < 0.3:
                print(f"    ⚠️  最高相似度偏低 ({max(item['score'] for item in items):.3f})")

    if all_ok:
        print("  ✅ RAG 检索正常，能返回相关片段")
    else:
        print("  ⚠️  RAG 检索部分异常")
    return all_ok


# ═══════════════════════════════════════════
# 测试 3：Agent 生成问题时是否使用 RAG
# ═══════════════════════════════════════════
async def test_agent_rag_usage(token: str, job_id: int):
    print_sep("测试 3：Agent 生成问题时的 RAG 使用检测")

    # 构造模拟的岗位和候选人信息
    job_info = {
        "title": "Python 后端开发工程师",
        "education_requirement": "本科及以上",
        "work_experience_requirement": 3,
        "work_content": "负责 AI 面试系统后端开发，包括 API 设计、数据库建模、系统性能优化",
        "position_requirements": "精通 Python，熟悉 FastAPI/Flask，熟悉 MySQL 和 Redis，有 AI 项目经验优先",
    }
    candidate_info = {
        "name": "张三",
        "education": "硕士",
        "work_experience": 4,
        "skills": "Python, FastAPI, MySQL, Redis, Docker",
        "experience": "负责过在线教育平台后端开发，使用 FastAPI 构建 RESTful API",
    }

    # 调用 agent_chain 生成初始问题（带 job_id 使 RAG 生效）
    from ai.agent_chain import generate_initial_question

    result = await generate_initial_question(
        job_info=job_info,
        candidate_info=candidate_info,
        max_rounds=5,
        job_id=job_id,
    )

    print(f"  生成问题: {result.get('question_text', '')[:80]}...")
    print(f"  问题类型: {result.get('question_type')}")
    print(f"  是否结束: {result.get('is_done')}")
    print(f"  理由: {result.get('reason', '')[:60]}...")

    if result.get("question_text"):
        # 检查问题中是否包含了与 JD 相关的关键词
        jd_keywords = ["FastAPI", "MySQL", "Redis", "Python", "后端", "API", "数据库", "缓存", "高并发"]
        found = [kw for kw in jd_keywords if kw.lower() in result["question_text"].lower()]
        if found:
            print(f"  ✅ Agent 问题中引用了 JD 关键词: {found}")
        else:
            print(f"  ⚠️  未检测到明确 JD 关键词引用（Agent 可能未使用 RAG 上下文）")

        # 通过 prompt 中 jd_context 来判断 RAG 是否生效
        # 直接检查 _build_jd_context 的输出
        from ai.agent_chain import _build_jd_context as build_jd_ctx
        jd_ctx = await build_jd_ctx(job_id)
        if "（暂无" in jd_ctx:
            print(f"  ❌ RAG 未生效: {jd_ctx}")
            return False
        else:
            print(f"  ✅ RAG 已生效，JD 上下文长度: {len(jd_ctx)} 字符")
            print(f"     JD 上下文预览: {jd_ctx[:120]}...")
            return True
    else:
        print(f"  ⚠️  问题生成可能失败")
        return False


# ═══════════════════════════════════════════
# 测试 4：基于 LLM 的报告生成是否使用 RAG
# ═══════════════════════════════════════════
async def test_report_rag_usage(token: str, job_id: int):
    print_sep("测试 4：报告生成时的 RAG 使用检测")

    from ai.assessor import _build_jd_context as build_jd_ctx
    jd_ctx = await build_jd_ctx(job_id)

    if "（暂无" in jd_ctx:
        print(f"  ❌ 报告 RAG 未生效: {jd_ctx}")
        return False
    else:
        print(f"  ✅ 报告 RAG 已生效，JD 上下文长度: {len(jd_ctx)} 字符")
        print(f"     JD 上下文预览: {jd_ctx[:120]}...")
        return True


# ═══════════════════════════════════════════
# 主流程
# ═══════════════════════════════════════════
async def main():
    print("=" * 60)
    print("  JD 文档 RAG — API 集成检测")
    print("=" * 60)

    db: Session = SessionLocal()
    try:
        # 准备测试数据
        user = _create_test_user(db)
        job = _create_test_job(db, user.id)
        token = get_token(user)
        print(f"\n测试用户: {user.name} (ID={user.id})")
        print(f"测试岗位: {job.title} (ID={job.id})")
        print(f"JWT token: {token[:40]}...")

        # 测试 1：上传 + 解析
        doc_id = test_upload_and_parse(db, token, job.id)

        if doc_id:
            # 测试 2：RAG 检索
            rag_ok = test_rag_query(token, job.id)

            # 测试 3：Agent 问题生成使用 RAG
            agent_rag_ok = await test_agent_rag_usage(token, job.id)

            # 测试 4：报告生成使用 RAG
            report_rag_ok = await test_report_rag_usage(token, job.id)

            # 汇总
            print(f"\n{'='*60}")
            print("  检测汇总")
            print('=' * 60)
            tests = {
                "JD 文档上传+解析": "✅" if doc_id else "❌",
                "RAG 检索": "✅" if rag_ok else "⚠️",
                "Agent 使用 RAG": "✅" if agent_rag_ok else "⚠️",
                "报告使用 RAG": "✅" if report_rag_ok else "⚠️",
            }
            for name, status in tests.items():
                print(f"  {status} {name}")

        # 清理测试数据
        print(f"\n  清理测试数据...")
        db.query(JdDocumentChunk).filter(
            JdDocumentChunk.document_id == doc_id
        ).delete()
        db.query(JdDocument).filter(JdDocument.id == doc_id).delete()
        db.query(Job).filter(Job.id == 99991).delete()
        db.query(User).filter(User.account == "TINT").delete()
        db.commit()
        print("  清理完成")

    except Exception as e:
        print(f"\n  ❌ 测试异常: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

    print(f"\n{'='*60}")
    print("  检测完成")
    print('=' * 60)


if __name__ == "__main__":
    asyncio.run(main())
