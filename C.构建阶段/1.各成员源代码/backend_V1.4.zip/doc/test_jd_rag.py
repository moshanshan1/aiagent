"""JD 文档 RAG 功能测试脚本。

测试范围：
1. 文本切分 (_chunk_text)
2. 文档解析 (_parse_document) — txt / docx / pdf
3. 异步向量生成 (_embed_texts) — 调用 DashScope text-embedding-v4
4. 异步文档处理流程 (process_jd_document) — 切分+嵌入+入库
5. 异步 RAG 检索 (query_jd_documents) — 向量相似度搜索

运行方式：
    cd backend
    conda activate agent
    python doc/test_jd_rag.py

环境要求：
    - DASHSCOPE_API_KEY 已配置（config.py 或 .env）
    - MySQL 数据库可连接
    - 已安装 python-docx、pypdf
"""

import asyncio
import sys
import tempfile
from pathlib import Path

# 将 backend 目录加入路径，便于导入本地模块
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models.jd_document import JdDocument, JdDocumentChunk
from services.jd_document_service import (
    _chunk_text,
    _parse_document,
    _embed_texts,
    process_jd_document,
    query_jd_documents,
)


# ═══════════════════════════════════════════
# 1. 文本切分测试
# ═══════════════════════════════════════════
def test_chunk_text():
    print("\n[TEST 1] 文本切分")
    text = "这是一个测试文本。" * 200  # 约 1200 字符
    chunks = _chunk_text(text, chunk_size=300, overlap=30)
    print(f"  原文长度: {len(text)} 字符")
    print(f"  切片数量: {len(chunks)}")
    assert len(chunks) > 0, "切片不应为空"
    assert all(len(c) <= 300 for c in chunks), "每片不应超过 chunk_size"
    print("  ✓ 通过")


# ═══════════════════════════════════════════
# 2. 文档解析测试
# ═══════════════════════════════════════════
def test_parse_document():
    print("\n[TEST 2] 文档解析")

    # 2.1 TXT
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("Python 后端开发工程师\n熟悉 Django / Flask / FastAPI\n")
        txt_path = f.name
    txt_content = _parse_document(txt_path)
    assert "Python" in txt_content, "TXT 解析失败"
    print(f"  TXT 解析: ✓ ({len(txt_content)} 字符)")
    Path(txt_path).unlink()

    # 2.2 DOCX（如果 python-docx 可用）
    try:
        from docx import Document
        docx_path = Path(tempfile.gettempdir()) / "test_jd.docx"
        doc = Document()
        doc.add_paragraph("岗位职责：负责高并发系统架构设计。")
        doc.add_paragraph("任职要求：5 年以上 Python 经验。")
        doc.save(str(docx_path))
        docx_content = _parse_document(str(docx_path))
        assert "高并发" in docx_content, "DOCX 解析失败"
        print(f"  DOCX 解析: ✓ ({len(docx_content)} 字符)")
        docx_path.unlink()
    except ImportError:
        print("  DOCX 解析: 跳过（未安装 python-docx）")

    # 2.3 PDF（如果 pypdf 可用）
    try:
        from fpdf import FPDF
        pdf_path = Path(tempfile.gettempdir()) / "test_jd.pdf"
        pdf = FPDF()
        pdf.add_page()
        # 使用内置字体避免中文字体缺失问题
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt="Java Senior Developer", ln=True)
        pdf.cell(200, 10, txt="Spring Boot, Microservices", ln=True)
        pdf.output(str(pdf_path))
        pdf_content = _parse_document(str(pdf_path))
        assert "Java" in pdf_content or "Spring" in pdf_content, "PDF 解析失败"
        print(f"  PDF 解析: ✓ ({len(pdf_content)} 字符)")
        pdf_path.unlink()
    except ImportError:
        print("  PDF 解析: 跳过（未安装 fpdf / pypdf）")

    print("  ✓ 通过")


# ═══════════════════════════════════════════
# 3. 异步向量生成测试
# ═══════════════════════════════════════════
async def test_embed_texts():
    print("\n[TEST 3] 异步向量生成 (DashScope text-embedding-v4)")
    texts = [
        "熟悉 Python 和 Django 框架",
        "具备高并发系统设计经验",
        "了解 Kubernetes 和 Docker",
    ]
    vectors = await _embed_texts(texts)
    print(f"  请求片段数: {len(texts)}")
    print(f"  返回向量数: {len(vectors)}")
    assert len(vectors) == len(texts), "向量数量应与文本数量一致"
    dim = len(vectors[0])
    print(f"  向量维度: {dim}")
    assert dim > 0, "向量维度应大于 0"
    print("  ✓ 通过")


# ═══════════════════════════════════════════
# 4. 异步文档处理流程测试
# ═══════════════════════════════════════════
async def test_process_jd_document():
    print("\n[TEST 4] 异步文档处理流程")
    db: Session = SessionLocal()
    try:
        # 创建临时测试文件
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
            f.write("岗位职责：\n1. 负责 AI 面试系统的后端架构设计\n")
            f.write("2. 优化数据库查询性能\n")
            f.write("3. 编写单元测试和集成测试\n")
            f.write("任职要求：\n1. 3 年以上 Python 开发经验\n")
            f.write("2. 熟悉 FastAPI 和 SQLAlchemy\n")
            f.write("3. 了解 Redis 和消息队列\n")
            temp_path = f.name

        # 构造一个模拟的 JdDocument 记录
        # 注意：这里不经过 create_jd_document，直接插入记录以便测试
        # 创建虚拟岗位（满足外键约束）
        from models.job import Job
        job = db.query(Job).filter(Job.id == 99999).first()
        if not job:
            job = Job(
                id=99999,
                title="测试岗位",
                salary_range="20k-30k",
                education_requirement="本科",
                work_experience_requirement=3,
                fresh_requirement="不限",
                work_content="测试工作内容",
                position_requirements="测试要求",
                created_by=1,
            )
            db.add(job)
            db.commit()

        doc = JdDocument(
            job_id=99999,  # 虚拟 job_id
            title="测试 JD 文档",
            file_url=f"/uploads/jd-docs/99999/{Path(temp_path).name}",
            status="processing",
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)
        print(f"  创建测试文档 ID: {doc.id}")

        # 将文件复制到预期路径（process_jd_document 会基于 BASE_DIR 查找）
        from main import BASE_DIR
        target_dir = Path(BASE_DIR) / "uploads" / "jd-docs" / "99999"
        target_dir.mkdir(parents=True, exist_ok=True)
        target_path = target_dir / Path(temp_path).name
        target_path.write_text(Path(temp_path).read_text(encoding="utf-8"), encoding="utf-8")

        # 执行异步处理
        await process_jd_document(db, doc.id)

        # 验证结果
        db.refresh(doc)
        assert doc.status == "completed", f"文档状态应为 completed，实际为 {doc.status}"
        assert doc.parsed_chunks is not None and doc.parsed_chunks > 0, "应有切片"
        print(f"  处理状态: {doc.status}")
        print(f"  切片数量: {doc.parsed_chunks}")

        # 验证切片入库
        chunks = db.query(JdDocumentChunk).filter(JdDocumentChunk.document_id == doc.id).all()
        assert len(chunks) == doc.parsed_chunks, "数据库切片数应与 parsed_chunks 一致"
        print(f"  入库切片数: {len(chunks)}")

        # 清理
        for chunk in chunks:
            db.delete(chunk)
        db.delete(doc)
        db.delete(job)
        db.commit()
        target_path.unlink(missing_ok=True)
        Path(temp_path).unlink(missing_ok=True)
        print("  ✓ 通过")
    finally:
        db.close()


# ═══════════════════════════════════════════
# 5. 异步 RAG 检索测试
# ═══════════════════════════════════════════
async def test_query_jd_documents():
    print("\n[TEST 5] 异步 RAG 检索")
    db: Session = SessionLocal()
    try:
        # 复用 TEST 4 的文档数据，或新建
        # 这里直接插入一些已知切片用于检索测试
        # 创建虚拟岗位（满足外键约束）
        from models.job import Job
        job = db.query(Job).filter(Job.id == 99998).first()
        if not job:
            job = Job(
                id=99998,
                title="检索测试岗位",
                salary_range="15k-25k",
                education_requirement="本科",
                work_experience_requirement=2,
                fresh_requirement="不限",
                work_content="检索测试工作内容",
                position_requirements="检索测试要求",
                created_by=1,
            )
            db.add(job)
            db.commit()

        doc = JdDocument(
            job_id=99998,
            title="检索测试文档",
            file_url=None,
            status="completed",
            parsed_chunks=3,
        )
        db.add(doc)
        db.commit()
        db.refresh(doc)

        # 预置向量（使用真实嵌入）
        texts = [
            "精通 Python 异步编程和 FastAPI",
            "熟悉 MySQL 索引优化和慢查询分析",
            "具备团队管理经验，善于跨部门沟通",
        ]
        vectors = await _embed_texts(texts)

        for idx, (text, vector) in enumerate(zip(texts, vectors)):
            chunk = JdDocumentChunk(
                document_id=doc.id,
                job_id=99998,
                chunk_text=text,
                chunk_index=idx,
            )
            import json
            chunk.embedding_vector = json.dumps(vector)
            db.add(chunk)
        db.commit()

        # 执行检索
        results = await query_jd_documents(db, 99998, "Python 后端开发", top_k=2)
        print(f"  查询: 'Python 后端开发'")
        print(f"  返回结果数: {len(results)}")
        assert len(results) <= 2, "top_k=2 应最多返回 2 条"
        for r in results:
            print(f"    - [{r['score']}] {r['chunk_text'][:40]}...")

        # 清理
        db.query(JdDocumentChunk).filter(JdDocumentChunk.document_id == doc.id).delete()
        db.delete(doc)
        db.delete(job)
        db.commit()
        print("  ✓ 通过")
    finally:
        db.close()


# ═══════════════════════════════════════════
# 主入口
# ═══════════════════════════════════════════
async def main():
    print("=" * 50)
    print("JD 文档 RAG 功能测试")
    print("=" * 50)

    test_chunk_text()
    test_parse_document()
    await test_embed_texts()
    await test_process_jd_document()
    await test_query_jd_documents()

    print("\n" + "=" * 50)
    print("全部测试通过 ✓")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
