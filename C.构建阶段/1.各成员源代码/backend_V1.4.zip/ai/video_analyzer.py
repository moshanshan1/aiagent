"""媒体分析模块（合并视频/音频分析）。

基于 Qwen-Omni 多模态能力，统一分析面试者的视频或音频，
返回语音转写、语调、表情与肢体语言分析结果。
"""

import base64
import json
import os
from pathlib import Path

from openai import OpenAI

import time
from ai.logger import log_ai_request, log_ai_response, log_ai_error
from ai.fallbacks import fallback_tone_result
from config import DASHSCOPE_API_KEY, DASHSCOPE_BASE_URL, OMNI_TIMEOUT
from ai.tone_analyzer import _candidate_base_urls

PUBLIC_DASHSCOPE_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
VIDEO_MODEL = os.getenv("VIDEO_MODEL", "qwen3.5-omni-plus")
MAX_MEDIA_MB = 10  

_clients: dict[str, OpenAI] = {}


def _get_client(base_url: str | None = None) -> OpenAI:
    resolved_base_url = (base_url or DASHSCOPE_BASE_URL or PUBLIC_DASHSCOPE_BASE_URL).rstrip("/")
    client = _clients.get(resolved_base_url)
    if client is None:
        client = OpenAI(
            api_key=DASHSCOPE_API_KEY,
            base_url=resolved_base_url,
            timeout=OMNI_TIMEOUT,
        )
        _clients[resolved_base_url] = client
    return client


def _encode_video(video_path: str) -> str:
    """将视频文件编码为 Base64。"""
    with open(video_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def _build_analysis_prompt() -> str:
    """构建面试视频分析 prompt，要求模型输出结构化 JSON。"""
    return """你是一位专业的面试表现评估专家。请综合分析面试者的语音内容、语调、表情和肢体语言，并严格按以下 JSON 格式返回分析结果，不要包含其他内容：

{
  "transcript": "面试者说了什么内容，完整转写",
  "voice_content": "语音内容总结：面试者回答的核心要点，50字以内",
  "tone": "语调分析：语速/节奏/停顿是否得当，表达是否流畅自然",
  "speed": "语速：快/正常/慢",
  "facial_expression": "表情分析：自信/紧张/自然/严肃/积极/疲惫等",
  "body_language": "肢体语言分析：坐姿、手势、眼神交流、头部动作等",
  "emotion": "情绪状态：积极/中性/紧张/消极",
  "confidence": "自信程度：高/中/低",
  "notes": "其他值得注意的观察，50字以内"
}

注意：
1. 语音内容、语调、表情、肢体语言四项都要分析，缺一不可。
2. 如果视频/音频中没有出现人脸，表情和肢体语言可说明无法分析，但语音内容和语调仍需尽力判断。
3. 评价要客观，基于可观察到的内容。
4. 必须严格返回 JSON，不要添加 markdown 代码块标记。"""


def _normalize_video_result(raw: dict, base_url: str) -> dict:
    """将视频分析结果归一化为与音频 tone 分析一致的格式。"""
    transcript = raw.get("transcript", "")
    if not isinstance(transcript, str):
        transcript = ""

    return {
        "transcript": transcript,
        "emotion_hint": raw.get("tone", "未知"),
        "confidence": raw.get("confidence", "未知"),
        "emotion": raw.get("emotion", "未知"),
        "speed": raw.get("speed", "未知"),
        "service_status": "ok",
        "provider_base_url": base_url,
        "provider_model": VIDEO_MODEL,
        "tone": raw.get("tone", "未知"),
        "body_language": {
            "facial_expression": raw.get("facial_expression", "未知"),
            "body_language": raw.get("body_language", "未知"),
            "notes": raw.get("notes", ""),
        },
    }


def _call_omni_video(base_url: str, video_path: str) -> dict:
    log_ai_request(
        "video_analyzer._call_omni_video",
        metadata={"base_url": base_url, "model": VIDEO_MODEL, "video_path": video_path},
    )
    client = _get_client(base_url)
    base64_video = _encode_video(video_path)

    completion = client.chat.completions.create(
        model=VIDEO_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "video_url",
                        "video_url": {"url": f"data:;base64,{base64_video}"},
                    },
                    {"type": "text", "text": _build_analysis_prompt()},
                ],
            },
        ],
        modalities=["text"],
        stream=True,
        stream_options={"include_usage": True},
    )

    full_content = ""
    for chunk in completion:
        if chunk.choices and chunk.choices[0].delta.content:
            full_content += chunk.choices[0].delta.content

    if not full_content.strip():
        raise RuntimeError("模型返回为空")

    text = full_content.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:].strip()

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as e:
        print(f"[WARN] video_analyzer: JSON 解析失败 - {e}")
        parsed = {"raw_output": full_content, "parse_error": str(e)}

    log_ai_response(
        "video_analyzer._call_omni_video",
        response=parsed,
        note=f"Omni 视频分析完成 | transcript={parsed.get('transcript','')[:60]}...",
        metadata={"base_url": base_url, "model": VIDEO_MODEL},
    )
    return parsed


def analyze_video(video_path: str) -> dict:
    """分析面试视频，返回转写文本 + 语调/肢体/表情分析。

    Returns:
        {
            "transcript": "...",
            "emotion_hint": "...",
            "confidence": "...",
            "emotion": "...",
            "speed": "...",
            "service_status": "ok",
            "provider_base_url": "...",
            "provider_model": "...",
            "body_language": {
                "eye_contact": "...",
                "posture": "...",
                "facial_expression": "...",
                "gesture": "...",
                "notes": "..."
            }
        }
    """
    if not DASHSCOPE_API_KEY or DASHSCOPE_API_KEY.startswith("your-"):
        print("[WARN] video_analyzer: API Key 未配置，使用 fallback 数据")
        return fallback_tone_result("服务未配置")

    if not os.path.isfile(video_path):
        return fallback_tone_result("分析失败", error="文件不存在")

    size_mb = Path(video_path).stat().st_size / (1024 * 1024)
    if size_mb > MAX_MEDIA_MB:
        return fallback_tone_result("分析失败", error=f"视频文件超过 {MAX_MEDIA_MB}MB")

    last_error = ""
    attempted_urls = []

    for base_url in _candidate_base_urls():
        attempted_urls.append(base_url)
        try:
            raw = _call_omni_video(base_url, video_path)
            if "raw_output" in raw or "parse_error" in raw:
                last_error = raw.get("parse_error", "JSON 解析失败")
                continue
            return _normalize_video_result(raw, base_url)
        except Exception as e:
            last_error = str(e)
            print(f"[WARN] video_analyzer: 调用失败 - base_url={base_url} error={e}")
            if "Workspace endpoint access denied" in last_error:
                continue

    print(f"[WARN] video_analyzer: 分析失败，使用 fallback 数据 - {last_error}")
    print(f"[WARN] video_analyzer: 视频分析失败，尝试回退到音频分析...")
    try:
        audio_result = analyze_audio(video_path)
        if audio_result.get("service_status") == "ok":
            # 保留 body_language=None，但把 transcript/tone 用音频结果填充
            print(f"[INFO] video_analyzer: 音频回退成功")
            fallback_result = {
                **audio_result,
                "body_language": None,
                "note": "视频分析失败，已回退到音频分析",
            }
            log_ai_response(
                "video_analyzer.analyze_video",
                response=fallback_result,
                note=f"视频分析失败→回退音频成功 | transcript={audio_result.get('transcript','')[:60]}",
                metadata={"video_path": video_path, "fallback": True},
            )
            return fallback_result
    except Exception as audio_err:
        print(f"[WARN] video_analyzer: 音频回退也失败 - {audio_err}")

    fallback_result = {
        **fallback_tone_result("分析失败", error=last_error),
        "attempted_base_urls": attempted_urls,
        "service_status": "unavailable",
        "body_language": None,
    }
    log_ai_error(
        "video_analyzer.analyze_video",
        error=last_error,
        metadata={"video_path": video_path, "attempted_urls": attempted_urls},
    )
    return fallback_result


# ─── 音频分析（复用 Omni 模型） ─────────────────────────────


def _call_omni_audio(base_url: str, audio_path: str) -> dict:
    """调用 Qwen-Omni 分析音频（转写 + 语调）。"""
    log_ai_request(
        "video_analyzer._call_omni_audio",
        metadata={"base_url": base_url, "model": VIDEO_MODEL, "audio_path": audio_path},
    )

    with open(audio_path, "rb") as f:
        base64_audio = base64.b64encode(f.read()).decode("utf-8")

    ext = os.path.splitext(audio_path)[1].lower().lstrip(".")
    if ext not in ("mp3", "wav", "m4a", "aac", "amr", "3gp", "3gpp", "webm", "ogg", "weba", "mp4"):
        ext = "wav"

    mime_map = {
        "mp3": "audio/mpeg", "wav": "audio/wav", "m4a": "audio/mp4",
        "aac": "audio/aac", "amr": "audio/amr", "ogg": "audio/ogg",
        "webm": "audio/webm", "weba": "audio/webm", "mp4": "audio/mp4",
    }
    audio_mime = mime_map.get(ext, "audio/wav")

    client = _get_client(base_url)
    completion = client.chat.completions.create(
        model=VIDEO_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_audio",
                        "input_audio": {
                            "data": f"data:{audio_mime};base64,{base64_audio}",
                            "format": ext,
                        },
                    },
                    {
                        "type": "text",
                        "text": _build_analysis_prompt(),
                    },
                ],
            },
        ],
        modalities=["text"],
        stream=True,
        stream_options={"include_usage": True},
    )

    full_content = ""
    for chunk in completion:
        if chunk.choices and chunk.choices[0].delta.content:
            full_content += chunk.choices[0].delta.content

    if not full_content.strip():
        raise RuntimeError("模型返回为空")

    text = full_content.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:].strip()

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as e:
        print(f"[WARN] video_analyzer: 音频 JSON 解析失败 - {e}")
        parsed = {"raw_output": full_content, "parse_error": str(e)}

    log_ai_response(
        "video_analyzer._call_omni_audio",
        response=parsed,
        note=f"Omni 音频分析完成 | transcript={parsed.get('transcript','')[:60]}...",
        metadata={"base_url": base_url, "model": VIDEO_MODEL},
    )
    return parsed


def _normalize_audio_result(raw: dict, base_url: str) -> dict:
    """将音频分析结果归一化（body_language 为 None）。"""
    transcript = raw.get("transcript", "")
    if not isinstance(transcript, str):
        transcript = ""

    return {
        "transcript": transcript,
        "emotion_hint": raw.get("voice_content") or raw.get("emotion_hint", "未知"),
        "confidence": raw.get("confidence", "未知"),
        "emotion": raw.get("emotion", "未知"),
        "speed": raw.get("speed", "未知"),
        "tone": raw.get("tone", "未知"),
        "service_status": "ok",
        "provider_base_url": base_url,
        "provider_model": VIDEO_MODEL,
        "body_language": None,
    }


def analyze_audio(audio_path: str) -> dict:
    """分析面试音频，返回转写 + 语调。"""
    if not DASHSCOPE_API_KEY or DASHSCOPE_API_KEY.startswith("your-"):
        print("[WARN] video_analyzer: API Key 未配置，使用 fallback 数据")
        return fallback_tone_result("服务未配置")

    if not os.path.isfile(audio_path):
        return fallback_tone_result("分析失败", error="文件不存在")

    last_error = ""
    attempted_urls = []
    for base_url in _candidate_base_urls():
        attempted_urls.append(base_url)
        try:
            raw = _call_omni_audio(base_url, audio_path)
            if "raw_output" in raw or "parse_error" in raw:
                last_error = raw.get("parse_error", "JSON 解析失败")
                continue
            return _normalize_audio_result(raw, base_url)
        except Exception as e:
            last_error = str(e)
            print(f"[WARN] video_analyzer: audio 调用失败 - base_url={base_url} error={e}")
            if "Workspace endpoint access denial" in str(e):
                continue

    print(f"[WARN] video_analyzer: 音频分析失败，使用 fallback - {last_error}")
    return {**fallback_tone_result("分析失败", error=last_error), "body_language": None}


# ─── 统一入口：根据文件类型自动分派 ─────────────────────────


def analyze_media(file_path: str) -> dict:
    """统一分析面试媒体（视频或音频），根据后缀名自动选择分析方式。

    返回格式与 analyze_video 一致：
    - 视频：含 transcript + tone + body_language（表情/肢体/眼神等）
    - 音频：含 transcript + tone，body_language 为 None
    """
    ext = Path(file_path).suffix.lower().lstrip(".")
    is_video = ext in {"mp4", "mov", "webm", "mkv"}
    if is_video:
        return analyze_video(file_path)
    return analyze_audio(file_path)
