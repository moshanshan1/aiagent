"""语调分析 + 语音转写模块。

优先使用 Qwen Omni 做一次调用的转写 + 语调分析。
当业务空间端点不可用时，自动回退到阿里云百炼公共 OpenAI 兼容端点重试。
"""

import base64
import json
import os

from openai import OpenAI

from ai.logger import log_ai_request, log_ai_response, log_ai_error
from config import DASHSCOPE_API_KEY, DASHSCOPE_BASE_URL, OMNI_MODEL, OMNI_TIMEOUT
from ai.fallbacks import fallback_tone_result

PUBLIC_DASHSCOPE_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
_clients: dict[str, OpenAI] = {}


def _get_client(base_url: str | None = None) -> OpenAI:
    resolved_base_url = (base_url or DASHSCOPE_BASE_URL or PUBLIC_DASHSCOPE_BASE_URL).rstrip("/")
    client = _clients.get(resolved_base_url)
    if client is None:
        client = OpenAI(
            api_key=DASHSCOPE_API_KEY,
            base_url=resolved_base_url,
            timeout=OMNI_TIMEOUT,
        )
        _clients[resolved_base_url] = client
    return client


def _candidate_base_urls() -> list[str]:
    """供 video_analyzer.py 复用的候选端点列表。"""
    urls = []
    for item in [DASHSCOPE_BASE_URL, PUBLIC_DASHSCOPE_BASE_URL]:
        normalized = (item or "").strip().rstrip("/")
        if normalized and normalized not in urls:
            urls.append(normalized)
    return urls


def _call_omni(base_url: str, model: str, base64_audio: str, ext: str) -> dict:
    log_ai_request(
        "tone_analyzer._call_omni",
        metadata={"base_url": base_url, "model": model, "format": ext},
    )
    client = _get_client(base_url)
    completion = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_audio",
                        "input_audio": {
                            "data": f"data:;base64,{base64_audio}",
                            "format": ext,
                        },
                    },
                    {
                        "type": "text",
                        "text": (
                            "请完成两项任务：\n"
                            "1. 将这段语音完整转写为文字\n"
                            "2. 分析说话者的语调特征\n\n"
                            "严格按以下JSON格式返回，不要包含其他内容：\n"
                            "{\n"
                            '  "transcript": "语音转写文字",\n'
                            '  "emotion_hint": "总体感觉，例如：自信有活力/平稳自然/较为平淡",\n'
                            '  "confidence": "自信/一般/不自信",\n'
                            '  "emotion": "积极/中性/消极",\n'
                            '  "speed": "快/正常/慢"\n'
                            "}"
                        ),
                    },
                ],
            },
        ],
        modalities=["text"],
        stream=True,
        stream_options={"include_usage": True},
    )

    full_content = ""
    for chunk in completion:
        if chunk.choices and chunk.choices[0].delta.content:
            full_content += chunk.choices[0].delta.content

    if not full_content:
        return fallback_tone_result("分析失败", service_status="empty")

    try:
        parsed = json.loads(full_content)
        output = {
            "transcript": parsed.get("transcript", full_content),
            "emotion_hint": parsed.get("emotion_hint", "未知"),
            "confidence": parsed.get("confidence", "未知"),
            "emotion": parsed.get("emotion", "未知"),
            "speed": parsed.get("speed", "未知"),
            "service_status": "ok",
            "provider_base_url": base_url,
            "provider_model": model,
        }
        log_ai_response(
            "tone_analyzer._call_omni",
            response=output,
            note=f"语调分析完成 | transcript={output.get('transcript','')[:60]}...",
            metadata={"base_url": base_url, "model": model},
        )
        return output
    except json.JSONDecodeError:
        output = {
            "transcript": full_content,
            "emotion_hint": "平稳自然",
            "confidence": "未知",
            "emotion": "未知",
            "speed": "未知",
            "note": "模型未按 JSON 格式返回，此为原始输出",
            "service_status": "partial",
            "provider_base_url": base_url,
            "provider_model": model,
        }
        log_ai_response(
            "tone_analyzer._call_omni",
            response=output,
            note=f"JSON 解析回退 | transcript={output.get('transcript','')[:60]}...",
            metadata={"base_url": base_url, "model": model, "note": "json_decode_error"},
        )
        return output


def analyze_tone(audio_path: str) -> dict:
    """分析语音，返回转写文本与语调特征。"""
    if not DASHSCOPE_API_KEY or DASHSCOPE_API_KEY.startswith("your-"):
        print("[WARN] tone_analyzer: API Key 未配置，使用 fallback 数据")
        return fallback_tone_result("服务未配置")

    if not os.path.isfile(audio_path):
        return fallback_tone_result("分析失败", error="文件不存在")

    try:
        with open(audio_path, "rb") as file:
            audio_data = file.read()
    except Exception as error:
        return fallback_tone_result("分析失败", error=str(error))

    base64_audio = base64.b64encode(audio_data).decode("utf-8")
    if len(base64_audio) > 10 * 1024 * 1024:
        return fallback_tone_result("分析失败", error="Base64 编码后超过 10MB")

    ext = os.path.splitext(audio_path)[1].lower().lstrip(".")
    if ext not in ("mp3", "wav", "m4a", "aac", "amr", "3gp", "3gpp", "webm", "ogg", "weba", "mp4"):
        ext = "wav"

    last_error = ""
    attempted_urls = []

    for base_url in _candidate_base_urls():
        attempted_urls.append(base_url)
        try:
            result = _call_omni(base_url, OMNI_MODEL, base64_audio, ext)
            if result.get("service_status") in {"ok", "partial"}:
                return result
            last_error = result.get("error", "") or result.get("emotion_hint", "")
        except Exception as error:
            last_error = str(error)
            print(f"[WARN] tone_analyzer: 调用失败 - base_url={base_url} error={error}")
            if "Workspace endpoint access denied" in last_error:
                continue

    print(f"[WARN] tone_analyzer: 分析失败，使用 fallback 数据 - {last_error}")
    fallback_result = {
        **fallback_tone_result("分析失败", error=last_error),
        "attempted_base_urls": attempted_urls,
        "service_status": "access_denied" if "Workspace endpoint access denied" in last_error else "unavailable",
    }
    log_ai_response(
        "tone_analyzer.analyze_tone",
        prompt=f"audio_path={audio_path}",
        response=fallback_result,
        metadata={"status": "fallback", "last_error": last_error, "attempted_urls": attempted_urls},
    )
    return fallback_result
