﻿import { computed, reactive } from 'vue'
import {
  authApi,
  jobsApi,
  interviewsApi,
  messagesApi,
  reportsApi,
  ApiError,
  getStoredAccessToken,
  mapUserFromApi
} from '../api/index.js?v=20260714r'
import { getTabSessionValue, setTabSessionValue } from '../utils/tabSession.js?v=20260714r'

const SESSION_USER_KEY = 'ai-interview-frontend-session-user-v1'
const HIDDEN_INTERVIEW_IDS_KEY = 'ai-interview-hidden-interview-ids-v1'

function loadSessionUser() {
  try {
    const raw = getTabSessionValue(SESSION_USER_KEY)
    if (typeof raw !== 'string') {
      return raw ?? null
    }
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

function persistSessionUser(user) {
  if (!user) {
    setTabSessionValue(SESSION_USER_KEY, '')
    return
  }

  setTabSessionValue(SESSION_USER_KEY, JSON.stringify(user))
}

function loadHiddenInterviewIds() {
  if (typeof localStorage === 'undefined') {
    return []
  }

  try {
    const raw = localStorage.getItem(HIDDEN_INTERVIEW_IDS_KEY)
    const parsed = raw ? JSON.parse(raw) : []
    return Array.isArray(parsed) ? parsed.map((item) => String(item)) : []
  } catch {
    return []
  }
}

function persistHiddenInterviewIds(ids) {
  if (typeof localStorage === 'undefined') {
    return
  }

  try {
    localStorage.setItem(HIDDEN_INTERVIEW_IDS_KEY, JSON.stringify(ids))
  } catch {
    // Ignore storage failures.
  }
}

function normalizeDateTimeLocal(value) {
  if (!value) {
    return ''
  }

  const text = String(value)
  if (text.includes('T')) {
    return text.slice(0, 16)
  }

  return text.replace(' ', 'T').slice(0, 16)
}

function formatScheduleDisplay(value) {
  if (!value) {
    return '待定'
  }

  return String(value).replace('T', ' ').slice(0, 16)
}

function mapMessageForUi(message, currentUser) {
  const mine =
    !!currentUser &&
    ((currentUser.role === 'interviewer' && message.senderType === '面试官') ||
      (currentUser.role === 'candidate' && message.senderType === '面试者'))

  return {
    id: message.id,
    senderId: mine ? currentUser.id : `remote-${message.senderType}`,
    senderLabel: message.senderType,
    text: message.content,
    time: message.sentAt
  }
}

const state = reactive({
  sessionUser: loadSessionUser(),
  users: loadSessionUser() ? [loadSessionUser()] : [],
  jobs: [],
  applicantsByJob: {},
  interviews: [],
  answersByInterview: {},
  reports: [],
  channels: [],
  messagesByChannel: {},
  notifications: [],
  hiddenInterviewIds: loadHiddenInterviewIds(),
  autoRefreshLocks: {},
  ready: false,
  bootstrapping: false,
  bootstrappingPromise: null
})

function isInterviewHidden(interviewId) {
  return state.hiddenInterviewIds.includes(String(interviewId))
}

function addHiddenInterviewId(interviewId) {
  const normalizedId = String(interviewId)
  if (state.hiddenInterviewIds.includes(normalizedId)) {
    return
  }

  state.hiddenInterviewIds = [...state.hiddenInterviewIds, normalizedId]
  persistHiddenInterviewIds(state.hiddenInterviewIds)
}

function pushNotification({ userId, title, body }) {
  if (!userId || !title || !body) {
    return null
  }

  const item = {
    id: `notice-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    userId: String(userId),
    title: String(title),
    body: String(body)
  }

  state.notifications = [item, ...state.notifications].slice(0, 6)
  return item
}

function dismissNotification(notificationId) {
  state.notifications = state.notifications.filter((item) => item.id !== notificationId)
}

function upsertUser(user) {
  if (!user) {
    return
  }

  const existingIndex = state.users.findIndex((item) => item.id === user.id)
  if (existingIndex === -1) {
    state.users.push(user)
    return
  }

  state.users.splice(existingIndex, 1, {
    ...state.users[existingIndex],
    ...user
  })
}

function setSessionUser(user) {
  state.sessionUser = user
  persistSessionUser(user)
  if (user) {
    upsertUser(user)
  }
}

function clearSession() {
  authApi.logout()
  setSessionUser(null)
  state.jobs = []
  state.applicantsByJob = {}
  state.interviews = []
  state.answersByInterview = {}
  state.reports = []
  state.channels = []
  state.messagesByChannel = {}
  state.notifications = []
  state.autoRefreshLocks = {}
}

function pauseAutoRefresh(reason) {
  if (!reason) {
    return
  }

  state.autoRefreshLocks[reason] = true
}

function resumeAutoRefresh(reason) {
  if (!reason) {
    return
  }

  delete state.autoRefreshLocks[reason]
}

function isAutoRefreshPaused() {
  return Object.keys(state.autoRefreshLocks).length > 0
}

function mergeInterview(rawInterview) {
  const existingIndex = state.interviews.findIndex((item) => item.id === rawInterview.id)
  if (existingIndex === -1) {
    state.interviews.unshift(rawInterview)
    return
  }

  state.interviews.splice(existingIndex, 1, {
    ...state.interviews[existingIndex],
    ...rawInterview
  })
}

function replaceInterviewsPreservingRuntime(incomingInterviews) {
  const existingById = new Map(state.interviews.map((item) => [item.id, item]))

  state.interviews = incomingInterviews.map((item) => {
    const existing = existingById.get(item.id)
    const shouldPreserveCurrentQuestion =
      !item.currentQuestion &&
      item.status !== 'completed' &&
      existing?.currentQuestion

    return {
      ...existing,
      ...item,
      currentQuestion: shouldPreserveCurrentQuestion ? existing.currentQuestion : (item.currentQuestion ?? null)
    }
  })
}

function getNormalizedInterviewById(interviewId) {
  const raw = state.interviews.find((item) => item.id === interviewId)
  if (!raw) {
    return null
  }

  const answerData = state.answersByInterview[interviewId]
  const records = (answerData?.items ?? []).map((item, index) => ({
    round: index + 1,
    question: item.question,
    answerTranscript: item.transcript || '已提交语音回答。',
    durationSec: '',
    answeredAt: item.answeredAt
  }))
  const report = state.reports.find((item) => item.interviewId === interviewId)
  const totalQuestions = answerData?.totalCount ?? raw.questions?.length ?? 5
  const completedCount = answerData?.completedCount ?? records.length
  const currentIndex =
    raw.currentQuestion?.currentIndex ??
    (completedCount >= totalQuestions ? totalQuestions : completedCount + 1)

  return {
    ...raw,
    scheduledAt: normalizeDateTimeLocal(raw.openTimeStart),
    activeQuestion: raw.currentQuestion
      ? {
          id: raw.currentQuestion.id,
          text: raw.currentQuestion.text,
          source: '系统题库',
          sentAt: raw.openTimeStart || '',
          round: raw.currentQuestion.currentIndex
        }
      : null,
    responseLimitSec: 90,
    maxRounds: totalQuestions,
    round: currentIndex,
    qaRecords: records,
    reportId: report?.id ?? null
  }
}

function normalizeThread(channel, currentUser) {
  const messages = state.messagesByChannel[channel.id] ?? []
  const title =
    currentUser?.role === 'interviewer'
      ? channel.candidate?.name || `候选人 ${channel.id}`
      : `${channel.createdFrom || '面试'}消息`
  return {
    id: channel.id,
    title,
    candidateId: channel.candidate?.id ?? '',
    messages
  }
}

async function hydrateCurrentUser() {
  const response = await authApi.fetchCurrentUser()
  setSessionUser(response.data)
  return response.data
}

async function loadJobs() {
  const response = await jobsApi.listJobs({
    page: 1,
    size: 100
  })

  state.jobs = response.data.items.map((item) => ({
    ...item,
    tags: item.tags ?? []
  }))
  return state.jobs
}

async function loadApplicantsForJob(jobId) {
  const response = await jobsApi.listApplicants(jobId, {
    page: 1,
    size: 100
  })

  state.applicantsByJob[jobId] = response.data.items.map((item) => {
    const user = {
      id: item.id,
      name: item.name,
      role: 'candidate',
      profile: {
        education: item.profile.education,
        experienceYears: item.profile.experienceYears,
        graduateType: item.profile.graduateType,
        skills: item.profile.skills,
        experienceSummary: ''
      }
    }
    upsertUser(user)

    return {
      ...item,
      profile: user.profile
    }
  })

  return state.applicantsByJob[jobId]
}

async function loadApplicantsForJobs() {
  if (state.sessionUser?.role !== 'interviewer') {
    state.applicantsByJob = {}
    return
  }

  await Promise.allSettled(state.jobs.map((job) => loadApplicantsForJob(job.id)))
}

async function loadInterviews() {
  const response = await interviewsApi.listInterviews({
    page: 1,
    size: 100
  })

  replaceInterviewsPreservingRuntime(response.data.items)
  return state.interviews
}

async function loadInterviewWorkspace(interviewId) {
  const detailResponse = await interviewsApi.getInterview(interviewId)
  mergeInterview({
    ...detailResponse.data,
    currentQuestion: null
  })

  let currentQuestion = null
  if (state.sessionUser?.role === 'candidate') {
    try {
      const checkinResponse = await interviewsApi.checkInInterview(interviewId)
      currentQuestion = checkinResponse.data.currentQuestion
    } catch (error) {
      currentQuestion = null
      if (!(error instanceof ApiError) || error.status !== 403) {
        throw error
      }
    }
  }

  const answersResponse = await interviewsApi.listInterviewAnswers(interviewId)
  state.answersByInterview[interviewId] = answersResponse.data

  if (currentQuestion) {
    mergeInterview({
      ...detailResponse.data,
      currentQuestion
    })
  }

  return getNormalizedInterviewById(interviewId)
}

async function loadReports() {
  if (state.sessionUser?.role !== 'interviewer') {
    state.reports = []
    return []
  }

  const response = await reportsApi.listReports({
    page: 1,
    size: 100
  })

  state.reports = response.data.items
  return state.reports
}

async function loadChannels() {
  const response = await messagesApi.listMessageChannels({
    page: 1,
    size: 100
  })

  state.channels = response.data.items

  state.channels.forEach((channel) => {
    if (channel.candidate) {
      upsertUser({
        id: channel.candidate.id,
        account: channel.candidate.account,
        name: channel.candidate.name,
        role: 'candidate'
      })
    }
  })

  await Promise.allSettled(state.channels.map((channel) => loadChannelMessages(channel.id)))
  return state.channels
}

async function loadChannelMessages(channelId) {
  const response = await messagesApi.getChannelMessages(channelId, {
    page: 1,
    size: 100
  })

  state.messagesByChannel[channelId] = response.data.items.map((item) =>
    mapMessageForUi(item, state.sessionUser)
  )

  return state.messagesByChannel[channelId]
}

async function refreshAll() {
  await loadJobs()
  await loadInterviews()
  await Promise.all([
    state.sessionUser?.role === 'interviewer' ? loadApplicantsForJobs() : Promise.resolve(),
    state.sessionUser?.role === 'interviewer' ? loadReports() : Promise.resolve(),
    loadChannels()
  ])
}

async function refreshCandidateWorkspace() {
  if (state.sessionUser?.role !== 'candidate' || isAutoRefreshPaused()) {
    return
  }

  await Promise.all([loadJobs(), loadInterviews(), loadChannels()])
}

async function bootstrap(force = false) {
  if (state.bootstrappingPromise && !force) {
    return state.bootstrappingPromise
  }

  if (!getStoredAccessToken()) {
    state.ready = true
    return
  }

  state.bootstrapping = true
  state.bootstrappingPromise = (async () => {
    try {
      await hydrateCurrentUser()
      await refreshAll()
    } catch {
      clearSession()
    } finally {
      state.ready = true
      state.bootstrapping = false
      state.bootstrappingPromise = null
    }
  })()

  return state.bootstrappingPromise
}

bootstrap()

export function useAppStore() {
  const currentUser = computed(() => state.sessionUser)

  const notificationsForCurrentUser = computed(() =>
    state.notifications.filter((item) => item.userId === String(state.sessionUser?.id ?? ''))
  )

  const unreadNotificationCount = computed(() => notificationsForCurrentUser.value.length)

  const interviewerJobs = computed(() =>
    state.jobs.map((job) => ({
      ...job,
      applicantsDetailed: (state.applicantsByJob[job.id] ?? [])
        .map((candidate) => {
          const linkedInterview =
            state.interviews.find(
              (item) => item.jobId === job.id && item.candidateId === candidate.id
            ) ?? null

          if (linkedInterview?.status === 'completed' || (linkedInterview && isInterviewHidden(linkedInterview.id))) {
            return null
          }

          return {
            ...candidate,
            aiNotes: candidate.aiNotes,
            currentInterview: linkedInterview,
            application: {
              submittedAt: candidate.appliedAt
            }
          }
        })
        .filter(Boolean)
    }))
  )

  const candidateApplications = computed(() =>
    state.jobs.filter((job) => job.hasApplied)
  )

  const currentCandidateInterviews = computed(() =>
    state.interviews
      .filter((interview) => !isInterviewHidden(interview.id))
      .filter((interview) => interview.candidateId === state.sessionUser?.id)
      .map((interview) => getNormalizedInterviewById(interview.id) ?? interview)
  )

  const interviewerInterviews = computed(() =>
    state.interviews
      .filter((interview) => !isInterviewHidden(interview.id))
      .filter((interview) => interview.job)
      .map((interview) => getNormalizedInterviewById(interview.id) ?? interview)
  )

  const enrichedReports = computed(() =>
    state.reports.map((report) => {
      const interview = state.interviews.find((item) => item.id === report.interviewId)
      const average = Math.round(
        (report.scores.professional +
          report.scores.communication +
          report.scores.logic +
          report.scores.culture) /
          4
      )

      return {
        ...report,
        candidate: interview?.candidate ?? {
          id: '',
          name: report.candidateName
        },
        job: interview?.job ?? {
          id: '',
          title: report.jobTitle
        },
        grade: report.grade || '',
        average
      }
    })
  )

  const messageThreads = computed(() =>
    state.channels.map((channel) => normalizeThread(channel, state.sessionUser))
  )

  function findJob(jobId) {
    return state.jobs.find((job) => job.id === jobId) ?? null
  }

  function findInterview(interviewId) {
    return getNormalizedInterviewById(interviewId)
  }

  async function login({ account, password }) {
    try {
      const response = await authApi.login({ account, password })
      setSessionUser(response.data.user)
      await hydrateCurrentUser()
      await refreshAll()
      return { ok: true, user: response.data.user }
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : '登录失败'
      }
    }
  }

  function logout() {
    clearSession()
  }

  async function registerCandidate(payload) {
    const registerResponse = await authApi.registerCandidate(payload)
    await login({
      account: registerResponse.data.account,
      password: payload.password
    })

    await updateCandidateProfile({
      education: payload.education,
      experienceYears: Number(payload.experienceYears),
      graduateType: payload.graduateType,
      salaryExpectation: payload.salaryExpectation,
      skills: payload.skills,
      experienceSummary: payload.experienceSummary
    })

    return {
      account: registerResponse.data.account,
      name: registerResponse.data.name,
      role: 'candidate'
    }
  }

  async function updateCandidateProfile(profile) {
    const response = await authApi.updateCurrentUserProfile(profile)
    const normalized = mapUserFromApi(response.data)
    setSessionUser(normalized)
    return normalized
  }

  async function applyToJob(jobId) {
    try {
      await jobsApi.applyToJob(jobId)
      await loadJobs()
      return { ok: true, message: '岗位申请已提交。' }
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : '申请失败'
      }
    }
  }

  async function addJob(payload) {
    try {
      const response = await jobsApi.createJob(payload)
      await loadJobs()
      return { ok: true, job: response.data }
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : '岗位创建失败'
      }
    }
  }

  async function createInterviewPlan(jobId, candidateId) {
    const response = await interviewsApi.createInterview({
      jobId,
      intervieweeId: candidateId
    })
    mergeInterview(response.data)
    await interviewsApi.createInterviewMessageChannel(response.data.id)
    await Promise.all([loadInterviews(), loadChannels(), loadReports()])
    return getNormalizedInterviewById(response.data.id)
  }

  async function updateInterviewSchedule(interviewId, payload) {
    const response = await interviewsApi.updateInterviewOpenTime(interviewId, payload)
    mergeInterview(response.data)
    await loadInterviewWorkspace(interviewId)
    return getNormalizedInterviewById(interviewId)
  }

  async function loadInterviewDetails(interviewId) {
    return loadInterviewWorkspace(interviewId)
  }

  async function submitVoiceAnswer(interviewId, payload) {
    const interview = getNormalizedInterviewById(interviewId)
    if (!interview?.activeQuestion) {
      return null
    }

    const transcriptText = payload?.transcript?.trim?.() ?? ''
    const inputAudio = payload?.audioBlob || payload?.audioFile || null
    const audioType = inputAudio?.type || 'audio/webm'
    const audioExtension = audioType.includes('mp4')
      ? 'mp4'
      : audioType.includes('mpeg') || audioType.includes('mp3')
        ? 'mp3'
        : audioType.includes('m4a')
          ? 'm4a'
          : audioType.includes('wav')
            ? 'wav'
            : audioType.includes('ogg')
              ? 'ogg'
              : 'webm'

    const audioFile = inputAudio instanceof File
      ? inputAudio
      : new File([inputAudio || 'voice-answer'], `answer.${audioExtension}`, {
          type: audioType
        })

    await interviewsApi.submitInterviewAnswer(interviewId, {
      audioFile,
      questionId: interview.activeQuestion.id,
      transcriptText
    })

    await Promise.all([loadInterviewWorkspace(interviewId), loadReports()])
    return { completed: !getNormalizedInterviewById(interviewId)?.activeQuestion }
  }

  async function generateReport(interviewId) {
    const response = await reportsApi.generateInterviewReport(interviewId)
    await loadReports()
    return response.data
  }

  async function rateReport(reportId, grade) {
    await reportsApi.rateReport(reportId, grade)
    await loadReports()
  }

  async function sendOutcome(reportId, outcomeText) {
    if (!outcomeText.trim()) {
      return
    }

    const response = await reportsApi.createReportMessageChannel(reportId)
    const channelId = String(response.data.channel_id)
    await messagesApi.sendChannelMessage(channelId, outcomeText)
    await loadChannels()
  }

  async function sendMessage(payload) {
    if (!payload.threadId || !payload.text?.trim()) {
      return null
    }

    await messagesApi.sendChannelMessage(payload.threadId, payload.text)
    await Promise.all([loadChannelMessages(payload.threadId), loadChannels()])
    return true
  }

  function hideCompletedInterview(interviewId) {
    const interview = getNormalizedInterviewById(interviewId)
    if (!interview || interview.status !== 'completed') {
      return {
        ok: false,
        message: '仅支持删除已完成的面试。'
      }
    }

    addHiddenInterviewId(interviewId)
    state.interviews = state.interviews.filter((item) => item.id !== interviewId)
    delete state.answersByInterview[interviewId]
    return { ok: true }
  }

  function markNotificationRead(notificationId) {
    dismissNotification(notificationId)
  }

  async function resetDemo() {
    await bootstrap(true)
  }

  return {
    state,
    currentUser,
    notificationsForCurrentUser,
    unreadNotificationCount,
    interviewerJobs,
    candidateApplications,
    currentCandidateInterviews,
    interviewerInterviews,
    enrichedReports,
    messageThreads,
    findJob,
    findInterview,
    formatScheduleDisplay,
    login,
    logout,
    registerCandidate,
    updateCandidateProfile,
    applyToJob,
    addJob,
    createInterviewPlan,
    updateInterviewSchedule,
    loadInterviewDetails,
    submitVoiceAnswer,
    generateReport,
    rateReport,
    sendOutcome,
    sendMessage,
    hideCompletedInterview,
    pushNotification,
    dismissNotification,
    markNotificationRead,
    resetDemo,
    refreshAll,
    refreshCandidateWorkspace,
    pauseAutoRefresh,
    resumeAutoRefresh,
    isAutoRefreshPaused
  }
}




