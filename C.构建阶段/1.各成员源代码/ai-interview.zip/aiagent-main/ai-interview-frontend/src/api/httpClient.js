﻿import { API_BASE_URL, getStoredAccessToken } from './config.js?v=20260714m'

function buildQueryString(query = {}) {
  const params = new URLSearchParams()

  Object.entries(query).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') {
      return
    }

    params.set(key, String(value))
  })

  const result = params.toString()
  return result ? `?${result}` : ''
}

export class ApiError extends Error {
  constructor(message, options = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = options.status ?? 500
    this.code = options.code ?? this.status
    this.data = options.data ?? null
    this.raw = options.raw ?? null
  }
}

export async function request(path, options = {}) {
  const {
    method = 'GET',
    query,
    body,
    headers = {},
    auth = true,
    responseType = 'json'
  } = options

  const url = `${API_BASE_URL}${path}${buildQueryString(query)}`
  const finalHeaders = new Headers(headers)
  const token = getStoredAccessToken()

  if (auth && token) {
    finalHeaders.set('Authorization', `Bearer ${token}`)
  }

  // Prevent stale browser-cached API responses from overwriting recent edits.
  finalHeaders.set('Cache-Control', 'no-cache, no-store, must-revalidate')
  finalHeaders.set('Pragma', 'no-cache')

  let payload = body
  if (body !== undefined && !(body instanceof FormData)) {
    finalHeaders.set('Content-Type', 'application/json')
    payload = JSON.stringify(body)
  }

  const response = await fetch(url, {
    method,
    headers: finalHeaders,
    body: payload,
    cache: 'no-store'
  })

  if (responseType === 'blob') {
    if (!response.ok) {
      throw new ApiError(`请求失败: ${response.status}`, {
        status: response.status
      })
    }

    return {
      blob: await response.blob(),
      filename: response.headers.get('Content-Disposition') ?? '',
      contentType: response.headers.get('Content-Type') ?? ''
    }
  }

  const contentType = response.headers.get('Content-Type') ?? ''
  const isJson = contentType.includes('application/json')
  const json = isJson ? await response.json() : null

  if (!response.ok) {
    throw new ApiError(json?.message ?? `请求失败: ${response.status}`, {
      status: response.status,
      code: json?.code,
      data: json?.data,
      raw: json
    })
  }

  if (json && typeof json.code === 'number' && json.code >= 400) {
    throw new ApiError(json.message ?? '业务请求失败', {
      status: response.status,
      code: json.code,
      data: json.data,
      raw: json
    })
  }

  return json
}




