﻿import { request } from './httpClient.js?v=20260714m'
import { mapApplicantFromApi, mapJobFromApi } from './mappers.js?v=20260714m'

function unwrapPagedItems(response, mapper) {
  return {
    ...response,
    data: {
      ...response.data,
      items: Array.isArray(response.data.items) ? response.data.items.map(mapper) : []
    }
  }
}

export async function createJob(payload) {
  const response = await request('/jobs', {
    method: 'POST',
    body: {
      title: payload.title,
      salary_range: payload.salaryRange,
      education_requirement: payload.education,
      work_experience_requirement: payload.experienceYears,
      fresh_requirement: payload.graduateType,
      work_content: payload.responsibilities,
      position_requirements: payload.requirements
    }
  })

  return {
    ...response,
    data: mapJobFromApi(response.data)
  }
}

export async function listJobs(filters = {}) {
  const response = await request('/jobs', {
    query: {
      page: filters.page,
      size: filters.size,
      title: filters.keyword,
      education_requirement: filters.education,
      work_experience_requirement: filters.minExperience,
      fresh_requirement: filters.graduateType,
      sort: filters.sort,
      order: filters.order
    }
  })

  return unwrapPagedItems(response, mapJobFromApi)
}

export async function getJob(jobId) {
  const response = await request(`/jobs/${jobId}`)
  return {
    ...response,
    data: mapJobFromApi(response.data)
  }
}

export async function updateJob(jobId, payload) {
  const response = await request(`/jobs/${jobId}`, {
    method: 'PUT',
    body: {
      title: payload.title,
      salary_range: payload.salaryRange,
      education_requirement: payload.education,
      work_experience_requirement: payload.experienceYears,
      fresh_requirement: payload.graduateType,
      work_content: payload.responsibilities,
      position_requirements: payload.requirements
    }
  })

  return {
    ...response,
    data: mapJobFromApi(response.data)
  }
}

export async function deleteJob(jobId) {
  return request(`/jobs/${jobId}`, {
    method: 'DELETE'
  })
}

export async function listApplicants(jobId, options = {}) {
  const response = await request(`/jobs/${jobId}/applicants`, {
    query: {
      page: options.page,
      size: options.size
    }
  })

  return unwrapPagedItems(response, mapApplicantFromApi)
}

export async function createApplicantMessageChannel(jobId, intervieweeId) {
  return request(`/jobs/${jobId}/applicants/${intervieweeId}/message-channel`, {
    method: 'POST'
  })
}

export async function applyToJob(jobId) {
  return request(`/jobs/${jobId}/apply`, {
    method: 'POST'
  })
}




