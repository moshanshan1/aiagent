﻿import { request } from './httpClient.js?v=20260714m'
import { mapChannelMessageFromApi, mapMessageChannelFromApi } from './mappers.js?v=20260714m'

export async function listMessageChannels(options = {}) {
  const response = await request('/messages/channels', {
    query: {
      page: options.page,
      size: options.size
    }
  })

  return {
    ...response,
    data: {
      ...response.data,
      items: Array.isArray(response.data.items)
        ? response.data.items.map(mapMessageChannelFromApi)
        : []
    }
  }
}

export async function getChannelMessages(channelId, options = {}) {
  const response = await request(`/messages/channels/${channelId}`, {
    query: {
      page: options.page,
      size: options.size
    }
  })

  return {
    ...response,
    data: {
      ...response.data,
      items: Array.isArray(response.data.items)
        ? response.data.items.map(mapChannelMessageFromApi)
        : []
    }
  }
}

export async function sendChannelMessage(channelId, content) {
  const response = await request(`/messages/channels/${channelId}`, {
    method: 'POST',
    body: {
      content
    }
  })

  return {
    ...response,
    data: mapChannelMessageFromApi(response.data)
  }
}




