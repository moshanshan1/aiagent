﻿const TAB_SESSION_PREFIX = '__AI_INTERVIEW_TAB_SESSION__='

function readWindowName() {
  if (typeof window === 'undefined') {
    return ''
  }

  return typeof window.name === 'string' ? window.name : ''
}

function writeWindowName(value) {
  if (typeof window === 'undefined') {
    return
  }

  window.name = value
}

export function getTabSessionState() {
  const raw = readWindowName()
  if (!raw.startsWith(TAB_SESSION_PREFIX)) {
    return {}
  }

  try {
    return JSON.parse(raw.slice(TAB_SESSION_PREFIX.length)) ?? {}
  } catch {
    return {}
  }
}

export function setTabSessionState(nextState) {
  const state = nextState && typeof nextState === 'object' ? nextState : {}
  writeWindowName(`${TAB_SESSION_PREFIX}${JSON.stringify(state)}`)
}

export function getTabSessionValue(key) {
  return getTabSessionState()[key]
}

export function setTabSessionValue(key, value) {
  const current = getTabSessionState()
  if (value === undefined || value === null || value === '') {
    delete current[key]
  } else {
    current[key] = value
  }
  setTabSessionState(current)
}




