﻿import { createApp } from 'vue'
import router from './router/index.js?v=20260714r'

const App = {
  template: '<router-view />'
}

createApp(App).use(router).mount('#app')




