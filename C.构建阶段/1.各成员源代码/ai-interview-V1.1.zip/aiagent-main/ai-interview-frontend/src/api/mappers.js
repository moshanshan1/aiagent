function splitSkills(value) {
  if (Array.isArray(value)) {
    return value.filter(Boolean)
  }

  return String(value ?? '')
    .split(/[,\uff0c\u3001/]+/)
    .map((item) => item.trim())
    .filter(Boolean)
}

function splitLines(value) {
  if (Array.isArray(value)) {
    return value.filter(Boolean)
  }

  return String(value ?? '')
    .split(/\r?\n+/)
    .map((item) => item.trim())
    .filter(Boolean)
}

export function mapRoleFromApi(role) {
  if (role === 'interviewee') {
    return 'candidate'
  }

  return role
}

export function mapRoleToApi(role) {
  if (role === 'candidate') {
    return 'interviewee'
  }

  return role
}

export function mapInterviewStatusFromApi(status) {
  const map = {
    未定时: 'draft_schedule',
    未开始: 'scheduled',
    正在进行: 'in_progress',
    已结束: 'completed'
  }

  return map[status] ?? status
}

export function mapInterviewStatusToApi(status) {
  const map = {
    draft_schedule: '未定时',
    scheduled: '未开始',
    in_progress: '正在进行',
    completed: '已结束'
  }

  return map[status] ?? status
}

export function mapUserFromApi(user) {
  if (!user) {
    return null
  }

  return {
    id: String(user.id),
    account: user.account ?? '',
    name: user.name ?? '',
    role: mapRoleFromApi(user.role),
    avatarUrl: user.avatar_url ?? '',
    profile: {
      education: user.education ?? '',
      experienceYears: Number(user.work_experience ?? 0),
      graduateType: user.is_fresh ?? '',
      salaryExpectation: user.salary_expectation ?? '',
      skills: splitSkills(user.skills),
      experienceSummary: user.experience ?? ''
    }
  }
}

export function mapJobFromApi(job) {
  if (!job) {
    return null
  }

  return {
    id: String(job.id),
    title: job.title ?? '',
    salaryRange: job.salary_range ?? '',
    education: job.education_requirement ?? '',
    experienceYears: Number(job.work_experience_requirement ?? 0),
    graduateType: job.fresh_requirement ?? '',
    responsibilities: job.work_content ?? '',
    requirements: job.position_requirements ?? '',
    tags: Array.isArray(job.tags) ? job.tags : [],
    createdBy: job.created_by ? String(job.created_by) : '',
    createdAt: job.created_at ?? '',
    hasApplied: Boolean(job.has_applied)
  }
}

export function mapApplicantFromApi(item) {
  if (!item) {
    return null
  }

  return {
    id: String(item.interviewee_id),
    name: item.name ?? '',
    profile: {
      education: item.education ?? '',
      experienceYears: Number(item.work_experience ?? 0),
      graduateType: item.is_fresh ?? '',
      skills: splitSkills(item.skills)
    },
    aiNotes: splitLines(item.ai_note),
    appliedAt: item.applied_at ?? ''
  }
}

export function mapQuestionFromApi(question) {
  if (!question) {
    return null
  }

  return {
    id: String(question.id),
    text: question.question_text ?? '',
    type: question.question_type ?? '',
    sortOrder: Number(question.sort_order ?? 0)
  }
}

export function mapInterviewFromApi(interview) {
  if (!interview) {
    return null
  }

  return {
    id: String(interview.id),
    jobId: interview.job_id ? String(interview.job_id) : String(interview.job?.id ?? ''),
    candidateId: interview.interviewee_id
      ? String(interview.interviewee_id)
      : String(interview.interviewee?.id ?? ''),
    job: interview.job
      ? {
          id: String(interview.job.id),
          title: interview.job.title ?? ''
        }
      : null,
    candidate: interview.interviewee
      ? {
          id: String(interview.interviewee.id),
          name: interview.interviewee.name ?? ''
        }
      : null,
    status: mapInterviewStatusFromApi(interview.status),
    interviewMode: interview.interview_mode ?? 'preset',
    maxRounds: Number(interview.max_rounds ?? 5),
    openTimeStart: interview.open_time_start ?? '',
    openTimeEnd: interview.open_time_end ?? '',
    questions: Array.isArray(interview.questions)
      ? interview.questions.map(mapQuestionFromApi)
      : [],
    currentQuestion: interview.current_question
      ? {
          id: String(interview.current_question.id),
          text: interview.current_question.question_text ?? '',
          totalQuestions: Number(interview.current_question.total_questions ?? 0),
          currentIndex: Number(interview.current_question.current_index ?? 0)
        }
      : null
  }
}

export function mapAnswerRecordFromApi(item) {
  if (!item) {
    return null
  }

  return {
    id: String(item.id),
    questionId: String(item.question_id),
    question: item.question_text ?? '',
    transcript: item.transcript ?? '',
    analysis: item.content_analysis ?? '',
    answeredAt: item.answered_at ?? ''
  }
}

export function mapReportFromApi(report) {
  if (!report) {
    return null
  }

  return {
    id: String(report.id),
    interviewId: String(report.interview_id),
    candidateName: report.interviewee_name ?? '',
    jobTitle: report.job_title ?? '',
    summary: report.answer_summary ?? '',
    highlights: splitLines(report.highlights),
    risks: splitLines(report.risks),
    recommendation: report.recommendation ?? '',
    scores: {
      professional: Number(report.skill_score ?? 0),
      communication: Number(report.communication_score ?? 0),
      logic: Number(report.logic_score ?? 0),
      culture: Number(report.culture_score ?? 0)
    },
    grade: report.interviewer_rating ?? '',
    generatedAt: report.generated_at ?? ''
  }
}

export function mapMessageChannelFromApi(channel) {
  if (!channel) {
    return null
  }

  return {
    id: String(channel.id),
    candidate: channel.interviewee
      ? {
          id: String(channel.interviewee.id),
          name: channel.interviewee.name ?? '',
          account: channel.interviewee.account ?? ''
        }
      : null,
    createdFrom: channel.created_from ?? '',
    lastMessage: channel.last_message
      ? {
          content: channel.last_message.content ?? '',
          sentAt: channel.last_message.sent_at ?? ''
        }
      : null,
    createdAt: channel.created_at ?? ''
  }
}

export function mapChannelMessageFromApi(message) {
  if (!message) {
    return null
  }

  return {
    id: String(message.id),
    senderType: message.sender_type ?? '',
    content: message.content ?? '',
    sentAt: message.sent_at ?? ''
  }
}
