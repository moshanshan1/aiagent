﻿import { request } from './httpClient.js?v=20260714m'
import {
  mapAnswerRecordFromApi,
  mapInterviewFromApi,
  mapInterviewStatusToApi,
  mapQuestionFromApi
} from './mappers.js?v=20260714m'

function unwrapPagedInterviews(response) {
  return {
    ...response,
    data: {
      ...response.data,
      items: Array.isArray(response.data.items)
        ? response.data.items.map(mapInterviewFromApi)
        : []
    }
  }
}

export async function createInterview(payload) {
  const body = {
    job_id: payload.jobId,
    interviewee_id: payload.intervieweeId
  }

  if (payload.interviewMode) {
    body.interview_mode = payload.interviewMode
  }

  if (payload.maxRounds != null) {
    body.max_rounds = payload.maxRounds
  }

  const response = await request('/interviews', {
    method: 'POST',
    body
  })

  return {
    ...response,
    data: mapInterviewFromApi(response.data)
  }
}

export async function listInterviews(filters = {}) {
  const response = await request('/interviews', {
    query: {
      page: filters.page,
      size: filters.size,
      status: filters.status ? mapInterviewStatusToApi(filters.status) : undefined,
      job_id: filters.jobId,
      sort: filters.sort,
      order: filters.order
    }
  })

  return unwrapPagedInterviews(response)
}

export async function getInterview(interviewId) {
  const response = await request(`/interviews/${interviewId}`)
  return {
    ...response,
    data: mapInterviewFromApi(response.data)
  }
}

export async function updateInterviewOpenTime(interviewId, payload) {
  const response = await request(`/interviews/${interviewId}/open-time`, {
    method: 'PUT',
    body: {
      open_time_start: payload.openTimeStart,
      open_time_end: payload.openTimeEnd
    }
  })

  return {
    ...response,
    data: mapInterviewFromApi(response.data)
  }
}

export async function updateInterviewQuestion(interviewId, questionId, questionText) {
  const response = await request(`/interviews/${interviewId}/questions/${questionId}`, {
    method: 'PUT',
    body: {
      question_text: questionText
    }
  })

  return {
    ...response,
    data: response.data ? mapQuestionFromApi(response.data) : null
  }
}

export async function checkInInterview(interviewId) {
  const response = await request(`/interviews/${interviewId}/check-in`)
  return {
    ...response,
    data: mapInterviewFromApi(response.data)
  }
}

export async function submitInterviewAnswer(interviewId, payload) {
  const formData = new FormData()
  formData.append('audio_file', payload.audioFile)
  formData.append('question_id', payload.questionId)
  formData.append('transcript_text', payload.transcriptText ?? '')

  const response = await request(`/interviews/${interviewId}/answers`, {
    method: 'POST',
    body: formData
  })

  return {
    ...response,
    data: {
      answerId: response.data.answer_id ? String(response.data.answer_id) : '',
      nextQuestion: response.data.next_question
        ? {
            id: String(response.data.next_question.id),
            text: response.data.next_question.question_text ?? '',
            currentIndex: Number(response.data.next_question.current_index ?? 0),
            totalQuestions: Number(response.data.next_question.total_questions ?? 0)
          }
        : null
    }
  }
}

export async function listInterviewAnswers(interviewId) {
  const response = await request(`/interviews/${interviewId}/answers`)
  return {
    ...response,
    data: {
      items: Array.isArray(response.data.items)
        ? response.data.items.map(mapAnswerRecordFromApi)
        : [],
      completedCount: Number(response.data.completed_count ?? 0),
      totalCount: Number(response.data.total_count ?? 0),
      allCompleted: Boolean(response.data.all_completed)
    }
  }
}

export async function createInterviewMessageChannel(interviewId) {
  return request(`/interviews/${interviewId}/message-channel`, {
    method: 'POST'
  })
}




