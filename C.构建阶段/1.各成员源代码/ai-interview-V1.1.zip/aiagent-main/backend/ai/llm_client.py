"""通用 LLM 客户端封装。

提供基于 OpenAI 兼容接口的异步调用能力，供 question_generator、assessor 等模块复用。
"""

import asyncio
from openai import OpenAI
from ai.logger import log_ai_response
from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL

# 全局 OpenAI 客户端
_client: OpenAI | None = None


def get_client() -> OpenAI:
    """获取或创建全局 OpenAI 客户端。"""
    global _client
    if _client is None:
        _client = OpenAI(
            api_key=LLM_API_KEY,
            base_url=LLM_BASE_URL,
        )
    return _client


def reset_client() -> None:
    """重置全局客户端，便于配置变更后重新初始化。"""
    global _client
    _client = None


async def call_llm(prompt: str, temperature: float = 0.7, model: str | None = None, **kwargs) -> str:
    """调用 LLM（OpenAI 兼容格式），成功返回响应文本，失败抛出 RuntimeError。

    Args:
        prompt: 发送给模型的用户消息内容。
        temperature: 采样温度，默认 0.7。
        model: 指定模型，默认使用配置中的 LLM_MODEL。
        **kwargs: 额外传递给 chat.completions.create 的参数。

    Returns:
        模型生成的文本内容。

    Raises:
        RuntimeError: API Key 未配置、调用超时、鉴权失败、频率超限或其他调用异常。
    """
    if not LLM_API_KEY or LLM_API_KEY.startswith("your-"):
        raise RuntimeError("API Key 未配置")

    try:
        client = get_client()

        def sync_call():
            resp = client.chat.completions.create(
                model=model or LLM_MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                **kwargs,
            )
            return resp.choices[0].message.content or ""

        content = await asyncio.to_thread(sync_call)
        log_ai_response(
            "llm_client.call_llm",
            prompt=prompt,
            response=content,
            metadata={"model": model or LLM_MODEL, "temperature": temperature, **kwargs},
        )
        return content
    except Exception as e:
        err = str(e)
        if "timeout" in err.lower() or "timed out" in err.lower():
            raise RuntimeError("模型调用超时")
        if "401" in err or "Unauthorized" in err:
            raise RuntimeError("API Key 无效")
        if "429" in err or "Rate limit" in err:
            raise RuntimeError("请求频率超限")
        raise RuntimeError(f"模型调用异常: {err}")
