"""面试路由"""

import json
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, Query, Response, UploadFile
from sqlalchemy.orm import Session

from ai.assessor import analyze_content
from ai.tone_analyzer import analyze_tone
from ai.agent_chain import generate_next_question
from database import get_db
from models.user import User
from schemas.interview import InterviewCreate, OpenTimeUpdate, QuestionUpdate
from services.interview_service import (
    check_in,
    create_interview,
    get_answers,
    get_interview,
    get_interviews,
    update_open_time,
    update_question,
    build_qa_history,
)
from services.message_service import create_channel
from utils.file_storage import save_audio
from utils.security import get_current_user, require_interviewer

router = APIRouter(prefix="/interviews", tags=["面试"])


def _is_invalid_transcript(text: str) -> bool:
    if not isinstance(text, str):
        return True

    stripped = text.strip()
    if not stripped:
        return True

    invalid_markers = [
        "[",
        "分析失败",
        "文件不存在",
        "模型返回为空",
        "Error code:",
        "access_denied",
        "Workspace endpoint access denied",
        "服务未配置",
    ]
    return any(marker in stripped for marker in invalid_markers)


@router.post("", status_code=201)
def create(
    req: InterviewCreate,
    response: Response,
    user: User = Depends(require_interviewer),
    db: Session = Depends(get_db),
):
    interview, created = create_interview(
        db, req.job_id, req.interviewee_id, user.id,
        interview_mode=req.interview_mode, max_rounds=req.max_rounds
    )
    if not created:
        response.status_code = 200
        return {"code": 200, "data": _interview_to_dict(interview), "message": "已存在可用面试，已直接返回当前面试"}
    return {"code": 201, "data": _interview_to_dict(interview), "message": "面试创建成功，AI已生成5道问题"}


@router.get("")
def list_interviews(
    status: Optional[str] = None,
    job_id: Optional[int] = None,
    sort: Optional[str] = "created_at",
    order: Optional[str] = "desc",
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    filters = {"status": status, "job_id": job_id, "sort": sort, "order": order}
    result = get_interviews(db, user, filters, page, size)
    items = [_interview_to_dict(item) for item in result["items"]]
    return {"code": 200, "data": {"items": items, "total": result["total"], "page": page, "size": size}, "message": "ok"}


@router.get("/{interview_id}")
def get_detail(interview_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    interview = get_interview(db, interview_id)
    return {"code": 200, "data": _interview_to_dict(interview), "message": "ok"}


@router.put("/{interview_id}/open-time")
def set_open_time(
    interview_id: int,
    req: OpenTimeUpdate,
    user: User = Depends(require_interviewer),
    db: Session = Depends(get_db),
):
    interview = get_interview(db, interview_id)
    updated = update_open_time(db, interview, req.open_time_start, req.open_time_end, user)
    return {"code": 200, "data": _interview_to_dict(updated), "message": "ok"}


@router.put("/{interview_id}/questions/{question_id}")
def edit_question(
    interview_id: int,
    question_id: int,
    req: QuestionUpdate,
    user: User = Depends(require_interviewer),
    db: Session = Depends(get_db),
):
    interview = get_interview(db, interview_id)
    question = update_question(db, interview, question_id, req.question_text, user)
    return {"code": 200, "data": {"id": question.id, "question_text": question.question_text}, "message": "ok"}


@router.get("/{interview_id}/check-in")
def checkin(interview_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    interview = get_interview(db, interview_id)
    data = check_in(db, interview, user)
    return {"code": 200, "data": data, "message": "可以进入面试"}


@router.post("/{interview_id}/answers", status_code=201)
async def submit_voice_answer(
    interview_id: int,
    audio_file: UploadFile = File(...),
    question_id: int = Form(...),
    transcript_text: str = Form(""),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    from models.interview import Answer, Question

    interview = get_interview(db, interview_id)
    audio_path = await save_audio(audio_file, interview_id, question_id)

    tone_result = analyze_tone(audio_path)
    transcript = tone_result.get("transcript", "")
    transcript = transcript.strip() if isinstance(transcript, str) else ""
    manual_transcript = transcript_text.strip() if isinstance(transcript_text, str) else ""
    raw_invalid = _is_invalid_transcript(transcript)

    if raw_invalid:
        transcript = ""
    if not transcript and manual_transcript:
        transcript = manual_transcript
    if not transcript:
        transcript = "已提交语音回答。"

    tone_str = json.dumps(tone_result, ensure_ascii=False)

    answer = db.query(Answer).filter(Answer.interview_id == interview_id, Answer.question_id == question_id).first()
    if answer:
        answer.audio_path = audio_path
        answer.transcript = transcript
        answer.tone_features = tone_str
    else:
        answer = Answer(
            interview_id=interview_id,
            question_id=question_id,
            audio_path=audio_path,
            transcript=transcript,
            tone_features=tone_str,
        )
        db.add(answer)

    question = db.query(Question).filter(Question.id == question_id).first()
    if question and transcript and transcript != "已提交语音回答。":
        content_analysis = await analyze_content(question.question_text, transcript, tone_str)
        answer.content_analysis = content_analysis
    elif answer and not answer.content_analysis:
        answer.content_analysis = "内容分析暂不可用"

    db.commit()

    completed = db.query(Answer).filter(Answer.interview_id == interview.id).count()
    total = len(interview.questions)

    # 构造岗位/候选人信息，供 Agent 模式使用
    job_info = {
        "title": interview.job.title,
        "education_requirement": interview.job.education_requirement,
        "work_experience_requirement": interview.job.work_experience_requirement,
        "work_content": interview.job.work_content,
        "position_requirements": interview.job.position_requirements,
    }
    candidate_info = {
        "name": interview.interviewee.name,
        "education": interview.interviewee.education,
        "work_experience": interview.interviewee.work_experience,
        "skills": interview.interviewee.skills,
        "experience": interview.interviewee.experience,
    }

    if interview.interview_mode == "agent":
        if completed >= interview.max_rounds:
            interview.status = "已结束"
            db.commit()
            next_question_data = None
        else:
            history = build_qa_history(db, interview_id)
            next_q = await generate_next_question(
                job_info, candidate_info, history, completed + 1, interview.max_rounds
            )
            if next_q is None:
                interview.status = "已结束"
                db.commit()
                next_question_data = None
            else:
                question = Question(
                    interview_id=interview.id,
                    question_text=next_q["question_text"],
                    question_type=next_q.get("question_type", "技术"),
                    sort_order=completed + 1,
                )
                db.add(question)
                db.flush()
                next_question_data = {
                    "id": question.id,
                    "question_text": question.question_text,
                    "current_index": completed + 1,
                    "total_questions": interview.max_rounds,
                }
                db.commit()
    else:
        if completed < total:
            next_question = interview.questions[completed]
            next_question_data = {
                "id": next_question.id,
                "question_text": next_question.question_text,
                "current_index": completed + 1,
                "total_questions": total,
            }
        else:
            interview.status = "已结束"
            db.commit()
            next_question_data = None

    return {"code": 201, "data": {"answer_id": answer.id, "next_question": next_question_data}, "message": "回答已保存"}


@router.get("/{interview_id}/answers")
def list_answers(interview_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = get_answers(db, interview_id)
    return {"code": 200, "data": data, "message": "ok"}


@router.post("/{interview_id}/message-channel", status_code=201)
def create_msg_channel(interview_id: int, user: User = Depends(require_interviewer), db: Session = Depends(get_db)):
    interview = get_interview(db, interview_id)
    channel = create_channel(db, user.id, interview.interviewee_id, "面试")
    return {"code": 201, "data": {"channel_id": channel.id}, "message": "通讯渠道已创建"}


def _interview_to_dict(interview):
    return {
        "id": interview.id,
        "job": {"id": interview.job.id, "title": interview.job.title} if interview.job else {},
        "interviewee": {"id": interview.interviewee.id, "name": interview.interviewee.name} if interview.interviewee else {},
        "status": interview.status,
        "interview_mode": interview.interview_mode,
        "max_rounds": interview.max_rounds,
        "questions": [
            {
                "id": question.id,
                "question_text": question.question_text,
                "question_type": question.question_type,
                "sort_order": question.sort_order,
            }
            for question in interview.questions
        ],
        "open_time_start": interview.open_time_start,
        "open_time_end": interview.open_time_end,
    }
