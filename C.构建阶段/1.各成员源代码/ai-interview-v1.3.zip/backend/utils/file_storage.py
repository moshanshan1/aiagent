﻿"""文件存储工具"""
import os
import uuid
from pathlib import Path
from fastapi import UploadFile
from config import AVATAR_DIR, AUDIO_DIR, REPORT_DIR, MAX_AVATAR_SIZE, MAX_AUDIO_SIZE

ALLOWED_AVATAR_TYPES = {"image/jpeg", "image/png", "image/jpg"}
ALLOWED_AUDIO_TYPES = {"audio/wav", "audio/mpeg", "audio/mp3", "audio/m4a", "audio/x-m4a", "audio/mp4"}

async def save_avatar(file: UploadFile, account: str) -> str:
    if file.content_type not in ALLOWED_AVATAR_TYPES:
        raise ValueError("仅支持 jpg/png 格式头像")
    content = await file.read()
    if len(content) > MAX_AVATAR_SIZE:
        raise ValueError("头像文件大小不能超过 2MB")
    AVATAR_DIR.mkdir(parents=True, exist_ok=True)
    ext = "jpg" if "jpeg" in file.content_type or "jpg" in file.content_type else "png"
    filename = f"{account}.{ext}"
    filepath = AVATAR_DIR / filename
    with open(filepath, "wb") as f:
        f.write(content)
    return f"/uploads/avatars/{filename}"

async def save_audio(file: UploadFile, interview_id: int, question_id: int) -> str:
    content = await file.read()
    if len(content) > MAX_AUDIO_SIZE:
        raise ValueError("录音文件大小不能超过 10MB")
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    ext = file.filename.rsplit(".", 1)[-1] if "." in file.filename else "wav"
    filename = f"interview_{interview_id}_q{question_id}_{uuid.uuid4().hex[:8]}.{ext}"
    filepath = AUDIO_DIR / filename
    with open(filepath, "wb") as f:
        f.write(content)
    return str(filepath)

def _find_cn_font(pdf) -> str | None:
    """查找系统中文字体，返回字体名称；找不到返回 None"""
    # 1. 项目目录下的 NotoSansSC
    local = Path(__file__).resolve().parent / "NotoSansSC-VariableFont_wght.ttf"
    if local.exists():
        pdf.add_font("NotoSansSC", "", str(local), uni=True)
        return "NotoSansSC"
    # 2. Windows 系统字体
    candidates = [
        (r"C:\Windows\Fonts\msyh.ttc", "YaHei"),
        (r"C:\Windows\Fonts\simsun.ttc", "SimSun"),
        (r"C:\Windows\Fonts\simhei.ttf", "SimHei"),
    ]
    for path, name in candidates:
        if Path(path).exists():
            try:
                pdf.add_font(name, "", path, uni=True)
                return name
            except Exception:
                continue
    return None


def save_report_pdf(report_data: dict, report_id: int) -> str:
    """使用 fpdf2 生成面试报告 PDF

    Args:
        report_data: {
            "interviewee_name", "job_title", "answer_summary",
            "highlights", "risks", "recommendation",
            "skill_score", "communication_score", "logic_score", "culture_score",
            "interviewer_rating"
        }
        report_id: 报告 ID（用于文件名）

    Returns:
        PDF 文件的绝对路径
    """
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    filepath = REPORT_DIR / f"report_{report_id}.pdf"

    from fpdf import FPDF

    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    cn_font = _find_cn_font(pdf)
    if not cn_font:
        # 无中文字体，降级为 HTML
        html_path = filepath.with_suffix(".html")
        edu = report_data.get("education") or "未填写"
        exp = report_data.get("work_experience")
        exp_str = f"{int(exp)}年" if exp is not None else "未填写"
        fresh = report_data.get("is_fresh") or "未填写"
        salary = report_data.get("salary_expectation") or "未填写"
        skills = report_data.get("skills") or "未填写"
        avatar = report_data.get("avatar_url") or ""

        html_parts = [
            "<html><head><meta charset='utf-8'><title>面试报告</title>",
            "<style>body{font-family:'Microsoft YaHei',sans-serif;padding:28px;color:#20324a;background:#f7fafe;} .card{background:#fff;border:1px solid #d9e6f7;border-radius:16px;padding:18px;margin-bottom:16px;} .title{background:linear-gradient(135deg,#225cbf,#4a87e8);color:#fff;border-radius:18px;padding:24px;} .meta{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;} .tag{display:inline-block;padding:4px 10px;border-radius:999px;background:#eef4ff;color:#2559b1;margin-right:8px;} h2{color:#2559b1;font-size:18px;margin:0 0 12px;} p{line-height:1.8;} li{line-height:1.8;}</style>",
            "</head><body>",
            "<div class='title'><h1>面试评估报告</h1><p>AI面试官与人才评估系统</p></div>",
            "<div class='card'>",
            ('<img src="' + avatar + '" width="88" style="border-radius:14px;float:right;margin-left:16px;">') if avatar else "",
            f"<h2>{report_data.get('interviewee_name') or '未知候选人'}</h2>",
            f"<p><span class='tag'>应聘岗位 {report_data.get('job_title') or '未知'}</span><span class='tag'>系统评级 {report_data.get('rating') or '待计算'}</span><span class='tag'>面试官评级 {report_data.get('interviewer_rating') or '未评级'}</span></p>",
            f"<p><b>学历：</b>{edu}　　<b>工作经验：</b>{exp_str}　　<b>届别：</b>{fresh}</p>",
            f"<p><b>期望薪资：</b>{salary}</p>",
            f"<p><b>技能标签：</b>{skills}</p>",
            "</div>",
            f"<div class='card'><h2>回答摘要</h2><p>{report_data.get('answer_summary', '无')}</p></div>",
            f"<div class='card'><h2>亮点</h2><p>{report_data.get('highlights', '无')}</p></div>",
            f"<div class='card'><h2>风险点</h2><p>{report_data.get('risks', '无')}</p></div>",
            f"<div class='card'><h2>录用建议</h2><p>{report_data.get('recommendation', '无')}</p></div>",
            "<div class='card'><h2>能力评分</h2><ul>",
            *[
                f"<li>{label}：{report_data.get(key, '未评分')}</li>"
                for label, key in (
                    ("专业技能", "skill_score"),
                    ("沟通能力", "communication_score"),
                    ("逻辑思维", "logic_score"),
                    ("文化匹配", "culture_score"),
                )
            ],
            "</ul></div>",
            "</body></html>",
        ]
        html_path.write_text("\n".join(html_parts), encoding="utf-8")
        print("[INFO] 未找到中文字体，已生成 HTML 替代")
        return str(html_path)

    def safe_text(value, default="无"):
        text = str(value).strip() if value is not None else ""
        return text or default

    def score_value(key):
        value = report_data.get(key)
        try:
            return max(0, min(100, int(float(value))))
        except (TypeError, ValueError):
            return 0

    def section_title(text: str):
        pdf.set_fill_color(235, 242, 255)
        pdf.set_draw_color(214, 226, 245)
        pdf.set_text_color(34, 92, 191)
        pdf.set_font(cn_font, "", 13)
        pdf.cell(0, 10, f"  {text}", border=1, fill=True, new_x="LMARGIN", new_y="NEXT")
        pdf.set_text_color(32, 50, 74)
        pdf.ln(2)

    def section_body(content: str):
        pdf.set_font(cn_font, "", 10)
        pdf.set_fill_color(250, 252, 255)
        pdf.set_draw_color(226, 233, 244)
        pdf.multi_cell(0, 7, safe_text(content), border=1, fill=True)
        pdf.ln(4)

    def score_row(label: str, value: int):
        pdf.set_x(18)
        pdf.set_font(cn_font, "", 10)
        pdf.set_text_color(32, 50, 74)
        pdf.cell(28, 8, label)
        pdf.set_fill_color(228, 236, 248)
        pdf.set_draw_color(228, 236, 248)
        pdf.cell(100, 8, "", border=0, fill=True)
        bar_width = 92 * value / 100
        x = pdf.get_x() - 100
        y = pdf.get_y()
        pdf.set_fill_color(58, 118, 219)
        pdf.rect(x + 4, y + 2, bar_width, 4, style="F")
        pdf.set_x(148)
        pdf.set_font(cn_font, "", 11)
        pdf.cell(0, 8, f"{value} 分", new_x="LMARGIN", new_y="NEXT")

    name = safe_text(report_data.get("interviewee_name"), "未知候选人")
    job_title = safe_text(report_data.get("job_title"), "未知岗位")
    edu = safe_text(report_data.get("education"), "未填写")
    exp = report_data.get("work_experience")
    exp_str = f"{int(exp)}年" if exp is not None else "未填写"
    fresh = safe_text(report_data.get("is_fresh"), "未填写")
    salary = safe_text(report_data.get("salary_expectation"), "未填写")
    skills = safe_text(report_data.get("skills"), "未填写")
    auto_rating = safe_text(report_data.get("rating"), "待计算")
    manual_rating = safe_text(report_data.get("interviewer_rating"), "未评级")

    pdf.set_fill_color(34, 92, 191)
    pdf.rect(10, 10, 190, 30, style="F")
    pdf.set_fill_color(82, 135, 226)
    pdf.rect(10, 32, 190, 8, style="F")
    pdf.set_text_color(255, 255, 255)
    pdf.set_font(cn_font, "", 22)
    pdf.set_xy(16, 16)
    pdf.cell(0, 8, "面试评估报告")
    pdf.set_font(cn_font, "", 10)
    pdf.set_xy(16, 26)
    pdf.cell(0, 6, "AI面试官与人才评估系统")

    from config import BASE_DIR
    avatar_url = report_data.get("avatar_url")
    if avatar_url:
        avatar_path = BASE_DIR / str(avatar_url).lstrip("/")
        if avatar_path.exists():
            try:
                pdf.image(str(avatar_path), x=166, y=14, w=22, h=22)
            except Exception:
                pass

    pdf.set_y(46)
    pdf.set_fill_color(246, 249, 255)
    pdf.set_draw_color(214, 226, 245)
    pdf.rect(10, 46, 128, 44, style="DF")
    pdf.rect(144, 46, 56, 44, style="DF")

    pdf.set_xy(16, 52)
    pdf.set_text_color(24, 63, 116)
    pdf.set_font(cn_font, "", 16)
    pdf.cell(0, 8, name)
    pdf.set_xy(16, 61)
    pdf.set_font(cn_font, "", 11)
    pdf.set_text_color(79, 104, 140)
    pdf.cell(0, 6, f"应聘岗位：{job_title}")
    pdf.set_xy(16, 69)
    pdf.cell(0, 6, f"学历：{edu}    工作经验：{exp_str}")
    pdf.set_xy(16, 77)
    pdf.cell(0, 6, f"届别：{fresh}    期望薪资：{salary}")

    pdf.set_xy(150, 55)
    pdf.set_text_color(34, 92, 191)
    pdf.set_font(cn_font, "", 10)
    pdf.cell(0, 6, "系统评级", align="C")
    pdf.set_xy(150, 63)
    pdf.set_font(cn_font, "", 24)
    pdf.cell(0, 10, auto_rating, align="C")
    pdf.set_xy(150, 77)
    pdf.set_font(cn_font, "", 10)
    pdf.set_text_color(79, 104, 140)
    pdf.cell(0, 6, f"面试官：{manual_rating}", align="C")

    pdf.set_y(96)
    section_title("候选人标签")
    section_body(f"技能标签：{skills}")

    sections = [
        ("回答摘要", report_data.get("answer_summary")),
        ("亮点", report_data.get("highlights")),
        ("风险点", report_data.get("risks")),
        ("录用建议", report_data.get("recommendation")),
    ]
    for title, content in sections:
        section_title(title)
        section_body(content)

    section_title("能力评分")
    pdf.set_fill_color(248, 250, 255)
    pdf.set_draw_color(223, 232, 247)
    box_top = pdf.get_y()
    pdf.rect(10, box_top, 190, 42, style="DF")
    pdf.ln(4)
    for label, key in (
        ("专业技能", "skill_score"),
        ("沟通能力", "communication_score"),
        ("逻辑思维", "logic_score"),
        ("文化匹配", "culture_score"),
    ):
        score_row(label, score_value(key))
    pdf.ln(4)

    section_title("结论")
    pdf.set_fill_color(250, 252, 255)
    pdf.set_draw_color(223, 232, 247)
    conclusion_top = pdf.get_y()
    pdf.rect(10, conclusion_top, 190, 20, style="DF")
    pdf.set_xy(16, conclusion_top + 5)
    pdf.set_font(cn_font, "", 11)
    pdf.set_text_color(32, 50, 74)
    pdf.cell(92, 8, f"系统评级：{auto_rating}")
    pdf.cell(0, 8, f"面试官评级：{manual_rating}", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(10)
    pdf.set_font(cn_font, "", 8)
    pdf.set_text_color(111, 130, 152)
    from datetime import date
    pdf.cell(0, 6, f"生成日期：{date.today().isoformat()}", align="C", new_x="LMARGIN", new_y="NEXT")

    pdf.output(str(filepath))
    return str(filepath)
